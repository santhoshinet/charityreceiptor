using System;
using System.Diagnostics;
using System.Reflection;
using System.Windows.Forms;



namespace VVX
{
    class About
    {
        // **************************************************
        // Modified: 2007.03.14
        // **************************************************
        private const string MODULE_NAME = "VVX.About";
        private const string LAST_MODIFIED = "2007.03.14";

        //---------------------------------------------------
        public static string VersionGet()
        {
            return "Last Modified " + LAST_MODIFIED;
        }

        //---------------------------------------------------
        public static void Version()
        {
            MsgBox.Info(VersionGet(), MODULE_NAME);
        }

        //---------------------------------------------------
        /// <summary>
        /// Cheap "About" MessageBox. Reads info from the assembly info in the EXE.
        /// To use simply connect the Help > About command's click handler to call this
        /// static method.
        /// </summary>
        public static void Show()
        {
            string sMsg = "";
            string sEOL = Environment.NewLine;

            //--- create an instance for the assembly
            Assembly appAssembly = Assembly.GetExecutingAssembly();

            //--- create an instance of file FileVersionInfo
            FileVersionInfo appFile = FileVersionInfo.GetVersionInfo(appAssembly.Location);

            //--- WARNING: This sounds crazy, but the value of "AssemblyDescription"
            //    has to be accessed using the "Comments" element of FileVersionInfo.
            string sDescription = appFile.Comments;

            sMsg = String.Format("{0}\n\nVersion {1}:{2}"
                                , sDescription
                                , appFile.FileMajorPart
                                , appFile.FileMinorPart);

            if (appFile.FileBuildPart != 0 || appFile.FilePrivatePart != 0 )
            {
                sMsg += String.Format(":{0}:{1}"
                                , appFile.FileBuildPart
                                , appFile.FilePrivatePart);

            }

            string sAppName = appAssembly.GetName().Name;
            string sCopyright = appFile.LegalCopyright;
            sMsg += sEOL + sCopyright;

            MsgBox.Info(sAppName, sMsg);
        }
    }
}
