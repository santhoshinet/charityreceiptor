namespace iTextSharpExpt
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ctlInfoLBL = new System.Windows.Forms.Label();
            this.ctlMainMenuStrip_MNU = new System.Windows.Forms.MenuStrip();
            this.ctlFile_MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlFileExitMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlHelp_MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlHelpTutorialHomeMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlAdobePdfSpec_MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlAdobePdfSpec17MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlAdobePdfSpec16MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlAdobePdfSpec15MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlAdobePdfSpec14MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlAdobePdfSpec13MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.ctlAdobePdfSpecTechCenterMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.ctlHelpAboutMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlHelpOnThisAppMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlBrowserBackMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlPdfTABS = new System.Windows.Forms.TabControl();
            this.ctlPdfInfoTABPAGE = new System.Windows.Forms.TabPage();
            this.ctlInfoBrowser = new System.Windows.Forms.WebBrowser();
            this.ctlPdfInputsTABPAGE = new System.Windows.Forms.TabPage();
            this.ctlTutorialChap1011BTN = new System.Windows.Forms.Button();
            this.ctlITextSharpTutorialsCHK = new System.Windows.Forms.CheckBox();
            this.ctlPdfHeaderPNL = new System.Windows.Forms.Panel();
            this.ctlScaleWidthsTBX = new System.Windows.Forms.TextBox();
            this.ctlScaleWidthsLBL = new System.Windows.Forms.Label();
            this.ctlScale_LBL = new System.Windows.Forms.Label();
            this.ctlFontHeaderTypeStyleItalicsCHK = new System.Windows.Forms.CheckBox();
            this.ctlFontHeaderTypeStyleBoldCHK = new System.Windows.Forms.CheckBox();
            this.ctlFontHeaderTypeSizeTBX = new System.Windows.Forms.TextBox();
            this.ctlFontHeaderTypeFaceCBX = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ctlFontBodyLBL = new System.Windows.Forms.Label();
            this.ctlFontBodyTypeStyleItalicsCHK = new System.Windows.Forms.CheckBox();
            this.ctlFontBodyTypeStyleBoldCHK = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ctlFontBodyTypeSizeTBX = new System.Windows.Forms.TextBox();
            this.ctlTypeSizeLBL = new System.Windows.Forms.Label();
            this.ctlFontBodyTypeFaceCBX = new System.Windows.Forms.ComboBox();
            this.ctlTypeFaceLBL = new System.Windows.Forms.Label();
            this.ctlShowSizeCBX = new System.Windows.Forms.ComboBox();
            this.ctlShowLandscapeCHK = new System.Windows.Forms.CheckBox();
            this.ctlShowWatermarkFileTBX = new System.Windows.Forms.TextBox();
            this.ctlShowWatermarkFileBTN = new System.Windows.Forms.Button();
            this.ctlShowWatermarkTextLBL = new System.Windows.Forms.Label();
            this.ctlShowWatermarkTextTBX = new System.Windows.Forms.TextBox();
            this.ctlShowWatermarkCHK = new System.Windows.Forms.CheckBox();
            this.ctlShowPageNumberCHK = new System.Windows.Forms.CheckBox();
            this.ctlShowTitleCHK = new System.Windows.Forms.CheckBox();
            this.ctlShow_LBL = new System.Windows.Forms.Label();
            this.ctlViewCenterOnScreenCHK = new System.Windows.Forms.CheckBox();
            this.ctlViewResizeToFitCHK = new System.Windows.Forms.CheckBox();
            this.ctlViewWindowUICHK = new System.Windows.Forms.CheckBox();
            this.ctlView_LBL = new System.Windows.Forms.Label();
            this.ctlViewMenuBarCHK = new System.Windows.Forms.CheckBox();
            this.ctlViewToolBarCHK = new System.Windows.Forms.CheckBox();
            this.ctlViewLayout2PageCHK = new System.Windows.Forms.CheckBox();
            this.ctlEncrypt_PNL = new System.Windows.Forms.Panel();
            this.ctlEncryptPasswordsLBL = new System.Windows.Forms.Label();
            this.ctlEncrypt128BitCHK = new System.Windows.Forms.CheckBox();
            this.ctlEncryptUserCanLBL = new System.Windows.Forms.Label();
            this.ctlEncryptAllowPrintDegradedCHK = new System.Windows.Forms.CheckBox();
            this.ctlEncryptAllowAssemblyCHK = new System.Windows.Forms.CheckBox();
            this.ctlEncryptAllowScreenReadersCHK = new System.Windows.Forms.CheckBox();
            this.ctlEncryptAllowFillInCHK = new System.Windows.Forms.CheckBox();
            this.ctlEncryptAllowModifyAnnotationsCHK = new System.Windows.Forms.CheckBox();
            this.ctlEncryptAllowCopyingCHK = new System.Windows.Forms.CheckBox();
            this.ctlEncryptAllowModifyContentsCHK = new System.Windows.Forms.CheckBox();
            this.ctlEncryptAllowPrintingCHK = new System.Windows.Forms.CheckBox();
            this.ctlEncryptPasswordOwnerTBX = new System.Windows.Forms.TextBox();
            this.ctlEncryptPasswordOwnerLBL = new System.Windows.Forms.Label();
            this.ctlEncryptPasswordUserTBX = new System.Windows.Forms.TextBox();
            this.ctlEncryptPasswordUserLBL = new System.Windows.Forms.Label();
            this.ctlPdfHeaderEncryptCHK = new System.Windows.Forms.CheckBox();
            this.ctlPdfHeaderDefaultsBTN = new System.Windows.Forms.Button();
            this.ctlPdfHeaderKeywordsTBX = new System.Windows.Forms.TextBox();
            this.ctlPdfHeaderKeywordsLBL = new System.Windows.Forms.Label();
            this.ctlPdfHeaderAuthorTBX = new System.Windows.Forms.TextBox();
            this.ctlPdfHeaderAuthorLBL = new System.Windows.Forms.Label();
            this.ctlPdfHeaderSubjectTBX = new System.Windows.Forms.TextBox();
            this.ctlPdfHeaderSubjectLBL = new System.Windows.Forms.Label();
            this.ctlPdfHeaderTitleTBX = new System.Windows.Forms.TextBox();
            this.ctlPdfHeaderTitleLBL = new System.Windows.Forms.Label();
            this.ctlPdfHeaderFileTBX = new System.Windows.Forms.TextBox();
            this.ctlPdfHeaderFileLBL = new System.Windows.Forms.Label();
            this.ctlPdfHeaderLBL = new System.Windows.Forms.Label();
            this.ctlTutorialChap1202BTN = new System.Windows.Forms.Button();
            this.ctlSrcXmlStoreBTN = new System.Windows.Forms.Button();
            this.ctlTutorialChap0518BTN = new System.Windows.Forms.Button();
            this.ctlPdfOutputTABPAGE = new System.Windows.Forms.TabPage();
            this.ctlPdfBrowser = new System.Windows.Forms.WebBrowser();
            this.ctlToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.ctlMainMenuStrip_MNU.SuspendLayout();
            this.ctlPdfTABS.SuspendLayout();
            this.ctlPdfInfoTABPAGE.SuspendLayout();
            this.ctlPdfInputsTABPAGE.SuspendLayout();
            this.ctlPdfHeaderPNL.SuspendLayout();
            this.ctlEncrypt_PNL.SuspendLayout();
            this.ctlPdfOutputTABPAGE.SuspendLayout();
            this.SuspendLayout();
            // 
            // ctlInfoLBL
            // 
            this.ctlInfoLBL.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ctlInfoLBL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ctlInfoLBL.Location = new System.Drawing.Point(12, 571);
            this.ctlInfoLBL.Name = "ctlInfoLBL";
            this.ctlInfoLBL.Size = new System.Drawing.Size(713, 23);
            this.ctlInfoLBL.TabIndex = 8;
            this.ctlInfoLBL.Text = "Ready";
            // 
            // ctlMainMenuStrip_MNU
            // 
            this.ctlMainMenuStrip_MNU.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlFile_MNU,
            this.ctlHelp_MNU,
            this.ctlBrowserBackMNU});
            this.ctlMainMenuStrip_MNU.Location = new System.Drawing.Point(0, 0);
            this.ctlMainMenuStrip_MNU.Name = "ctlMainMenuStrip_MNU";
            this.ctlMainMenuStrip_MNU.Size = new System.Drawing.Size(737, 24);
            this.ctlMainMenuStrip_MNU.TabIndex = 9;
            this.ctlMainMenuStrip_MNU.Text = "&Help";
            // 
            // ctlFile_MNU
            // 
            this.ctlFile_MNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlFileExitMNU});
            this.ctlFile_MNU.Name = "ctlFile_MNU";
            this.ctlFile_MNU.Size = new System.Drawing.Size(35, 20);
            this.ctlFile_MNU.Text = "&File";
            // 
            // ctlFileExitMNU
            // 
            this.ctlFileExitMNU.Name = "ctlFileExitMNU";
            this.ctlFileExitMNU.Size = new System.Drawing.Size(103, 22);
            this.ctlFileExitMNU.Text = "E&xit";
            // 
            // ctlHelp_MNU
            // 
            this.ctlHelp_MNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlHelpTutorialHomeMNU,
            this.ctlAdobePdfSpec_MNU,
            this.toolStripMenuItem1,
            this.ctlHelpAboutMNU,
            this.ctlHelpOnThisAppMNU});
            this.ctlHelp_MNU.Name = "ctlHelp_MNU";
            this.ctlHelp_MNU.Size = new System.Drawing.Size(40, 20);
            this.ctlHelp_MNU.Text = "&Help";
            // 
            // ctlHelpTutorialHomeMNU
            // 
            this.ctlHelpTutorialHomeMNU.Name = "ctlHelpTutorialHomeMNU";
            this.ctlHelpTutorialHomeMNU.Size = new System.Drawing.Size(206, 22);
            this.ctlHelpTutorialHomeMNU.Text = "iTextSharp Tutorial Home";
            this.ctlHelpTutorialHomeMNU.Click += new System.EventHandler(this.ctlHelpTutorialHomeMNU_Click);
            // 
            // ctlAdobePdfSpec_MNU
            // 
            this.ctlAdobePdfSpec_MNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlAdobePdfSpec17MNU,
            this.ctlAdobePdfSpec16MNU,
            this.ctlAdobePdfSpec15MNU,
            this.ctlAdobePdfSpec14MNU,
            this.ctlAdobePdfSpec13MNU,
            this.toolStripMenuItem2,
            this.ctlAdobePdfSpecTechCenterMNU});
            this.ctlAdobePdfSpec_MNU.Name = "ctlAdobePdfSpec_MNU";
            this.ctlAdobePdfSpec_MNU.Size = new System.Drawing.Size(206, 22);
            this.ctlAdobePdfSpec_MNU.Text = "Adobe PDF Specifications";
            // 
            // ctlAdobePdfSpec17MNU
            // 
            this.ctlAdobePdfSpec17MNU.Name = "ctlAdobePdfSpec17MNU";
            this.ctlAdobePdfSpec17MNU.Size = new System.Drawing.Size(198, 22);
            this.ctlAdobePdfSpec17MNU.Text = "Version 1.7";
            this.ctlAdobePdfSpec17MNU.Click += new System.EventHandler(this.ctlAdobePdfSpec17MNU_Click);
            // 
            // ctlAdobePdfSpec16MNU
            // 
            this.ctlAdobePdfSpec16MNU.Name = "ctlAdobePdfSpec16MNU";
            this.ctlAdobePdfSpec16MNU.Size = new System.Drawing.Size(198, 22);
            this.ctlAdobePdfSpec16MNU.Text = "Version 1.6";
            this.ctlAdobePdfSpec16MNU.Click += new System.EventHandler(this.ctlAdobePdfSpec16MNU_Click);
            // 
            // ctlAdobePdfSpec15MNU
            // 
            this.ctlAdobePdfSpec15MNU.Name = "ctlAdobePdfSpec15MNU";
            this.ctlAdobePdfSpec15MNU.Size = new System.Drawing.Size(198, 22);
            this.ctlAdobePdfSpec15MNU.Text = "Version 1.5";
            this.ctlAdobePdfSpec15MNU.Click += new System.EventHandler(this.ctlAdobePdfSpec15MNU_Click);
            // 
            // ctlAdobePdfSpec14MNU
            // 
            this.ctlAdobePdfSpec14MNU.Name = "ctlAdobePdfSpec14MNU";
            this.ctlAdobePdfSpec14MNU.Size = new System.Drawing.Size(198, 22);
            this.ctlAdobePdfSpec14MNU.Text = "Version 1.4";
            this.ctlAdobePdfSpec14MNU.Click += new System.EventHandler(this.ctlAdobePdfSpec14MNU_Click);
            // 
            // ctlAdobePdfSpec13MNU
            // 
            this.ctlAdobePdfSpec13MNU.Name = "ctlAdobePdfSpec13MNU";
            this.ctlAdobePdfSpec13MNU.Size = new System.Drawing.Size(198, 22);
            this.ctlAdobePdfSpec13MNU.Text = "Version 1.3";
            this.ctlAdobePdfSpec13MNU.Click += new System.EventHandler(this.ctlAdobePdfSpec13MNU_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(195, 6);
            // 
            // ctlAdobePdfSpecTechCenterMNU
            // 
            this.ctlAdobePdfSpecTechCenterMNU.Name = "ctlAdobePdfSpecTechCenterMNU";
            this.ctlAdobePdfSpecTechCenterMNU.Size = new System.Drawing.Size(198, 22);
            this.ctlAdobePdfSpecTechCenterMNU.Text = "PDF Technology Center";
            this.ctlAdobePdfSpecTechCenterMNU.Click += new System.EventHandler(this.ctlAdobePdfSpecTechCenterMNU_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(203, 6);
            // 
            // ctlHelpAboutMNU
            // 
            this.ctlHelpAboutMNU.Name = "ctlHelpAboutMNU";
            this.ctlHelpAboutMNU.Size = new System.Drawing.Size(206, 22);
            this.ctlHelpAboutMNU.Text = "&About";
            this.ctlHelpAboutMNU.Click += new System.EventHandler(this.ctlHelpAboutMNU_Click);
            // 
            // ctlHelpOnThisAppMNU
            // 
            this.ctlHelpOnThisAppMNU.Name = "ctlHelpOnThisAppMNU";
            this.ctlHelpOnThisAppMNU.Size = new System.Drawing.Size(206, 22);
            this.ctlHelpOnThisAppMNU.Text = "This app";
            this.ctlHelpOnThisAppMNU.Click += new System.EventHandler(this.ctlHelpOnThisAppMNU_Click);
            // 
            // ctlBrowserBackMNU
            // 
            this.ctlBrowserBackMNU.Name = "ctlBrowserBackMNU";
            this.ctlBrowserBackMNU.Size = new System.Drawing.Size(41, 20);
            this.ctlBrowserBackMNU.Text = "&Back";
            this.ctlBrowserBackMNU.Click += new System.EventHandler(this.ctlBrowserBackMNU_Click);
            // 
            // ctlPdfTABS
            // 
            this.ctlPdfTABS.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ctlPdfTABS.Controls.Add(this.ctlPdfInfoTABPAGE);
            this.ctlPdfTABS.Controls.Add(this.ctlPdfInputsTABPAGE);
            this.ctlPdfTABS.Controls.Add(this.ctlPdfOutputTABPAGE);
            this.ctlPdfTABS.Location = new System.Drawing.Point(12, 40);
            this.ctlPdfTABS.Name = "ctlPdfTABS";
            this.ctlPdfTABS.SelectedIndex = 0;
            this.ctlPdfTABS.Size = new System.Drawing.Size(713, 516);
            this.ctlPdfTABS.TabIndex = 11;
            // 
            // ctlPdfInfoTABPAGE
            // 
            this.ctlPdfInfoTABPAGE.Controls.Add(this.ctlInfoBrowser);
            this.ctlPdfInfoTABPAGE.Location = new System.Drawing.Point(4, 22);
            this.ctlPdfInfoTABPAGE.Name = "ctlPdfInfoTABPAGE";
            this.ctlPdfInfoTABPAGE.Size = new System.Drawing.Size(705, 490);
            this.ctlPdfInfoTABPAGE.TabIndex = 2;
            this.ctlPdfInfoTABPAGE.Text = "Information";
            this.ctlPdfInfoTABPAGE.UseVisualStyleBackColor = true;
            // 
            // ctlInfoBrowser
            // 
            this.ctlInfoBrowser.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ctlInfoBrowser.Location = new System.Drawing.Point(3, 3);
            this.ctlInfoBrowser.MinimumSize = new System.Drawing.Size(20, 20);
            this.ctlInfoBrowser.Name = "ctlInfoBrowser";
            this.ctlInfoBrowser.Size = new System.Drawing.Size(699, 484);
            this.ctlInfoBrowser.TabIndex = 0;
            // 
            // ctlPdfInputsTABPAGE
            // 
            this.ctlPdfInputsTABPAGE.Controls.Add(this.ctlTutorialChap1011BTN);
            this.ctlPdfInputsTABPAGE.Controls.Add(this.ctlITextSharpTutorialsCHK);
            this.ctlPdfInputsTABPAGE.Controls.Add(this.ctlPdfHeaderPNL);
            this.ctlPdfInputsTABPAGE.Controls.Add(this.ctlTutorialChap1202BTN);
            this.ctlPdfInputsTABPAGE.Controls.Add(this.ctlSrcXmlStoreBTN);
            this.ctlPdfInputsTABPAGE.Controls.Add(this.ctlTutorialChap0518BTN);
            this.ctlPdfInputsTABPAGE.Location = new System.Drawing.Point(4, 22);
            this.ctlPdfInputsTABPAGE.Name = "ctlPdfInputsTABPAGE";
            this.ctlPdfInputsTABPAGE.Padding = new System.Windows.Forms.Padding(3);
            this.ctlPdfInputsTABPAGE.Size = new System.Drawing.Size(705, 490);
            this.ctlPdfInputsTABPAGE.TabIndex = 1;
            this.ctlPdfInputsTABPAGE.Text = "Selections";
            this.ctlPdfInputsTABPAGE.UseVisualStyleBackColor = true;
            // 
            // ctlTutorialChap1011BTN
            // 
            this.ctlTutorialChap1011BTN.Enabled = false;
            this.ctlTutorialChap1011BTN.Location = new System.Drawing.Point(28, 330);
            this.ctlTutorialChap1011BTN.Name = "ctlTutorialChap1011BTN";
            this.ctlTutorialChap1011BTN.Size = new System.Drawing.Size(132, 23);
            this.ctlTutorialChap1011BTN.TabIndex = 6;
            this.ctlTutorialChap1011BTN.Text = "Chap1011";
            this.ctlTutorialChap1011BTN.UseVisualStyleBackColor = true;
            this.ctlTutorialChap1011BTN.Click += new System.EventHandler(this.ctlTutorialChap1011BTN_Click);
            // 
            // ctlITextSharpTutorialsCHK
            // 
            this.ctlITextSharpTutorialsCHK.AutoSize = true;
            this.ctlITextSharpTutorialsCHK.Location = new System.Drawing.Point(28, 273);
            this.ctlITextSharpTutorialsCHK.Name = "ctlITextSharpTutorialsCHK";
            this.ctlITextSharpTutorialsCHK.Size = new System.Drawing.Size(120, 17);
            this.ctlITextSharpTutorialsCHK.TabIndex = 5;
            this.ctlITextSharpTutorialsCHK.Text = "iTextSharp Tutorials";
            this.ctlITextSharpTutorialsCHK.UseVisualStyleBackColor = true;
            this.ctlITextSharpTutorialsCHK.CheckedChanged += new System.EventHandler(this.ctlITextSharpTutorialsCHK_CheckedChanged);
            // 
            // ctlPdfHeaderPNL
            // 
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlScaleWidthsTBX);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlScaleWidthsLBL);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlScale_LBL);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlFontHeaderTypeStyleItalicsCHK);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlFontHeaderTypeStyleBoldCHK);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlFontHeaderTypeSizeTBX);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlFontHeaderTypeFaceCBX);
            this.ctlPdfHeaderPNL.Controls.Add(this.label2);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlFontBodyLBL);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlFontBodyTypeStyleItalicsCHK);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlFontBodyTypeStyleBoldCHK);
            this.ctlPdfHeaderPNL.Controls.Add(this.label1);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlFontBodyTypeSizeTBX);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlTypeSizeLBL);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlFontBodyTypeFaceCBX);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlTypeFaceLBL);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlShowSizeCBX);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlShowLandscapeCHK);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlShowWatermarkFileTBX);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlShowWatermarkFileBTN);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlShowWatermarkTextLBL);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlShowWatermarkTextTBX);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlShowWatermarkCHK);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlShowPageNumberCHK);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlShowTitleCHK);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlShow_LBL);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlViewCenterOnScreenCHK);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlViewResizeToFitCHK);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlViewWindowUICHK);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlView_LBL);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlViewMenuBarCHK);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlViewToolBarCHK);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlViewLayout2PageCHK);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlEncrypt_PNL);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlPdfHeaderEncryptCHK);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlPdfHeaderDefaultsBTN);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlPdfHeaderKeywordsTBX);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlPdfHeaderKeywordsLBL);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlPdfHeaderAuthorTBX);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlPdfHeaderAuthorLBL);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlPdfHeaderSubjectTBX);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlPdfHeaderSubjectLBL);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlPdfHeaderTitleTBX);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlPdfHeaderTitleLBL);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlPdfHeaderFileTBX);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlPdfHeaderFileLBL);
            this.ctlPdfHeaderPNL.Controls.Add(this.ctlPdfHeaderLBL);
            this.ctlPdfHeaderPNL.Location = new System.Drawing.Point(180, 12);
            this.ctlPdfHeaderPNL.Name = "ctlPdfHeaderPNL";
            this.ctlPdfHeaderPNL.Size = new System.Drawing.Size(512, 472);
            this.ctlPdfHeaderPNL.TabIndex = 3;
            // 
            // ctlScaleWidthsTBX
            // 
            this.ctlScaleWidthsTBX.Location = new System.Drawing.Point(235, 211);
            this.ctlScaleWidthsTBX.Name = "ctlScaleWidthsTBX";
            this.ctlScaleWidthsTBX.Size = new System.Drawing.Size(34, 20);
            this.ctlScaleWidthsTBX.TabIndex = 42;
            this.ctlScaleWidthsTBX.Text = "1.0";
            this.ctlToolTip.SetToolTip(this.ctlScaleWidthsTBX, "Multiplier for scaling the widths of the columns");
            // 
            // ctlScaleWidthsLBL
            // 
            this.ctlScaleWidthsLBL.AutoSize = true;
            this.ctlScaleWidthsLBL.Location = new System.Drawing.Point(168, 214);
            this.ctlScaleWidthsLBL.Name = "ctlScaleWidthsLBL";
            this.ctlScaleWidthsLBL.Size = new System.Drawing.Size(61, 13);
            this.ctlScaleWidthsLBL.TabIndex = 41;
            this.ctlScaleWidthsLBL.Text = "Col. Widths";
            // 
            // ctlScale_LBL
            // 
            this.ctlScale_LBL.AutoSize = true;
            this.ctlScale_LBL.Location = new System.Drawing.Point(155, 199);
            this.ctlScale_LBL.Name = "ctlScale_LBL";
            this.ctlScale_LBL.Size = new System.Drawing.Size(70, 13);
            this.ctlScale_LBL.TabIndex = 40;
            this.ctlScale_LBL.Text = "Scale Factor:";
            // 
            // ctlFontHeaderTypeStyleItalicsCHK
            // 
            this.ctlFontHeaderTypeStyleItalicsCHK.AutoSize = true;
            this.ctlFontHeaderTypeStyleItalicsCHK.Location = new System.Drawing.Point(191, 446);
            this.ctlFontHeaderTypeStyleItalicsCHK.Name = "ctlFontHeaderTypeStyleItalicsCHK";
            this.ctlFontHeaderTypeStyleItalicsCHK.Size = new System.Drawing.Size(53, 17);
            this.ctlFontHeaderTypeStyleItalicsCHK.TabIndex = 18;
            this.ctlFontHeaderTypeStyleItalicsCHK.Text = "Italics";
            this.ctlToolTip.SetToolTip(this.ctlFontHeaderTypeStyleItalicsCHK, "Column Header Font Style ITALICS");
            this.ctlFontHeaderTypeStyleItalicsCHK.UseVisualStyleBackColor = true;
            // 
            // ctlFontHeaderTypeStyleBoldCHK
            // 
            this.ctlFontHeaderTypeStyleBoldCHK.AutoSize = true;
            this.ctlFontHeaderTypeStyleBoldCHK.Location = new System.Drawing.Point(191, 423);
            this.ctlFontHeaderTypeStyleBoldCHK.Name = "ctlFontHeaderTypeStyleBoldCHK";
            this.ctlFontHeaderTypeStyleBoldCHK.Size = new System.Drawing.Size(47, 17);
            this.ctlFontHeaderTypeStyleBoldCHK.TabIndex = 17;
            this.ctlFontHeaderTypeStyleBoldCHK.Text = "Bold";
            this.ctlToolTip.SetToolTip(this.ctlFontHeaderTypeStyleBoldCHK, "Column Header Font Style BOLD");
            this.ctlFontHeaderTypeStyleBoldCHK.UseVisualStyleBackColor = true;
            // 
            // ctlFontHeaderTypeSizeTBX
            // 
            this.ctlFontHeaderTypeSizeTBX.Location = new System.Drawing.Point(191, 397);
            this.ctlFontHeaderTypeSizeTBX.Name = "ctlFontHeaderTypeSizeTBX";
            this.ctlFontHeaderTypeSizeTBX.Size = new System.Drawing.Size(53, 20);
            this.ctlFontHeaderTypeSizeTBX.TabIndex = 16;
            this.ctlToolTip.SetToolTip(this.ctlFontHeaderTypeSizeTBX, "Column Header Font Size in Points");
            // 
            // ctlFontHeaderTypeFaceCBX
            // 
            this.ctlFontHeaderTypeFaceCBX.FormattingEnabled = true;
            this.ctlFontHeaderTypeFaceCBX.Location = new System.Drawing.Point(191, 372);
            this.ctlFontHeaderTypeFaceCBX.Name = "ctlFontHeaderTypeFaceCBX";
            this.ctlFontHeaderTypeFaceCBX.Size = new System.Drawing.Size(66, 21);
            this.ctlFontHeaderTypeFaceCBX.TabIndex = 15;
            this.ctlToolTip.SetToolTip(this.ctlFontHeaderTypeFaceCBX, "Column Header Font Type Face");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(188, 356);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 39;
            this.label2.Text = "Header";
            // 
            // ctlFontBodyLBL
            // 
            this.ctlFontBodyLBL.AutoSize = true;
            this.ctlFontBodyLBL.Location = new System.Drawing.Point(108, 356);
            this.ctlFontBodyLBL.Name = "ctlFontBodyLBL";
            this.ctlFontBodyLBL.Size = new System.Drawing.Size(31, 13);
            this.ctlFontBodyLBL.TabIndex = 38;
            this.ctlFontBodyLBL.Text = "Body";
            // 
            // ctlFontBodyTypeStyleItalicsCHK
            // 
            this.ctlFontBodyTypeStyleItalicsCHK.AutoSize = true;
            this.ctlFontBodyTypeStyleItalicsCHK.Location = new System.Drawing.Point(109, 446);
            this.ctlFontBodyTypeStyleItalicsCHK.Name = "ctlFontBodyTypeStyleItalicsCHK";
            this.ctlFontBodyTypeStyleItalicsCHK.Size = new System.Drawing.Size(53, 17);
            this.ctlFontBodyTypeStyleItalicsCHK.TabIndex = 14;
            this.ctlFontBodyTypeStyleItalicsCHK.Text = "Italics";
            this.ctlToolTip.SetToolTip(this.ctlFontBodyTypeStyleItalicsCHK, "Body Font Style ITALICS");
            this.ctlFontBodyTypeStyleItalicsCHK.UseVisualStyleBackColor = true;
            // 
            // ctlFontBodyTypeStyleBoldCHK
            // 
            this.ctlFontBodyTypeStyleBoldCHK.AutoSize = true;
            this.ctlFontBodyTypeStyleBoldCHK.Location = new System.Drawing.Point(109, 423);
            this.ctlFontBodyTypeStyleBoldCHK.Name = "ctlFontBodyTypeStyleBoldCHK";
            this.ctlFontBodyTypeStyleBoldCHK.Size = new System.Drawing.Size(47, 17);
            this.ctlFontBodyTypeStyleBoldCHK.TabIndex = 13;
            this.ctlFontBodyTypeStyleBoldCHK.Text = "Bold";
            this.ctlToolTip.SetToolTip(this.ctlFontBodyTypeStyleBoldCHK, "Body Font Style BOLD");
            this.ctlFontBodyTypeStyleBoldCHK.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 425);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 35;
            this.label1.Text = "Type Style";
            // 
            // ctlFontBodyTypeSizeTBX
            // 
            this.ctlFontBodyTypeSizeTBX.Location = new System.Drawing.Point(109, 397);
            this.ctlFontBodyTypeSizeTBX.Name = "ctlFontBodyTypeSizeTBX";
            this.ctlFontBodyTypeSizeTBX.Size = new System.Drawing.Size(53, 20);
            this.ctlFontBodyTypeSizeTBX.TabIndex = 12;
            this.ctlToolTip.SetToolTip(this.ctlFontBodyTypeSizeTBX, "Body Font Size in Points");
            // 
            // ctlTypeSizeLBL
            // 
            this.ctlTypeSizeLBL.AutoSize = true;
            this.ctlTypeSizeLBL.Location = new System.Drawing.Point(21, 400);
            this.ctlTypeSizeLBL.Name = "ctlTypeSizeLBL";
            this.ctlTypeSizeLBL.Size = new System.Drawing.Size(54, 13);
            this.ctlTypeSizeLBL.TabIndex = 33;
            this.ctlTypeSizeLBL.Text = "Type Size";
            // 
            // ctlFontBodyTypeFaceCBX
            // 
            this.ctlFontBodyTypeFaceCBX.FormattingEnabled = true;
            this.ctlFontBodyTypeFaceCBX.Location = new System.Drawing.Point(109, 372);
            this.ctlFontBodyTypeFaceCBX.Name = "ctlFontBodyTypeFaceCBX";
            this.ctlFontBodyTypeFaceCBX.Size = new System.Drawing.Size(66, 21);
            this.ctlFontBodyTypeFaceCBX.TabIndex = 11;
            this.ctlToolTip.SetToolTip(this.ctlFontBodyTypeFaceCBX, "Body Font Type Face");
            // 
            // ctlTypeFaceLBL
            // 
            this.ctlTypeFaceLBL.AutoSize = true;
            this.ctlTypeFaceLBL.Location = new System.Drawing.Point(21, 375);
            this.ctlTypeFaceLBL.Name = "ctlTypeFaceLBL";
            this.ctlTypeFaceLBL.Size = new System.Drawing.Size(58, 13);
            this.ctlTypeFaceLBL.TabIndex = 31;
            this.ctlTypeFaceLBL.Text = "Type Face";
            // 
            // ctlShowSizeCBX
            // 
            this.ctlShowSizeCBX.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ctlShowSizeCBX.FormattingEnabled = true;
            this.ctlShowSizeCBX.Location = new System.Drawing.Point(109, 316);
            this.ctlShowSizeCBX.Name = "ctlShowSizeCBX";
            this.ctlShowSizeCBX.Size = new System.Drawing.Size(116, 21);
            this.ctlShowSizeCBX.TabIndex = 10;
            this.ctlToolTip.SetToolTip(this.ctlShowSizeCBX, "Paper Size");
            // 
            // ctlShowLandscapeCHK
            // 
            this.ctlShowLandscapeCHK.AutoSize = true;
            this.ctlShowLandscapeCHK.Location = new System.Drawing.Point(24, 318);
            this.ctlShowLandscapeCHK.Name = "ctlShowLandscapeCHK";
            this.ctlShowLandscapeCHK.Size = new System.Drawing.Size(79, 17);
            this.ctlShowLandscapeCHK.TabIndex = 29;
            this.ctlShowLandscapeCHK.Text = "Landscape";
            this.ctlToolTip.SetToolTip(this.ctlShowLandscapeCHK, "Rotate the page so that Width is greater than Height");
            this.ctlShowLandscapeCHK.UseVisualStyleBackColor = true;
            // 
            // ctlShowWatermarkFileTBX
            // 
            this.ctlShowWatermarkFileTBX.Location = new System.Drawing.Point(109, 290);
            this.ctlShowWatermarkFileTBX.Name = "ctlShowWatermarkFileTBX";
            this.ctlShowWatermarkFileTBX.Size = new System.Drawing.Size(116, 20);
            this.ctlShowWatermarkFileTBX.TabIndex = 9;
            // 
            // ctlShowWatermarkFileBTN
            // 
            this.ctlShowWatermarkFileBTN.Location = new System.Drawing.Point(53, 287);
            this.ctlShowWatermarkFileBTN.Name = "ctlShowWatermarkFileBTN";
            this.ctlShowWatermarkFileBTN.Size = new System.Drawing.Size(50, 25);
            this.ctlShowWatermarkFileBTN.TabIndex = 8;
            this.ctlShowWatermarkFileBTN.Text = "File ...";
            this.ctlShowWatermarkFileBTN.UseVisualStyleBackColor = true;
            this.ctlShowWatermarkFileBTN.Click += new System.EventHandler(this.ctlShowWatermarkFileBTN_Click);
            // 
            // ctlShowWatermarkTextLBL
            // 
            this.ctlShowWatermarkTextLBL.AutoSize = true;
            this.ctlShowWatermarkTextLBL.Location = new System.Drawing.Point(58, 271);
            this.ctlShowWatermarkTextLBL.Name = "ctlShowWatermarkTextLBL";
            this.ctlShowWatermarkTextLBL.Size = new System.Drawing.Size(28, 13);
            this.ctlShowWatermarkTextLBL.TabIndex = 26;
            this.ctlShowWatermarkTextLBL.Text = "Text";
            // 
            // ctlShowWatermarkTextTBX
            // 
            this.ctlShowWatermarkTextTBX.Location = new System.Drawing.Point(109, 268);
            this.ctlShowWatermarkTextTBX.Name = "ctlShowWatermarkTextTBX";
            this.ctlShowWatermarkTextTBX.Size = new System.Drawing.Size(116, 20);
            this.ctlShowWatermarkTextTBX.TabIndex = 7;
            // 
            // ctlShowWatermarkCHK
            // 
            this.ctlShowWatermarkCHK.AutoSize = true;
            this.ctlShowWatermarkCHK.Location = new System.Drawing.Point(24, 254);
            this.ctlShowWatermarkCHK.Name = "ctlShowWatermarkCHK";
            this.ctlShowWatermarkCHK.Size = new System.Drawing.Size(78, 17);
            this.ctlShowWatermarkCHK.TabIndex = 24;
            this.ctlShowWatermarkCHK.Text = "Watermark";
            this.ctlToolTip.SetToolTip(this.ctlShowWatermarkCHK, "Display watermark in the middle of the page");
            this.ctlShowWatermarkCHK.UseVisualStyleBackColor = true;
            // 
            // ctlShowPageNumberCHK
            // 
            this.ctlShowPageNumberCHK.AutoSize = true;
            this.ctlShowPageNumberCHK.Location = new System.Drawing.Point(24, 234);
            this.ctlShowPageNumberCHK.Name = "ctlShowPageNumberCHK";
            this.ctlShowPageNumberCHK.Size = new System.Drawing.Size(91, 17);
            this.ctlShowPageNumberCHK.TabIndex = 23;
            this.ctlShowPageNumberCHK.Text = "Page Number";
            this.ctlToolTip.SetToolTip(this.ctlShowPageNumberCHK, "Display page number in bottom margin");
            this.ctlShowPageNumberCHK.UseVisualStyleBackColor = true;
            // 
            // ctlShowTitleCHK
            // 
            this.ctlShowTitleCHK.AutoSize = true;
            this.ctlShowTitleCHK.Location = new System.Drawing.Point(24, 214);
            this.ctlShowTitleCHK.Name = "ctlShowTitleCHK";
            this.ctlShowTitleCHK.Size = new System.Drawing.Size(46, 17);
            this.ctlShowTitleCHK.TabIndex = 22;
            this.ctlShowTitleCHK.Text = "Title";
            this.ctlToolTip.SetToolTip(this.ctlShowTitleCHK, "Display Title in top margin");
            this.ctlShowTitleCHK.UseVisualStyleBackColor = true;
            // 
            // ctlShow_LBL
            // 
            this.ctlShow_LBL.AutoSize = true;
            this.ctlShow_LBL.Location = new System.Drawing.Point(16, 199);
            this.ctlShow_LBL.Name = "ctlShow_LBL";
            this.ctlShow_LBL.Size = new System.Drawing.Size(46, 13);
            this.ctlShow_LBL.TabIndex = 21;
            this.ctlShow_LBL.Text = "Show ...";
            // 
            // ctlViewCenterOnScreenCHK
            // 
            this.ctlViewCenterOnScreenCHK.AutoSize = true;
            this.ctlViewCenterOnScreenCHK.Location = new System.Drawing.Point(378, 141);
            this.ctlViewCenterOnScreenCHK.Name = "ctlViewCenterOnScreenCHK";
            this.ctlViewCenterOnScreenCHK.Size = new System.Drawing.Size(109, 17);
            this.ctlViewCenterOnScreenCHK.TabIndex = 25;
            this.ctlViewCenterOnScreenCHK.Text = "Center on Screen";
            this.ctlToolTip.SetToolTip(this.ctlViewCenterOnScreenCHK, "See iTextSharp Tutorial Chap 1");
            this.ctlViewCenterOnScreenCHK.UseVisualStyleBackColor = true;
            // 
            // ctlViewResizeToFitCHK
            // 
            this.ctlViewResizeToFitCHK.AutoSize = true;
            this.ctlViewResizeToFitCHK.Location = new System.Drawing.Point(378, 121);
            this.ctlViewResizeToFitCHK.Name = "ctlViewResizeToFitCHK";
            this.ctlViewResizeToFitCHK.Size = new System.Drawing.Size(126, 17);
            this.ctlViewResizeToFitCHK.TabIndex = 24;
            this.ctlViewResizeToFitCHK.Text = "Resize to Fit Window";
            this.ctlToolTip.SetToolTip(this.ctlViewResizeToFitCHK, "See iTextSharp Tutorial Chap 1");
            this.ctlViewResizeToFitCHK.UseVisualStyleBackColor = true;
            // 
            // ctlViewWindowUICHK
            // 
            this.ctlViewWindowUICHK.AutoSize = true;
            this.ctlViewWindowUICHK.Location = new System.Drawing.Point(378, 101);
            this.ctlViewWindowUICHK.Name = "ctlViewWindowUICHK";
            this.ctlViewWindowUICHK.Size = new System.Drawing.Size(79, 17);
            this.ctlViewWindowUICHK.TabIndex = 23;
            this.ctlViewWindowUICHK.Text = "Window UI";
            this.ctlToolTip.SetToolTip(this.ctlViewWindowUICHK, "See iTextSharp Tutorial Chap 1");
            this.ctlViewWindowUICHK.UseVisualStyleBackColor = true;
            // 
            // ctlView_LBL
            // 
            this.ctlView_LBL.AutoSize = true;
            this.ctlView_LBL.Location = new System.Drawing.Point(370, 24);
            this.ctlView_LBL.Name = "ctlView_LBL";
            this.ctlView_LBL.Size = new System.Drawing.Size(42, 13);
            this.ctlView_LBL.TabIndex = 19;
            this.ctlView_LBL.Text = "View ...";
            // 
            // ctlViewMenuBarCHK
            // 
            this.ctlViewMenuBarCHK.AutoSize = true;
            this.ctlViewMenuBarCHK.Location = new System.Drawing.Point(378, 81);
            this.ctlViewMenuBarCHK.Name = "ctlViewMenuBarCHK";
            this.ctlViewMenuBarCHK.Size = new System.Drawing.Size(71, 17);
            this.ctlViewMenuBarCHK.TabIndex = 22;
            this.ctlViewMenuBarCHK.Text = "Menu bar";
            this.ctlToolTip.SetToolTip(this.ctlViewMenuBarCHK, "See iTextSharp Tutorial Chap 1");
            this.ctlViewMenuBarCHK.UseVisualStyleBackColor = true;
            // 
            // ctlViewToolBarCHK
            // 
            this.ctlViewToolBarCHK.AutoSize = true;
            this.ctlViewToolBarCHK.Location = new System.Drawing.Point(378, 61);
            this.ctlViewToolBarCHK.Name = "ctlViewToolBarCHK";
            this.ctlViewToolBarCHK.Size = new System.Drawing.Size(65, 17);
            this.ctlViewToolBarCHK.TabIndex = 21;
            this.ctlViewToolBarCHK.Text = "Tool bar";
            this.ctlToolTip.SetToolTip(this.ctlViewToolBarCHK, "See iTextSharp Tutorial Chap 1");
            this.ctlViewToolBarCHK.UseVisualStyleBackColor = true;
            // 
            // ctlViewLayout2PageCHK
            // 
            this.ctlViewLayout2PageCHK.AutoSize = true;
            this.ctlViewLayout2PageCHK.Location = new System.Drawing.Point(378, 41);
            this.ctlViewLayout2PageCHK.Name = "ctlViewLayout2PageCHK";
            this.ctlViewLayout2PageCHK.Size = new System.Drawing.Size(98, 17);
            this.ctlViewLayout2PageCHK.TabIndex = 20;
            this.ctlViewLayout2PageCHK.Text = "2-Page Layout ";
            this.ctlToolTip.SetToolTip(this.ctlViewLayout2PageCHK, "See iTextSharp Tutorial Chap 1");
            this.ctlViewLayout2PageCHK.UseVisualStyleBackColor = true;
            // 
            // ctlEncrypt_PNL
            // 
            this.ctlEncrypt_PNL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctlEncrypt_PNL.Controls.Add(this.ctlEncryptPasswordsLBL);
            this.ctlEncrypt_PNL.Controls.Add(this.ctlEncrypt128BitCHK);
            this.ctlEncrypt_PNL.Controls.Add(this.ctlEncryptUserCanLBL);
            this.ctlEncrypt_PNL.Controls.Add(this.ctlEncryptAllowPrintDegradedCHK);
            this.ctlEncrypt_PNL.Controls.Add(this.ctlEncryptAllowAssemblyCHK);
            this.ctlEncrypt_PNL.Controls.Add(this.ctlEncryptAllowScreenReadersCHK);
            this.ctlEncrypt_PNL.Controls.Add(this.ctlEncryptAllowFillInCHK);
            this.ctlEncrypt_PNL.Controls.Add(this.ctlEncryptAllowModifyAnnotationsCHK);
            this.ctlEncrypt_PNL.Controls.Add(this.ctlEncryptAllowCopyingCHK);
            this.ctlEncrypt_PNL.Controls.Add(this.ctlEncryptAllowModifyContentsCHK);
            this.ctlEncrypt_PNL.Controls.Add(this.ctlEncryptAllowPrintingCHK);
            this.ctlEncrypt_PNL.Controls.Add(this.ctlEncryptPasswordOwnerTBX);
            this.ctlEncrypt_PNL.Controls.Add(this.ctlEncryptPasswordOwnerLBL);
            this.ctlEncrypt_PNL.Controls.Add(this.ctlEncryptPasswordUserTBX);
            this.ctlEncrypt_PNL.Controls.Add(this.ctlEncryptPasswordUserLBL);
            this.ctlEncrypt_PNL.Location = new System.Drawing.Point(332, 187);
            this.ctlEncrypt_PNL.Name = "ctlEncrypt_PNL";
            this.ctlEncrypt_PNL.Size = new System.Drawing.Size(172, 277);
            this.ctlEncrypt_PNL.TabIndex = 13;
            // 
            // ctlEncryptPasswordsLBL
            // 
            this.ctlEncryptPasswordsLBL.AutoSize = true;
            this.ctlEncryptPasswordsLBL.Location = new System.Drawing.Point(46, 12);
            this.ctlEncryptPasswordsLBL.Name = "ctlEncryptPasswordsLBL";
            this.ctlEncryptPasswordsLBL.Size = new System.Drawing.Size(58, 13);
            this.ctlEncryptPasswordsLBL.TabIndex = 14;
            this.ctlEncryptPasswordsLBL.Text = "Passwords";
            // 
            // ctlEncrypt128BitCHK
            // 
            this.ctlEncrypt128BitCHK.AutoSize = true;
            this.ctlEncrypt128BitCHK.Location = new System.Drawing.Point(13, 250);
            this.ctlEncrypt128BitCHK.Name = "ctlEncrypt128BitCHK";
            this.ctlEncrypt128BitCHK.Size = new System.Drawing.Size(110, 17);
            this.ctlEncrypt128BitCHK.TabIndex = 11;
            this.ctlEncrypt128BitCHK.Text = "Strong Encryption";
            this.ctlToolTip.SetToolTip(this.ctlEncrypt128BitCHK, "See iTextSharp Tutorial Chap 1");
            this.ctlEncrypt128BitCHK.UseVisualStyleBackColor = true;
            // 
            // ctlEncryptUserCanLBL
            // 
            this.ctlEncryptUserCanLBL.AutoSize = true;
            this.ctlEncryptUserCanLBL.Location = new System.Drawing.Point(10, 84);
            this.ctlEncryptUserCanLBL.Name = "ctlEncryptUserCanLBL";
            this.ctlEncryptUserCanLBL.Size = new System.Drawing.Size(37, 13);
            this.ctlEncryptUserCanLBL.TabIndex = 2;
            this.ctlEncryptUserCanLBL.Text = "can ...";
            // 
            // ctlEncryptAllowPrintDegradedCHK
            // 
            this.ctlEncryptAllowPrintDegradedCHK.AutoSize = true;
            this.ctlEncryptAllowPrintDegradedCHK.Location = new System.Drawing.Point(50, 104);
            this.ctlEncryptAllowPrintDegradedCHK.Name = "ctlEncryptAllowPrintDegradedCHK";
            this.ctlEncryptAllowPrintDegradedCHK.Size = new System.Drawing.Size(97, 17);
            this.ctlEncryptAllowPrintDegradedCHK.TabIndex = 4;
            this.ctlEncryptAllowPrintDegradedCHK.Text = "Print Degraded";
            this.ctlToolTip.SetToolTip(this.ctlEncryptAllowPrintDegradedCHK, "See iTextSharp Tutorial Chap 1");
            this.ctlEncryptAllowPrintDegradedCHK.UseVisualStyleBackColor = true;
            // 
            // ctlEncryptAllowAssemblyCHK
            // 
            this.ctlEncryptAllowAssemblyCHK.AutoSize = true;
            this.ctlEncryptAllowAssemblyCHK.Location = new System.Drawing.Point(50, 224);
            this.ctlEncryptAllowAssemblyCHK.Name = "ctlEncryptAllowAssemblyCHK";
            this.ctlEncryptAllowAssemblyCHK.Size = new System.Drawing.Size(71, 17);
            this.ctlEncryptAllowAssemblyCHK.TabIndex = 10;
            this.ctlEncryptAllowAssemblyCHK.Text = "Assemble";
            this.ctlToolTip.SetToolTip(this.ctlEncryptAllowAssemblyCHK, "See iTextSharp Tutorial Chap 1");
            this.ctlEncryptAllowAssemblyCHK.UseVisualStyleBackColor = true;
            // 
            // ctlEncryptAllowScreenReadersCHK
            // 
            this.ctlEncryptAllowScreenReadersCHK.AutoSize = true;
            this.ctlEncryptAllowScreenReadersCHK.Location = new System.Drawing.Point(50, 204);
            this.ctlEncryptAllowScreenReadersCHK.Name = "ctlEncryptAllowScreenReadersCHK";
            this.ctlEncryptAllowScreenReadersCHK.Size = new System.Drawing.Size(89, 17);
            this.ctlEncryptAllowScreenReadersCHK.TabIndex = 9;
            this.ctlEncryptAllowScreenReadersCHK.Text = "Screen Read";
            this.ctlToolTip.SetToolTip(this.ctlEncryptAllowScreenReadersCHK, "See iTextSharp Tutorial Chap 1");
            this.ctlEncryptAllowScreenReadersCHK.UseVisualStyleBackColor = true;
            // 
            // ctlEncryptAllowFillInCHK
            // 
            this.ctlEncryptAllowFillInCHK.AutoSize = true;
            this.ctlEncryptAllowFillInCHK.Location = new System.Drawing.Point(50, 184);
            this.ctlEncryptAllowFillInCHK.Name = "ctlEncryptAllowFillInCHK";
            this.ctlEncryptAllowFillInCHK.Size = new System.Drawing.Size(50, 17);
            this.ctlEncryptAllowFillInCHK.TabIndex = 8;
            this.ctlEncryptAllowFillInCHK.Text = "Fill In";
            this.ctlToolTip.SetToolTip(this.ctlEncryptAllowFillInCHK, "See iTextSharp Tutorial Chap 1");
            this.ctlEncryptAllowFillInCHK.UseVisualStyleBackColor = true;
            // 
            // ctlEncryptAllowModifyAnnotationsCHK
            // 
            this.ctlEncryptAllowModifyAnnotationsCHK.AutoSize = true;
            this.ctlEncryptAllowModifyAnnotationsCHK.Location = new System.Drawing.Point(50, 164);
            this.ctlEncryptAllowModifyAnnotationsCHK.Name = "ctlEncryptAllowModifyAnnotationsCHK";
            this.ctlEncryptAllowModifyAnnotationsCHK.Size = new System.Drawing.Size(116, 17);
            this.ctlEncryptAllowModifyAnnotationsCHK.TabIndex = 7;
            this.ctlEncryptAllowModifyAnnotationsCHK.Text = "Modify Annotations";
            this.ctlToolTip.SetToolTip(this.ctlEncryptAllowModifyAnnotationsCHK, "See iTextSharp Tutorial Chap 1");
            this.ctlEncryptAllowModifyAnnotationsCHK.UseVisualStyleBackColor = true;
            // 
            // ctlEncryptAllowCopyingCHK
            // 
            this.ctlEncryptAllowCopyingCHK.AutoSize = true;
            this.ctlEncryptAllowCopyingCHK.Location = new System.Drawing.Point(50, 144);
            this.ctlEncryptAllowCopyingCHK.Name = "ctlEncryptAllowCopyingCHK";
            this.ctlEncryptAllowCopyingCHK.Size = new System.Drawing.Size(50, 17);
            this.ctlEncryptAllowCopyingCHK.TabIndex = 6;
            this.ctlEncryptAllowCopyingCHK.Text = "Copy";
            this.ctlToolTip.SetToolTip(this.ctlEncryptAllowCopyingCHK, "See iTextSharp Tutorial Chap 1");
            this.ctlEncryptAllowCopyingCHK.UseVisualStyleBackColor = true;
            // 
            // ctlEncryptAllowModifyContentsCHK
            // 
            this.ctlEncryptAllowModifyContentsCHK.AutoSize = true;
            this.ctlEncryptAllowModifyContentsCHK.Location = new System.Drawing.Point(50, 124);
            this.ctlEncryptAllowModifyContentsCHK.Name = "ctlEncryptAllowModifyContentsCHK";
            this.ctlEncryptAllowModifyContentsCHK.Size = new System.Drawing.Size(105, 17);
            this.ctlEncryptAllowModifyContentsCHK.TabIndex = 5;
            this.ctlEncryptAllowModifyContentsCHK.Text = "Modify Contents ";
            this.ctlToolTip.SetToolTip(this.ctlEncryptAllowModifyContentsCHK, "See iTextSharp Tutorial Chap 1");
            this.ctlEncryptAllowModifyContentsCHK.UseVisualStyleBackColor = true;
            // 
            // ctlEncryptAllowPrintingCHK
            // 
            this.ctlEncryptAllowPrintingCHK.AutoSize = true;
            this.ctlEncryptAllowPrintingCHK.Location = new System.Drawing.Point(50, 84);
            this.ctlEncryptAllowPrintingCHK.Name = "ctlEncryptAllowPrintingCHK";
            this.ctlEncryptAllowPrintingCHK.Size = new System.Drawing.Size(47, 17);
            this.ctlEncryptAllowPrintingCHK.TabIndex = 3;
            this.ctlEncryptAllowPrintingCHK.Text = "Print";
            this.ctlToolTip.SetToolTip(this.ctlEncryptAllowPrintingCHK, "See iTextSharp Tutorial Chap 1");
            this.ctlEncryptAllowPrintingCHK.UseVisualStyleBackColor = true;
            // 
            // ctlEncryptPasswordOwnerTBX
            // 
            this.ctlEncryptPasswordOwnerTBX.Location = new System.Drawing.Point(49, 35);
            this.ctlEncryptPasswordOwnerTBX.Name = "ctlEncryptPasswordOwnerTBX";
            this.ctlEncryptPasswordOwnerTBX.PasswordChar = '*';
            this.ctlEncryptPasswordOwnerTBX.Size = new System.Drawing.Size(100, 20);
            this.ctlEncryptPasswordOwnerTBX.TabIndex = 0;
            this.ctlToolTip.SetToolTip(this.ctlEncryptPasswordOwnerTBX, "See iTextSharp Tutorial Chap 1");
            // 
            // ctlEncryptPasswordOwnerLBL
            // 
            this.ctlEncryptPasswordOwnerLBL.AutoSize = true;
            this.ctlEncryptPasswordOwnerLBL.Location = new System.Drawing.Point(10, 38);
            this.ctlEncryptPasswordOwnerLBL.Name = "ctlEncryptPasswordOwnerLBL";
            this.ctlEncryptPasswordOwnerLBL.Size = new System.Drawing.Size(38, 13);
            this.ctlEncryptPasswordOwnerLBL.TabIndex = 2;
            this.ctlEncryptPasswordOwnerLBL.Text = "Owner";
            // 
            // ctlEncryptPasswordUserTBX
            // 
            this.ctlEncryptPasswordUserTBX.Location = new System.Drawing.Point(49, 58);
            this.ctlEncryptPasswordUserTBX.Name = "ctlEncryptPasswordUserTBX";
            this.ctlEncryptPasswordUserTBX.Size = new System.Drawing.Size(100, 20);
            this.ctlEncryptPasswordUserTBX.TabIndex = 1;
            this.ctlToolTip.SetToolTip(this.ctlEncryptPasswordUserTBX, "See iTextSharp Tutorial Chap 1");
            // 
            // ctlEncryptPasswordUserLBL
            // 
            this.ctlEncryptPasswordUserLBL.AutoSize = true;
            this.ctlEncryptPasswordUserLBL.Location = new System.Drawing.Point(10, 61);
            this.ctlEncryptPasswordUserLBL.Name = "ctlEncryptPasswordUserLBL";
            this.ctlEncryptPasswordUserLBL.Size = new System.Drawing.Size(29, 13);
            this.ctlEncryptPasswordUserLBL.TabIndex = 0;
            this.ctlEncryptPasswordUserLBL.Text = "User";
            // 
            // ctlPdfHeaderEncryptCHK
            // 
            this.ctlPdfHeaderEncryptCHK.AutoSize = true;
            this.ctlPdfHeaderEncryptCHK.Location = new System.Drawing.Point(378, 164);
            this.ctlPdfHeaderEncryptCHK.Name = "ctlPdfHeaderEncryptCHK";
            this.ctlPdfHeaderEncryptCHK.Size = new System.Drawing.Size(62, 17);
            this.ctlPdfHeaderEncryptCHK.TabIndex = 26;
            this.ctlPdfHeaderEncryptCHK.Text = "Encrypt";
            this.ctlToolTip.SetToolTip(this.ctlPdfHeaderEncryptCHK, "See iTextSharp Tutorial Chap 1");
            this.ctlPdfHeaderEncryptCHK.UseVisualStyleBackColor = true;
            this.ctlPdfHeaderEncryptCHK.CheckedChanged += new System.EventHandler(this.ctlPdfHeaderEncryptCHK_CheckedChanged);
            // 
            // ctlPdfHeaderDefaultsBTN
            // 
            this.ctlPdfHeaderDefaultsBTN.Location = new System.Drawing.Point(260, 10);
            this.ctlPdfHeaderDefaultsBTN.Name = "ctlPdfHeaderDefaultsBTN";
            this.ctlPdfHeaderDefaultsBTN.Size = new System.Drawing.Size(75, 24);
            this.ctlPdfHeaderDefaultsBTN.TabIndex = 1;
            this.ctlPdfHeaderDefaultsBTN.Text = "Defaults";
            this.ctlToolTip.SetToolTip(this.ctlPdfHeaderDefaultsBTN, "Populate options with illustrative default values");
            this.ctlPdfHeaderDefaultsBTN.UseVisualStyleBackColor = true;
            this.ctlPdfHeaderDefaultsBTN.Click += new System.EventHandler(this.ctlPdfHeaderDefaultsBTN_Click);
            // 
            // ctlPdfHeaderKeywordsTBX
            // 
            this.ctlPdfHeaderKeywordsTBX.Location = new System.Drawing.Point(79, 158);
            this.ctlPdfHeaderKeywordsTBX.Name = "ctlPdfHeaderKeywordsTBX";
            this.ctlPdfHeaderKeywordsTBX.Size = new System.Drawing.Size(256, 20);
            this.ctlPdfHeaderKeywordsTBX.TabIndex = 6;
            this.ctlToolTip.SetToolTip(this.ctlPdfHeaderKeywordsTBX, "Keywords of PDF file (displayed in the Document Properties)");
            // 
            // ctlPdfHeaderKeywordsLBL
            // 
            this.ctlPdfHeaderKeywordsLBL.AutoSize = true;
            this.ctlPdfHeaderKeywordsLBL.Location = new System.Drawing.Point(17, 161);
            this.ctlPdfHeaderKeywordsLBL.Name = "ctlPdfHeaderKeywordsLBL";
            this.ctlPdfHeaderKeywordsLBL.Size = new System.Drawing.Size(53, 13);
            this.ctlPdfHeaderKeywordsLBL.TabIndex = 9;
            this.ctlPdfHeaderKeywordsLBL.Text = "Keywords";
            // 
            // ctlPdfHeaderAuthorTBX
            // 
            this.ctlPdfHeaderAuthorTBX.Location = new System.Drawing.Point(79, 127);
            this.ctlPdfHeaderAuthorTBX.Name = "ctlPdfHeaderAuthorTBX";
            this.ctlPdfHeaderAuthorTBX.Size = new System.Drawing.Size(256, 20);
            this.ctlPdfHeaderAuthorTBX.TabIndex = 5;
            this.ctlToolTip.SetToolTip(this.ctlPdfHeaderAuthorTBX, "Author of PDF file (displayed in the Document Properties)");
            // 
            // ctlPdfHeaderAuthorLBL
            // 
            this.ctlPdfHeaderAuthorLBL.AutoSize = true;
            this.ctlPdfHeaderAuthorLBL.Location = new System.Drawing.Point(17, 130);
            this.ctlPdfHeaderAuthorLBL.Name = "ctlPdfHeaderAuthorLBL";
            this.ctlPdfHeaderAuthorLBL.Size = new System.Drawing.Size(38, 13);
            this.ctlPdfHeaderAuthorLBL.TabIndex = 7;
            this.ctlPdfHeaderAuthorLBL.Text = "Author";
            // 
            // ctlPdfHeaderSubjectTBX
            // 
            this.ctlPdfHeaderSubjectTBX.Location = new System.Drawing.Point(79, 97);
            this.ctlPdfHeaderSubjectTBX.Name = "ctlPdfHeaderSubjectTBX";
            this.ctlPdfHeaderSubjectTBX.Size = new System.Drawing.Size(256, 20);
            this.ctlPdfHeaderSubjectTBX.TabIndex = 4;
            this.ctlToolTip.SetToolTip(this.ctlPdfHeaderSubjectTBX, "Subject of PDF file (displayed in the Document Properties)");
            // 
            // ctlPdfHeaderSubjectLBL
            // 
            this.ctlPdfHeaderSubjectLBL.AutoSize = true;
            this.ctlPdfHeaderSubjectLBL.Location = new System.Drawing.Point(17, 100);
            this.ctlPdfHeaderSubjectLBL.Name = "ctlPdfHeaderSubjectLBL";
            this.ctlPdfHeaderSubjectLBL.Size = new System.Drawing.Size(43, 13);
            this.ctlPdfHeaderSubjectLBL.TabIndex = 5;
            this.ctlPdfHeaderSubjectLBL.Text = "Subject";
            // 
            // ctlPdfHeaderTitleTBX
            // 
            this.ctlPdfHeaderTitleTBX.Location = new System.Drawing.Point(79, 67);
            this.ctlPdfHeaderTitleTBX.Name = "ctlPdfHeaderTitleTBX";
            this.ctlPdfHeaderTitleTBX.Size = new System.Drawing.Size(256, 20);
            this.ctlPdfHeaderTitleTBX.TabIndex = 3;
            this.ctlToolTip.SetToolTip(this.ctlPdfHeaderTitleTBX, "Title of PDF file (displayed in the Document Properties)");
            // 
            // ctlPdfHeaderTitleLBL
            // 
            this.ctlPdfHeaderTitleLBL.AutoSize = true;
            this.ctlPdfHeaderTitleLBL.Location = new System.Drawing.Point(17, 70);
            this.ctlPdfHeaderTitleLBL.Name = "ctlPdfHeaderTitleLBL";
            this.ctlPdfHeaderTitleLBL.Size = new System.Drawing.Size(27, 13);
            this.ctlPdfHeaderTitleLBL.TabIndex = 3;
            this.ctlPdfHeaderTitleLBL.Text = "Title";
            // 
            // ctlPdfHeaderFileTBX
            // 
            this.ctlPdfHeaderFileTBX.Enabled = false;
            this.ctlPdfHeaderFileTBX.Location = new System.Drawing.Point(79, 37);
            this.ctlPdfHeaderFileTBX.Name = "ctlPdfHeaderFileTBX";
            this.ctlPdfHeaderFileTBX.Size = new System.Drawing.Size(256, 20);
            this.ctlPdfHeaderFileTBX.TabIndex = 2;
            this.ctlToolTip.SetToolTip(this.ctlPdfHeaderFileTBX, "Name of PDF file (displayed in the Document Properties)");
            // 
            // ctlPdfHeaderFileLBL
            // 
            this.ctlPdfHeaderFileLBL.AutoSize = true;
            this.ctlPdfHeaderFileLBL.Enabled = false;
            this.ctlPdfHeaderFileLBL.Location = new System.Drawing.Point(17, 40);
            this.ctlPdfHeaderFileLBL.Name = "ctlPdfHeaderFileLBL";
            this.ctlPdfHeaderFileLBL.Size = new System.Drawing.Size(23, 13);
            this.ctlPdfHeaderFileLBL.TabIndex = 1;
            this.ctlPdfHeaderFileLBL.Text = "File";
            // 
            // ctlPdfHeaderLBL
            // 
            this.ctlPdfHeaderLBL.AutoSize = true;
            this.ctlPdfHeaderLBL.Location = new System.Drawing.Point(17, 15);
            this.ctlPdfHeaderLBL.Name = "ctlPdfHeaderLBL";
            this.ctlPdfHeaderLBL.Size = new System.Drawing.Size(126, 13);
            this.ctlPdfHeaderLBL.TabIndex = 0;
            this.ctlPdfHeaderLBL.Text = "PDF Document Summary";
            // 
            // ctlTutorialChap1202BTN
            // 
            this.ctlTutorialChap1202BTN.Enabled = false;
            this.ctlTutorialChap1202BTN.Location = new System.Drawing.Point(28, 363);
            this.ctlTutorialChap1202BTN.Name = "ctlTutorialChap1202BTN";
            this.ctlTutorialChap1202BTN.Size = new System.Drawing.Size(132, 23);
            this.ctlTutorialChap1202BTN.TabIndex = 2;
            this.ctlTutorialChap1202BTN.Text = "Chap1202";
            this.ctlTutorialChap1202BTN.UseVisualStyleBackColor = true;
            this.ctlTutorialChap1202BTN.Click += new System.EventHandler(this.ctlTutorialChap1202BTN_Click);
            // 
            // ctlSrcXmlStoreBTN
            // 
            this.ctlSrcXmlStoreBTN.Location = new System.Drawing.Point(28, 22);
            this.ctlSrcXmlStoreBTN.Name = "ctlSrcXmlStoreBTN";
            this.ctlSrcXmlStoreBTN.Size = new System.Drawing.Size(132, 23);
            this.ctlSrcXmlStoreBTN.TabIndex = 0;
            this.ctlSrcXmlStoreBTN.Text = "XmlStore File ...";
            this.ctlToolTip.SetToolTip(this.ctlSrcXmlStoreBTN, "Open an XML file (and immediately create a PDF using the current options)");
            this.ctlSrcXmlStoreBTN.UseVisualStyleBackColor = true;
            this.ctlSrcXmlStoreBTN.Click += new System.EventHandler(this.ctlSrcXmlStoreBTN_Click);
            // 
            // ctlTutorialChap0518BTN
            // 
            this.ctlTutorialChap0518BTN.Enabled = false;
            this.ctlTutorialChap0518BTN.Location = new System.Drawing.Point(28, 296);
            this.ctlTutorialChap0518BTN.Name = "ctlTutorialChap0518BTN";
            this.ctlTutorialChap0518BTN.Size = new System.Drawing.Size(132, 23);
            this.ctlTutorialChap0518BTN.TabIndex = 1;
            this.ctlTutorialChap0518BTN.Text = "Chap0518";
            this.ctlTutorialChap0518BTN.UseVisualStyleBackColor = true;
            this.ctlTutorialChap0518BTN.Click += new System.EventHandler(this.ctlTutorialChap0518BTN_Click);
            // 
            // ctlPdfOutputTABPAGE
            // 
            this.ctlPdfOutputTABPAGE.Controls.Add(this.ctlPdfBrowser);
            this.ctlPdfOutputTABPAGE.Location = new System.Drawing.Point(4, 22);
            this.ctlPdfOutputTABPAGE.Name = "ctlPdfOutputTABPAGE";
            this.ctlPdfOutputTABPAGE.Padding = new System.Windows.Forms.Padding(3);
            this.ctlPdfOutputTABPAGE.Size = new System.Drawing.Size(705, 490);
            this.ctlPdfOutputTABPAGE.TabIndex = 0;
            this.ctlPdfOutputTABPAGE.Text = "Resulting PDF";
            this.ctlPdfOutputTABPAGE.UseVisualStyleBackColor = true;
            // 
            // ctlPdfBrowser
            // 
            this.ctlPdfBrowser.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ctlPdfBrowser.Location = new System.Drawing.Point(6, 6);
            this.ctlPdfBrowser.MinimumSize = new System.Drawing.Size(20, 20);
            this.ctlPdfBrowser.Name = "ctlPdfBrowser";
            this.ctlPdfBrowser.Size = new System.Drawing.Size(693, 478);
            this.ctlPdfBrowser.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(737, 611);
            this.Controls.Add(this.ctlPdfTABS);
            this.Controls.Add(this.ctlMainMenuStrip_MNU);
            this.Controls.Add(this.ctlInfoLBL);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Shown += new System.EventHandler(this.OnFormShown);
            this.ctlMainMenuStrip_MNU.ResumeLayout(false);
            this.ctlMainMenuStrip_MNU.PerformLayout();
            this.ctlPdfTABS.ResumeLayout(false);
            this.ctlPdfInfoTABPAGE.ResumeLayout(false);
            this.ctlPdfInputsTABPAGE.ResumeLayout(false);
            this.ctlPdfInputsTABPAGE.PerformLayout();
            this.ctlPdfHeaderPNL.ResumeLayout(false);
            this.ctlPdfHeaderPNL.PerformLayout();
            this.ctlEncrypt_PNL.ResumeLayout(false);
            this.ctlEncrypt_PNL.PerformLayout();
            this.ctlPdfOutputTABPAGE.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ctlInfoLBL;
        private System.Windows.Forms.MenuStrip ctlMainMenuStrip_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlFile_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlFileExitMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlHelp_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlHelpTutorialHomeMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlAdobePdfSpec_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlAdobePdfSpec17MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlAdobePdfSpec16MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlAdobePdfSpec15MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlAdobePdfSpec14MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlAdobePdfSpec13MNU;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem ctlAdobePdfSpecTechCenterMNU;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ctlHelpAboutMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlBrowserBackMNU;
        private System.Windows.Forms.TabControl ctlPdfTABS;
        private System.Windows.Forms.TabPage ctlPdfOutputTABPAGE;
        private System.Windows.Forms.WebBrowser ctlPdfBrowser;
        private System.Windows.Forms.TabPage ctlPdfInputsTABPAGE;
        private System.Windows.Forms.TabPage ctlPdfInfoTABPAGE;
        private System.Windows.Forms.WebBrowser ctlInfoBrowser;
        private System.Windows.Forms.Button ctlTutorialChap0518BTN;
        private System.Windows.Forms.Button ctlSrcXmlStoreBTN;
        private System.Windows.Forms.Button ctlTutorialChap1202BTN;
        private System.Windows.Forms.Panel ctlPdfHeaderPNL;
        private System.Windows.Forms.Label ctlPdfHeaderFileLBL;
        private System.Windows.Forms.Label ctlPdfHeaderLBL;
        private System.Windows.Forms.TextBox ctlPdfHeaderKeywordsTBX;
        private System.Windows.Forms.Label ctlPdfHeaderKeywordsLBL;
        private System.Windows.Forms.TextBox ctlPdfHeaderAuthorTBX;
        private System.Windows.Forms.Label ctlPdfHeaderAuthorLBL;
        private System.Windows.Forms.TextBox ctlPdfHeaderSubjectTBX;
        private System.Windows.Forms.Label ctlPdfHeaderSubjectLBL;
        private System.Windows.Forms.TextBox ctlPdfHeaderTitleTBX;
        private System.Windows.Forms.Label ctlPdfHeaderTitleLBL;
        private System.Windows.Forms.TextBox ctlPdfHeaderFileTBX;
        private System.Windows.Forms.CheckBox ctlITextSharpTutorialsCHK;
        private System.Windows.Forms.Button ctlPdfHeaderDefaultsBTN;
        private System.Windows.Forms.Panel ctlEncrypt_PNL;
        private System.Windows.Forms.CheckBox ctlPdfHeaderEncryptCHK;
        private System.Windows.Forms.TextBox ctlEncryptPasswordOwnerTBX;
        private System.Windows.Forms.Label ctlEncryptPasswordOwnerLBL;
        private System.Windows.Forms.TextBox ctlEncryptPasswordUserTBX;
        private System.Windows.Forms.Label ctlEncryptPasswordUserLBL;
        private System.Windows.Forms.ToolTip ctlToolTip;
        private System.Windows.Forms.CheckBox ctlEncryptAllowPrintDegradedCHK;
        private System.Windows.Forms.CheckBox ctlEncryptAllowAssemblyCHK;
        private System.Windows.Forms.CheckBox ctlEncryptAllowScreenReadersCHK;
        private System.Windows.Forms.CheckBox ctlEncryptAllowFillInCHK;
        private System.Windows.Forms.CheckBox ctlEncryptAllowModifyAnnotationsCHK;
        private System.Windows.Forms.CheckBox ctlEncryptAllowCopyingCHK;
        private System.Windows.Forms.CheckBox ctlEncryptAllowModifyContentsCHK;
        private System.Windows.Forms.CheckBox ctlEncryptAllowPrintingCHK;
        private System.Windows.Forms.CheckBox ctlEncrypt128BitCHK;
        private System.Windows.Forms.Label ctlEncryptUserCanLBL;
        private System.Windows.Forms.CheckBox ctlViewToolBarCHK;
        private System.Windows.Forms.CheckBox ctlViewLayout2PageCHK;
        private System.Windows.Forms.CheckBox ctlViewCenterOnScreenCHK;
        private System.Windows.Forms.CheckBox ctlViewResizeToFitCHK;
        private System.Windows.Forms.CheckBox ctlViewWindowUICHK;
        private System.Windows.Forms.Label ctlView_LBL;
        private System.Windows.Forms.CheckBox ctlViewMenuBarCHK;
        private System.Windows.Forms.CheckBox ctlShowPageNumberCHK;
        private System.Windows.Forms.CheckBox ctlShowTitleCHK;
        private System.Windows.Forms.Label ctlShow_LBL;
        private System.Windows.Forms.Button ctlShowWatermarkFileBTN;
        private System.Windows.Forms.Label ctlShowWatermarkTextLBL;
        private System.Windows.Forms.TextBox ctlShowWatermarkTextTBX;
        private System.Windows.Forms.CheckBox ctlShowWatermarkCHK;
        private System.Windows.Forms.TextBox ctlShowWatermarkFileTBX;
        private System.Windows.Forms.ComboBox ctlShowSizeCBX;
        private System.Windows.Forms.CheckBox ctlShowLandscapeCHK;
        private System.Windows.Forms.Label ctlTypeFaceLBL;
        private System.Windows.Forms.TextBox ctlFontBodyTypeSizeTBX;
        private System.Windows.Forms.Label ctlTypeSizeLBL;
        private System.Windows.Forms.ComboBox ctlFontBodyTypeFaceCBX;
        private System.Windows.Forms.CheckBox ctlFontBodyTypeStyleItalicsCHK;
        private System.Windows.Forms.CheckBox ctlFontBodyTypeStyleBoldCHK;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ctlFontHeaderTypeSizeTBX;
        private System.Windows.Forms.ComboBox ctlFontHeaderTypeFaceCBX;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label ctlFontBodyLBL;
        private System.Windows.Forms.CheckBox ctlFontHeaderTypeStyleItalicsCHK;
        private System.Windows.Forms.CheckBox ctlFontHeaderTypeStyleBoldCHK;
        private System.Windows.Forms.Label ctlEncryptPasswordsLBL;
        private System.Windows.Forms.Button ctlTutorialChap1011BTN;
        private System.Windows.Forms.Label ctlScale_LBL;
        private System.Windows.Forms.TextBox ctlScaleWidthsTBX;
        private System.Windows.Forms.Label ctlScaleWidthsLBL;
        private System.Windows.Forms.ToolStripMenuItem ctlHelpOnThisAppMNU;
    }
}

