using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.IO;
using VVX;

namespace iTextSharpExpt
{
    public partial class Form1 : Form
    {
        private string msAppName = "iTextSharp Tutorials 2 ";
        VVX.PDF mPDF = new PDF();
        string msFilePDF = "";
        string msDataFolder = "";
        string msInfoFile = "";

        public Form1()
        {
            InitializeComponent();

            //--- init the Data folder 
            //    (source of XML files and in which generated PDF's will be saved)
            this.DoInitDataFolder();

            //--- turn off encrypt option
            this.DoEnableEncryptionOptions(false);

            //--- init combo boxes
            this.DoInitPaperSizes(this.ctlShowSizeCBX);
            this.DoInitTypeFaces(this.ctlFontBodyTypeFaceCBX);
            this.DoInitTypeFaces(this.ctlFontHeaderTypeFaceCBX);

            //--- refresh the form caption
            this.DoUpdateCaption();

            //--- set the "Help" menu item for this solution
            this.ctlHelpOnThisAppMNU.Text = "On this solution";
        }
        
        private void OnFormShown(object sender, EventArgs e)
        {
            this.DoNavigateToInfoPage();
            VVX.About.Show();   //OK to comment this out.
        }

        #region General Purpose Helpers for this Form

        private void DoInitDataFolder()
        {
            msDataFolder = Application.ExecutablePath;
            int n = msDataFolder.LastIndexOf(@"\");
            msDataFolder = msDataFolder.Substring(0, n + 1);
            msDataFolder = msDataFolder.Replace(@"bin\Release", "Data");
            msDataFolder = msDataFolder.Replace(@"bin\Debug", "Data");
        }

        private void ctlBrowserBackMNU_Click(object sender, EventArgs e)
        {
            if (this.ctlPdfTABS.SelectedIndex == 0)
            {
                if (this.ctlInfoBrowser.CanGoBack)
                    this.ctlInfoBrowser.GoBack();
                else
                    this.DoNavigateToInfoPage();
            }
            if (this.ctlPdfTABS.SelectedIndex == 0)
            {
                if (this.ctlInfoBrowser.CanGoBack)
                    this.ctlInfoBrowser.GoBack();
                else
                    this.DoNavigateToInfoPage();
            }
        }

        //************************************************************
        /// <summary>
        /// Refreshes the window's Caption/Title bar
        /// </summary>
        private void DoUpdateCaption()
        {
            this.Text = this.msAppName;

            if (this.msFilePDF.Length == 0)
            {
                this.Text += "<no PDF file create>";
            }
            else
            {
                FileInfo fi = new FileInfo(this.msFilePDF);
                this.Text += @"...\" + fi.Name;
            }
        }


        #endregion //General Purpose Helpers for this Form

        #region Show PDF Helpers for Tutorial Chapters
        private string DoGetURI(string sFile)
        {
            string sRet = msDataFolder + sFile;

            return sRet;
        }

        private void DoShowPDF(string sFilePDF)
        {
            this.DoUpdateCaption();
            this.ctlPdfBrowser.Navigate(DoGetURI(sFilePDF));
        }
        #endregion //Show PDF Helpers for Tutorial Chapters

        #region Help Event Handlers

        private void ctlHelpAboutMNU_Click(object sender, EventArgs e)
        {
            VVX.About.Show();
        }

        private void ctlHelpOnThisAppMNU_Click(object sender, EventArgs e)
        {
            DoNavigateToInfoPage();
            this.ctlPdfTABS.SelectedIndex = 0;
        }

        private void ctlHelpTutorialHomeMNU_Click(object sender, EventArgs e)
        {
            this.DoShowInInfoTab("http://itextsharp.sourceforge.net/tutorial/index.html", true);
        }

        #region Help Event Handlers Adobe
        private void ctlAdobePdfSpecTechCenterMNU_Click(object sender, EventArgs e)
        {
            this.DoShowInInfoTab("http://www.adobe.com/devnet/pdf/pdf_reference.html", true);
        }

        private void DoOpenLocalCopy(string sPdfSpecFile)
        {
            FileInfo fi = new FileInfo(sPdfSpecFile);
            if (fi.Exists)
            {
                this.DoShowInInfoTab(sPdfSpecFile, true);
            }
            else
            {
                if (MsgBox.Confirm("Requested file not found. \n\nTry Adobe's Technology Center?"))
                {
                    this.ctlInfoBrowser.Navigate("http://www.adobe.com/devnet/pdf/pdf_reference.html");
                    this.ctlPdfTABS.SelectedIndex = 0;
                }
            }
        }

        private void ctlAdobePdfSpec13MNU_Click(object sender, EventArgs e)
        {
            string sPdfSpecFile = @"D:\Work\Xpt\VVX_PdfLibrary\PDFReference13.pdf";
            this.DoOpenLocalCopy(sPdfSpecFile);
        }

        private void ctlAdobePdfSpec14MNU_Click(object sender, EventArgs e)
        {
            string sPdfSpecFile = @"D:\Work\Xpt\VVX_PdfLibrary\PDFReference14.pdf";
            this.DoOpenLocalCopy(sPdfSpecFile);
        }

        private void ctlAdobePdfSpec15MNU_Click(object sender, EventArgs e)
        {
            string sPdfSpecFile = @"D:\Work\Xpt\VVX_PdfLibrary\PDFReference15_v6.pdf";
            this.DoOpenLocalCopy(sPdfSpecFile);
        }

        private void ctlAdobePdfSpec16MNU_Click(object sender, EventArgs e)
        {
            string sPdfSpecFile = @"D:\Work\Xpt\VVX_PdfLibrary\PDFReference16.pdf";
            this.DoOpenLocalCopy(sPdfSpecFile);
        }

        private void ctlAdobePdfSpec17MNU_Click(object sender, EventArgs e)
        {
            string sPdfSpecFile = @"D:\Work\Xpt\VVX_PdfLibrary\PDF_Reference.pdf";
            this.DoOpenLocalCopy(sPdfSpecFile);
        }
        #endregion //Help Event Handlers Adobe
        #endregion //Help Event Handlers

        #region Helpers for 'Info' Tab
        /// <summary>
        /// Moves up the directory tree and locates the info HTML file
        /// </summary>
        private void DoNavigateToInfoPage()
        {
            if (this.msInfoFile.Length == 0 && VVX.File.Exists(this.msInfoFile) == false)
            {
                msInfoFile = "iTextSharpPdfTables.html";

                string sPath = msInfoFile;
                for (int i = 0; i < 6; i++)
                {
                    if (VVX.File.Exists(sPath))
                    {
                        FileInfo fi = new FileInfo(sPath);
                        this.ctlInfoBrowser.Navigate(fi.FullName);
                        this.msInfoFile = fi.FullName;
                        break;
                    }
                    sPath = @"..\" + sPath;
                }
            }
            else
            {
                this.ctlInfoBrowser.Navigate(this.msInfoFile);
            }
        }

        /// <summary>
        /// Displays the URL in the Info Tab's browser
        /// </summary>
        /// <param name="sURL">URL or fully qualified file name</param>
        /// <param name="bSwitchToInfoTab">uf 'true', switches to the Info Tab</param>
        private void DoShowInInfoTab(string sURL, bool bSwitchToInfoTab)
        {
            this.ctlInfoBrowser.Navigate(sURL);
            if (bSwitchToInfoTab)
                this.ctlPdfTABS.SelectedIndex = 0;
        }
        #endregion //Helpers for 'Info' Tab

        #region Helpers for 'Selections' Tab

        private void DoPreProcess(object sender, EventArgs e)
        {
            if (true)
            {
                this.mPDF.DocAuthor = this.ctlPdfHeaderAuthorTBX.Text;
                this.mPDF.DocKeywords= this.ctlPdfHeaderKeywordsTBX.Text;
                this.mPDF.DocSubject = this.ctlPdfHeaderSubjectTBX.Text;
                this.mPDF.DocTitle = this.ctlPdfHeaderTitleTBX.Text;
                //--- View options
                this.mPDF.View2PageLayout = this.ctlViewLayout2PageCHK.Checked;
                this.mPDF.ViewToolbar = this.ctlViewToolBarCHK.Checked;
                this.mPDF.ViewMenubar = this.ctlViewMenuBarCHK.Checked;
                this.mPDF.ViewWindowUI = this.ctlViewWindowUICHK.Checked;
                this.mPDF.ViewResizeToFit = this.ctlViewResizeToFitCHK.Checked;
                this.mPDF.ViewCenterOnScreen = this.ctlViewCenterOnScreenCHK.Checked;
                //--- Show options
                this.mPDF.ShowPageNumber = this.ctlShowPageNumberCHK.Checked;
                this.mPDF.ShowTitle = this.ctlShowTitleCHK.Checked;
                this.mPDF.ShowWatermark = this.ctlShowWatermarkCHK.Checked;
                this.mPDF.ShowWatermarkText = this.ctlShowWatermarkTextTBX.Text;
                this.mPDF.ShowWatermarkFile = this.ctlShowWatermarkFileTBX.Text;
                this.mPDF.ShowLandscape = this.ctlShowLandscapeCHK.Checked;
                this.mPDF.ShowPaperSize = (VVX.PDF.PaperSize)this.ctlShowSizeCBX.SelectedIndex;
                this.mPDF.WidthScaleFactor = this.DoCvtToFloat(this.ctlScaleWidthsTBX.Text
                                                    , 1.0f, 0.5f, 1.2f);
                //--- Font/Type options
                this.mPDF.FontBodyTypeFace = (VVX.PDF.TypeFace)this.ctlFontBodyTypeFaceCBX.SelectedIndex;
                this.mPDF.FontBodyTypeSize = this.DoCvtToFloat(this.ctlFontBodyTypeSizeTBX.Text, 10f);
                this.mPDF.FontBodyTypeStyleBold = this.ctlFontBodyTypeStyleBoldCHK.Checked;
                this.mPDF.FontBodyTypeStyleItalics = this.ctlFontBodyTypeStyleItalicsCHK.Checked;

                //--- Font/Type options
                this.mPDF.FontHeaderTypeFace = (VVX.PDF.TypeFace)this.ctlFontHeaderTypeFaceCBX.SelectedIndex;
                this.mPDF.FontHeaderTypeSize = this.DoCvtToFloat(this.ctlFontHeaderTypeSizeTBX.Text, 10f);
                this.mPDF.FontHeaderTypeStyleBold = this.ctlFontHeaderTypeStyleBoldCHK.Checked;
                this.mPDF.FontHeaderTypeStyleItalics = this.ctlFontHeaderTypeStyleItalicsCHK.Checked;

                //--- encryption and permissions
                this.mPDF.EncryptionNeeded = this.ctlPdfHeaderEncryptCHK.Checked;
                this.mPDF.EncryptionPasswordOfCreator = this.ctlEncryptPasswordOwnerTBX.Text;
                this.mPDF.EncryptionPasswordOfReader = this.ctlEncryptPasswordUserTBX.Text;
                this.mPDF.EncryptionStrong = this.ctlEncrypt128BitCHK.Checked;

                this.mPDF.AllowAssembly = this.ctlEncryptAllowAssemblyCHK.Checked;
                this.mPDF.AllowCopy = this.ctlEncryptAllowCopyingCHK.Checked;
                this.mPDF.AllowFillIn = this.ctlEncryptAllowFillInCHK.Checked;
                this.mPDF.AllowModifyAnnotations = this.ctlEncryptAllowModifyAnnotationsCHK.Checked;
                this.mPDF.AllowModifyContents = this.ctlEncryptAllowModifyContentsCHK.Checked;
                this.mPDF.AllowDegradedPrinting = this.ctlEncryptAllowPrintDegradedCHK.Checked;
                this.mPDF.AllowPrinting = this.ctlEncryptAllowPrintingCHK.Checked;
                this.mPDF.AllowScreenReaders = this.ctlEncryptAllowScreenReadersCHK.Checked;

            }
            
            // This is a kluge because there doesn't seem to be a way to "empty" Acrobat Reader
            // So, if a file is being displayed in it (e.g., output tab's browser)
            // then that file cannot be created. 
            // Therefore, I fake it, by loading an empty PDF.
            // Not pretty, but it works!!!
            string sFile = "Empty.pdf";
            string sPath = this.DoGetURI(sFile);
            if(VVX.File.Exists(sPath) || mPDF.CreateEmptyPDF(sPath))
                DoShowPDF(sFile);
        }

        private float DoCvtToFloat(string sVal, float fDefault, float fMin, float fMax)
        {
            float fRet = DoCvtToFloat(sVal, fDefault);
            if (fRet < fMin)
                fRet = fMin;
            else
            if (fRet > fMax)
                fRet = fMax;

            return fRet;
        }

        private float DoCvtToFloat(string sVal, float fDefault)
        {
            float fRet = fDefault;

            try
            {
                fRet = (float)Convert.ToDouble(sVal);
            }
            catch (Exception ex)
            {
                string sMsg = String.Format("'{0}' is not valid", sVal);
                Debug.WriteLine(sMsg+"\n"+ex.ToString());
            }
            return fRet;
        }

        private void DoPostProcess(object sender, EventArgs e, string sXmlStoreFile)
        {
            DoPostProcess(sender, e);

            if (mPDF.Success)
            {
                //--- Show XmlStore XmlStore file in Info tab;
                this.ctlInfoBrowser.Navigate(sXmlStoreFile);
                //--- BUT DO NOT SWITCH TABS
            }
            else
            {
                this.DoNavigateToInfoPage();
            }

        }

        private void DoPostProcess(object sender, EventArgs e)
        {
            if (mPDF.Success)
            {
                //--- Show the name of the generated file in the Inputs tab
                this.ctlPdfHeaderFileTBX.Text = this.msFilePDF;
                //--- show the message in the status bar
                this.ctlInfoLBL.Text = mPDF.Message.Replace(msDataFolder, "");
                //--- Change tab: Show generated PDF
                this.ctlPdfTABS.SelectedIndex = 2;
            }
            else
            {
                //--- Show the name of the generated file in the Inputs tab
                this.ctlPdfHeaderFileTBX.Text = "";
                //--- show the message in the status bar
                this.ctlInfoLBL.Text = mPDF.Message;
            }
        }


        #region Tutorial

        private void ctlTutorialChap0518BTN_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0518.pdf"; //from iTextSharp tutorial
            if (mPDF.Chap0518(DoGetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlTutorialChap1011BTN_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);

            msFilePDF = "Chap1011.pdf"; //from iTextSharp tutorial
            if (this.mPDF.Chap1011(DoGetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlTutorialChap1202BTN_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);

            msFilePDF = "Chap1202.pdf"; //from iTextSharp tutorial
            if (this.mPDF.Chap1202(DoGetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }
        #endregion //Tutorial

        private void ctlSrcXmlStoreBTN_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);

            string sXmlStoreFileIn 
                = VVX.FileDialog.GetFilenameToOpen(VVX.FileDialog.FileType.XML, false, this.msDataFolder);

            if (sXmlStoreFileIn.Length > 0)
            {
                msFilePDF = VVX.File.DoExtractFilename(sXmlStoreFileIn);  // "Chap0518.pdf";
                msFilePDF += ".pdf";
                if (mPDF.DoCreateFromXmlStore(DoGetURI(msFilePDF), sXmlStoreFileIn))
                {
                    DoShowPDF(msFilePDF);
                }
                this.DoPostProcess(sender, e, sXmlStoreFileIn);
            }
        }

        private void ctlITextSharpTutorialsCHK_CheckedChanged(object sender, EventArgs e)
        {
            bool bOk = ctlITextSharpTutorialsCHK.Checked;

            this.ctlTutorialChap0518BTN.Enabled = bOk;
            this.ctlTutorialChap1011BTN.Enabled = bOk;
            this.ctlTutorialChap1202BTN.Enabled = bOk;

            this.ctlPdfHeaderPNL.Visible = !bOk;
            this.ctlSrcXmlStoreBTN.Enabled = !bOk;
        }

        private void ctlPdfHeaderDefaultsBTN_Click(object sender, EventArgs e)
        {
            //--- summary info
            this.ctlPdfHeaderAuthorTBX.Text = "victorbos";
            this.ctlPdfHeaderKeywordsTBX.Text = "XmlStore";
            this.ctlPdfHeaderSubjectTBX.Text = "Experiments Using VVX.PDF";
            this.ctlPdfHeaderTitleTBX.Text = "Sample Output from VVX.PDF";
            //--- View options
            this.ctlViewLayout2PageCHK.Checked = false;
            this.ctlViewToolBarCHK.Checked = true;
            this.ctlViewMenuBarCHK.Checked = true;
            this.ctlViewWindowUICHK.Checked = true;
            this.ctlViewResizeToFitCHK.Checked = true;
            this.ctlViewCenterOnScreenCHK.Checked = true;
            //--- Show options
            this.ctlShowPageNumberCHK.Checked = true;
            this.ctlShowTitleCHK.Checked = true;
            this.ctlShowWatermarkCHK.Checked = true;
            this.ctlShowWatermarkTextTBX.Text = "CONFIDENTIAL";
            this.ctlShowWatermarkFileTBX.Text = "watermark.jpg";
            this.ctlShowLandscapeCHK.Checked = true;
            this.ctlShowSizeCBX.SelectedIndex = 0;
            this.ctlScaleWidthsTBX.Text = "1.0";
            //--- Type/Font options BODY
            this.ctlFontBodyTypeFaceCBX.SelectedIndex = 0;
            this.ctlFontBodyTypeSizeTBX.Text = "10.0";
            this.ctlFontBodyTypeStyleBoldCHK.Checked = false;
            this.ctlFontBodyTypeStyleItalicsCHK.Checked = false;
            //--- Type/Font options HEADER
            this.ctlFontHeaderTypeFaceCBX.SelectedIndex = 1;
            this.ctlFontHeaderTypeSizeTBX.Text = "10.0";
            this.ctlFontHeaderTypeStyleBoldCHK.Checked = true;
            this.ctlFontHeaderTypeStyleItalicsCHK.Checked = false;

            //--- Encryption options
            this.ctlPdfHeaderEncryptCHK.Checked = false;
            this.ctlEncryptPasswordOwnerTBX.Text = "";
            this.ctlEncryptPasswordUserTBX.Text = "";
            this.ctlEncrypt128BitCHK.Checked = false;

            this.ctlEncryptAllowAssemblyCHK.Checked = true;
            this.ctlEncryptAllowCopyingCHK.Checked = true;
            this.ctlEncryptAllowFillInCHK.Checked = true;
            this.ctlEncryptAllowModifyAnnotationsCHK.Checked = true;
            this.ctlEncryptAllowModifyContentsCHK.Checked = true;
            this.ctlEncryptAllowPrintDegradedCHK.Checked = true;
            this.ctlEncryptAllowPrintingCHK.Checked = true;
            this.ctlEncryptAllowScreenReadersCHK.Checked = true;
        }

        private void ctlPdfHeaderEncryptCHK_CheckedChanged(object sender, EventArgs e)
        {
            bool bOk = ctlPdfHeaderEncryptCHK.Checked;
            this.DoEnableEncryptionOptions(bOk);
        }

        private void DoEnableEncryptionOptions(bool bEnable)
        {
            this.ctlEncrypt_PNL.Visible = bEnable;
            this.ctlEncrypt_PNL.Enabled = bEnable;
        }

        private void DoInitPaperSizes(ComboBox cbx)
        {
            cbx.Items.Clear();
            for (int i = 0; i < (int)VVX.PDF.PaperSize._COUNT; i++)
            {
                string sValue = ((VVX.PDF.PaperSize)i).ToString();
                cbx.Items.Add(sValue);
            }

            cbx.SelectedIndex = 0;
        }

        private void DoInitTypeFaces(ComboBox cbx)
        {
            cbx.Items.Clear();
            for (int i = 0; i < (int)VVX.PDF.TypeFace._COUNT; i++)
            {
                string sValue = ((VVX.PDF.TypeFace)i).ToString();
                cbx.Items.Add(sValue);
            }

            cbx.SelectedIndex = 0;
        }

        private void ctlShowWatermarkFileBTN_Click(object sender, EventArgs e)
        {
            string sFile
                = VVX.FileDialog.GetFilenameToOpen(VVX.FileDialog.FileType.Image, true, this.msDataFolder);

            if (VVX.File.Exists(sFile))
            {
                this.ctlShowWatermarkFileTBX.Text = sFile;
            }
        }
        #endregion //Helpers for 'Selections' Tab

    }
}