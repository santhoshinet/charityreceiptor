﻿/**
 *--------------------------------------------------------------------
 *
 * Page to create barcodes with C#
 *
 *--------------------------------------------------------------------
 * Revision History
 * v1.0.0	12 apr	2009	Jean-Sébastien Goupil	New version
 *--------------------------------------------------------------------
 * $Id: TestCode.aspx.cs,v 1.1 2009/05/03 20:44:23 jsgoupil Exp $
 *--------------------------------------------------------------------
 * Copyright (C) Jean-Sebastien Goupil
 * http://www.barcodeasp.com
 */

using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using BarcodeGenerator;
using System.Drawing.Imaging;
using System.Drawing;

namespace Barcode
{
	public partial class TestCode : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			BCGFont font = new BCGFont(new Font("Arial", 11, FontStyle.Regular));
			BCGColor color_black = new BCGColor(0, 0, 0);
			BCGColor color_white = new BCGColor(255, 255, 255);

			BCGBarcode1D code = new BCGcode39();
			code.setScale(2); // Resolution
			code.setThickness(30); // Thickness
			code.setForegroundColor(color_black); // Color of bars
			code.setBackgroundColor(color_white); // Color of spaces
			code.setFont(font); // Font
			code.parse("HELLO"); // Text

			/* Here is the list of the arguments
			1 - Filename (empty : display on screen)
			2 - Background color */
			BCGDrawing drawing = new BCGDrawing(color_white);
			drawing.setBarcode(code);
			drawing.draw();

			// Draw (or save) the image into PNG format.
			drawing.finish(ImageFormat.Png, this.Context.Response.OutputStream);
		}
	}
}
