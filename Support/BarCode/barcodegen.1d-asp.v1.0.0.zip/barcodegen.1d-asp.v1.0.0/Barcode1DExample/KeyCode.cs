﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace Barcode
{
	public class KeyCode
	{
		private char code;
		private string text;

		public KeyCode(char code)
		{
			init(code, code.ToString());
		}

		public KeyCode(char code, string text)
		{
			init(code, text);
		}

		public void init(char code, string text)
		{
			this.code = code;
			this.text = text;
		}

		public string Code
		{
			get
			{
				return string.Format("%{0:x}", (int)code);
			}
		}

		public string Text
		{
			get
			{
				return text;
			}
		}
	}
}
