﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using Barcode.code;

namespace Barcode
{
	public class Utility
	{
		public static Dictionary<Type, string> codeType = new Dictionary<Type, string>();

		public static Dictionary<int, string> outputType = new Dictionary<int, string>();

		public static List<string> fontType = new List<string>();

		public static List<KeyCode> keyCodeNumber = new List<KeyCode>();

		public static List<KeyCode> keyCodeLettersCapital = new List<KeyCode>();

		public static List<KeyCode> keyCodeLettersLower = new List<KeyCode>();

		public static List<KeyCode> keyCodeFull = new List<KeyCode>();

		static Utility()
		{
			codeType.Add(typeof(codabar), "Codabar");
			codeType.Add(typeof(code11), "Code 11");
			codeType.Add(typeof(code39), "Code 39");
			codeType.Add(typeof(code39extended), "Code 39 Extended");
			codeType.Add(typeof(code93), "Code 93");
			codeType.Add(typeof(code128), "Code 128");
			codeType.Add(typeof(ean8), "EAN-8");
			codeType.Add(typeof(ean13), "EAN-13");
			codeType.Add(typeof(isbn), "ISBN-10 / ISBN-13");
			codeType.Add(typeof(i25), "Interleaved 2 of 5");
			codeType.Add(typeof(s25), "Standard 2 of 5");
			codeType.Add(typeof(msi), "MSI Plessey");
			codeType.Add(typeof(upca), "UPC-A");
			codeType.Add(typeof(upce), "UPC-E");
			codeType.Add(typeof(upcext2), "UPC Extension 2 Digits");
			codeType.Add(typeof(upcext5), "UPC Extension 5 Digits");
			codeType.Add(typeof(postnet), "Postnet");
			codeType.Add(typeof(othercode), "Other Barcode");

			outputType.Add(1, "Bitmap (BMP)");
			outputType.Add(2, "Portable Network Graphics (PNG)");
			outputType.Add(3, "Joint Photographic Experts Group (JPEG)");
			outputType.Add(4, "Graphics Interchange Format (GIF)");

			fontType.Add("Arial");
			fontType.Add("Courier New");

			keyCodeNumber.Add(new KeyCode('0'));
			keyCodeNumber.Add(new KeyCode('1'));
			keyCodeNumber.Add(new KeyCode('2'));
			keyCodeNumber.Add(new KeyCode('3'));
			keyCodeNumber.Add(new KeyCode('4'));
			keyCodeNumber.Add(new KeyCode('5'));
			keyCodeNumber.Add(new KeyCode('6'));
			keyCodeNumber.Add(new KeyCode('7'));
			keyCodeNumber.Add(new KeyCode('8'));
			keyCodeNumber.Add(new KeyCode('9'));

			keyCodeLettersCapital.Add(new KeyCode('A'));
			keyCodeLettersCapital.Add(new KeyCode('B'));
			keyCodeLettersCapital.Add(new KeyCode('C'));
			keyCodeLettersCapital.Add(new KeyCode('D'));
			keyCodeLettersCapital.Add(new KeyCode('E'));
			keyCodeLettersCapital.Add(new KeyCode('F'));
			keyCodeLettersCapital.Add(new KeyCode('G'));
			keyCodeLettersCapital.Add(new KeyCode('H'));
			keyCodeLettersCapital.Add(new KeyCode('I'));
			keyCodeLettersCapital.Add(new KeyCode('J'));
			keyCodeLettersCapital.Add(new KeyCode('K'));
			keyCodeLettersCapital.Add(new KeyCode('L'));
			keyCodeLettersCapital.Add(new KeyCode('M'));
			keyCodeLettersCapital.Add(new KeyCode('N'));
			keyCodeLettersCapital.Add(new KeyCode('O'));
			keyCodeLettersCapital.Add(new KeyCode('P'));
			keyCodeLettersCapital.Add(new KeyCode('Q'));
			keyCodeLettersCapital.Add(new KeyCode('R'));
			keyCodeLettersCapital.Add(new KeyCode('S'));
			keyCodeLettersCapital.Add(new KeyCode('T'));
			keyCodeLettersCapital.Add(new KeyCode('U'));
			keyCodeLettersCapital.Add(new KeyCode('V'));
			keyCodeLettersCapital.Add(new KeyCode('W'));
			keyCodeLettersCapital.Add(new KeyCode('X'));
			keyCodeLettersCapital.Add(new KeyCode('Y'));
			keyCodeLettersCapital.Add(new KeyCode('Z'));

			keyCodeLettersLower.Add(new KeyCode('a'));
			keyCodeLettersLower.Add(new KeyCode('b'));
			keyCodeLettersLower.Add(new KeyCode('c'));
			keyCodeLettersLower.Add(new KeyCode('d'));
			keyCodeLettersLower.Add(new KeyCode('e'));
			keyCodeLettersLower.Add(new KeyCode('f'));
			keyCodeLettersLower.Add(new KeyCode('g'));
			keyCodeLettersLower.Add(new KeyCode('h'));
			keyCodeLettersLower.Add(new KeyCode('i'));
			keyCodeLettersLower.Add(new KeyCode('j'));
			keyCodeLettersLower.Add(new KeyCode('k'));
			keyCodeLettersLower.Add(new KeyCode('l'));
			keyCodeLettersLower.Add(new KeyCode('m'));
			keyCodeLettersLower.Add(new KeyCode('n'));
			keyCodeLettersLower.Add(new KeyCode('o'));
			keyCodeLettersLower.Add(new KeyCode('p'));
			keyCodeLettersLower.Add(new KeyCode('q'));
			keyCodeLettersLower.Add(new KeyCode('r'));
			keyCodeLettersLower.Add(new KeyCode('s'));
			keyCodeLettersLower.Add(new KeyCode('t'));
			keyCodeLettersLower.Add(new KeyCode('u'));
			keyCodeLettersLower.Add(new KeyCode('v'));
			keyCodeLettersLower.Add(new KeyCode('w'));
			keyCodeLettersLower.Add(new KeyCode('x'));
			keyCodeLettersLower.Add(new KeyCode('y'));
			keyCodeLettersLower.Add(new KeyCode('z'));

			keyCodeFull.Add(new KeyCode((char)0, "NUL"));
			keyCodeFull.Add(new KeyCode((char)1, "SOH"));
			keyCodeFull.Add(new KeyCode((char)2, "STX"));
			keyCodeFull.Add(new KeyCode((char)3, "ETX"));
			keyCodeFull.Add(new KeyCode((char)4, "EOT"));
			keyCodeFull.Add(new KeyCode((char)5, "ENQ"));
			keyCodeFull.Add(new KeyCode((char)6, "ACK"));
			keyCodeFull.Add(new KeyCode((char)7, "BEL"));
			keyCodeFull.Add(new KeyCode((char)8, "BS"));
			keyCodeFull.Add(new KeyCode((char)9, "TAB"));
			keyCodeFull.Add(new KeyCode((char)10, "LF"));
			keyCodeFull.Add(new KeyCode((char)11, "VT"));
			keyCodeFull.Add(new KeyCode((char)12, "FF"));
			keyCodeFull.Add(new KeyCode((char)13, "CR"));
			keyCodeFull.Add(new KeyCode((char)14, "SO"));
			keyCodeFull.Add(new KeyCode((char)15, "SI"));
			keyCodeFull.Add(new KeyCode((char)16, "DLE"));
			keyCodeFull.Add(new KeyCode((char)17, "DC1"));
			keyCodeFull.Add(new KeyCode((char)18, "DC2"));
			keyCodeFull.Add(new KeyCode((char)19, "DC3"));
			keyCodeFull.Add(new KeyCode((char)20, "DC4"));
			keyCodeFull.Add(new KeyCode((char)21, "NAK"));
			keyCodeFull.Add(new KeyCode((char)22, "SYN"));
			keyCodeFull.Add(new KeyCode((char)23, "ETB"));
			keyCodeFull.Add(new KeyCode((char)24, "CAN"));
			keyCodeFull.Add(new KeyCode((char)25, "EM"));
			keyCodeFull.Add(new KeyCode((char)26, "SUB"));
			keyCodeFull.Add(new KeyCode((char)27, "ESC"));
			keyCodeFull.Add(new KeyCode((char)28, "FS"));
			keyCodeFull.Add(new KeyCode((char)29, "GS"));
			keyCodeFull.Add(new KeyCode((char)30, "RS"));
			keyCodeFull.Add(new KeyCode((char)31, "US"));
			keyCodeFull.Add(new KeyCode(' '));
			keyCodeFull.Add(new KeyCode('!'));
			keyCodeFull.Add(new KeyCode('"'));
			keyCodeFull.Add(new KeyCode('#'));
			keyCodeFull.Add(new KeyCode('$'));
			keyCodeFull.Add(new KeyCode('%'));
			keyCodeFull.Add(new KeyCode('&'));
			keyCodeFull.Add(new KeyCode('\''));
			keyCodeFull.Add(new KeyCode('('));
			keyCodeFull.Add(new KeyCode(')'));
			keyCodeFull.Add(new KeyCode('*'));
			keyCodeFull.Add(new KeyCode('+'));
			keyCodeFull.Add(new KeyCode(','));
			keyCodeFull.Add(new KeyCode('-'));
			keyCodeFull.Add(new KeyCode('.'));
			keyCodeFull.Add(new KeyCode('/'));
			keyCodeFull.AddRange(keyCodeNumber);
			keyCodeFull.Add(new KeyCode(':'));
			keyCodeFull.Add(new KeyCode(';'));
			keyCodeFull.Add(new KeyCode('<'));
			keyCodeFull.Add(new KeyCode('='));
			keyCodeFull.Add(new KeyCode('>'));
			keyCodeFull.Add(new KeyCode('?'));
			keyCodeFull.Add(new KeyCode('@'));
			keyCodeFull.AddRange(keyCodeLettersCapital);
			keyCodeFull.Add(new KeyCode('['));
			keyCodeFull.Add(new KeyCode('\\'));
			keyCodeFull.Add(new KeyCode(']'));
			keyCodeFull.Add(new KeyCode('^'));
			keyCodeFull.Add(new KeyCode('_'));
			keyCodeFull.Add(new KeyCode('`'));
			keyCodeFull.AddRange(keyCodeLettersLower);
			keyCodeFull.Add(new KeyCode('{'));
			keyCodeFull.Add(new KeyCode('|'));
			keyCodeFull.Add(new KeyCode('}'));
			keyCodeFull.Add(new KeyCode('~'));
			keyCodeFull.Add(new KeyCode((char)127, "DEL"));

		}

		public static KeyCode[] MergeKeyCode(params List<KeyCode>[] listKeyCode)
		{
			List<KeyCode> list = new List<KeyCode>();
			foreach (List<KeyCode> keyCodes in listKeyCode)
			{
				list.AddRange(keyCodes);
			}

			return list.ToArray();
		}

		public static KeyCode[] MergeKeyCode(params object[] keyCode)
		{
			Type type1 = typeof(List<KeyCode>);
			Type type2 = typeof(KeyCode);

			List<KeyCode> list = new List<KeyCode>();
			foreach (object obj in keyCode)
			{
				Type typeDyn = obj.GetType();
				if (typeDyn == type1)
				{
					list.AddRange(obj as List<KeyCode>);
				}
				else if (typeDyn == type2)
				{
					list.Add(obj as KeyCode);
				}
			}

			return list.ToArray();
		}
	}
}
