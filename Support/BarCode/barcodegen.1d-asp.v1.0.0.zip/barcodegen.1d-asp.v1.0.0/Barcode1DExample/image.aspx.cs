﻿/**
 *--------------------------------------------------------------------
 *
 * File to create barcode used by Default.aspx
 *
 *--------------------------------------------------------------------
 * Revision History
 * v1.0.0	12 apr	2009	Jean-Sébastien Goupil	New version
 *--------------------------------------------------------------------
 * $Id: image.aspx.cs,v 1.1 2009/05/03 20:44:24 jsgoupil Exp $
 *--------------------------------------------------------------------
 * Copyright (C) Jean-Sebastien Goupil
 * http://www.barcodeasp.com
 */

using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using BarcodeGenerator;
using System.IO;
using System.Collections.Generic;
using Barcode.code;
using System.Reflection;
using System.Drawing;
using System.Drawing.Imaging;

namespace Barcode
{
	public partial class image : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			try
			{
				string fontString = Request.QueryString["f1"];
				BCGFont font = null;
				if (!string.IsNullOrEmpty(fontString))
				{
					float fontSize = 30;
					float.TryParse(Request.QueryString["f2"], out fontSize);
					font = new BCGFont(new Font(Request.QueryString["f1"], fontSize));
				}

				BCGColor color_black = new BCGColor(Color.Black);
				BCGColor color_white = new BCGColor(Color.White);

				BCGBarcode1D codebar = null;

				string code = Request.QueryString["code"];
				Type codeType = null;
				foreach (KeyValuePair<Type, string> kvp in Utility.codeType)
				{
					if (kvp.Value == code)
					{
						codeType = kvp.Key;
						break;
					}
				}

				if (codeType == null)
				{
					throw new Exception("You need to specify a type of barcode");
				}

				barcode temporaryBarcode = (barcode)Activator.CreateInstance(codeType);
				codebar = (BCGBarcode1D)Activator.CreateInstance(temporaryBarcode.Code);

				int thickness = 30;
				int.TryParse(Request.QueryString["t"], out thickness);
				codebar.setThickness(thickness);

				int scale = 30;
				int.TryParse(Request.QueryString["r"], out scale);
				codebar.setScale(scale);

				// Special
				int a1 = 0;
				if (int.TryParse(Request.QueryString["a1"], out a1) && a1 == 1)
				{
					MethodInfo method = temporaryBarcode.Code.GetMethod("setChecksum", new Type[] { typeof(bool) });
					if (method != null)
					{
						method.Invoke(codebar, new object[] { true });
					}
					method = temporaryBarcode.Code.GetMethod("setChecksum", new Type[] { typeof(int) });
					if (method != null)
					{
						method.Invoke(codebar, new object[] { 1 });
					}
				}
				if (!string.IsNullOrEmpty(Request.QueryString["a2"]))
				{
					MethodInfo method = temporaryBarcode.Code.GetMethod("setStart");
					if (method != null)
					{
						method.Invoke(codebar, new object[] { Request.QueryString["a2"] });
					}
				}
				if (!string.IsNullOrEmpty(Request.QueryString["a3"]))
				{
					MethodInfo method = temporaryBarcode.Code.GetMethod("setLabel");
					if (method != null)
					{
						method.Invoke(codebar, new object[] { Request.QueryString["a3"] });
					}
				}

				codebar.setBackgroundColor(color_white);
				codebar.setForegroundColor(color_black);
				codebar.setFont(font);
				codebar.parse(Request.QueryString["text"]);

				BCGDrawing drawing = new BCGDrawing(color_white);
				drawing.setBarcode(codebar);
				drawing.draw();

				// Draw (or save) the image into the right format.
				string format = Request.QueryString["o"];
				ImageFormat imageFormat = null;
				switch (format)
				{
					case "1":
						Response.ContentType = "image/bmp";
						imageFormat = ImageFormat.Bmp;
						break;
					case "2":
						Response.ContentType = "image/png";
						imageFormat = ImageFormat.Png;
						break;
					case "3":
						Response.ContentType = "image/jpeg";
						imageFormat = ImageFormat.Jpeg;
						break;
					case "4":
						Response.ContentType = "image/gif";
						imageFormat = ImageFormat.Gif;
						break;
				}

				if (imageFormat != null)
				{
					drawing.finish(imageFormat, Response.OutputStream);
				}
			}
			catch (Exception exception)
			{
				Response.ContentType = "image/png";

				using (FileStream fs = new FileStream("error.png", FileMode.Open))
				{
					using (BinaryReader br = new BinaryReader(fs))
					{
						byte[] buffer = new byte[fs.Length];
						br.Read(buffer, 0, (int)fs.Length);

						using (MemoryStream ms = new MemoryStream(buffer))
						{
							ms.WriteTo(Response.OutputStream);
						}
					}
				}

				// Here, check for the exception.
				System.Diagnostics.Debug.Write(exception);
				
			}
		}
	}
}
