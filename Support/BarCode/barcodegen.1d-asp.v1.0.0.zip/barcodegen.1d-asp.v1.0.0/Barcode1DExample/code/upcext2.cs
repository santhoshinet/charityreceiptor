﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace Barcode.code
{
	public class upcext2 : barcode
	{
		public override Type Code
		{
			get
			{
				return typeof(BarcodeGenerator.BCGupcext2);
			}
		}

		public override string Description
		{
			get
			{
				return "";
			}
		}

		public override string Title
		{
			get
			{
				return "UPC Extension 2 Digits";
			}
		}

		public override string Explanation
		{
			get
			{
				return "<ul style=\"margin: 0px; padding-left: 25px;\"><li>Extension for UPC-A, UPC-E, EAN-13 and EAN-8.</li><li>Used for encode additional information for newspaper, books...</li></ul>";
			}
		}

		public override KeyCode[] Keys
		{
			get
			{
				return Utility.keyCodeNumber.ToArray();
			}
		}
	}
}
