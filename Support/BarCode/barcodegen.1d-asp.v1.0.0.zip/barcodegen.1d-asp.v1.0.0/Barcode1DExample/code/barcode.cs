﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace Barcode.code
{
	public abstract class barcode
	{
		public abstract string Title
		{
			get;
		}

		public abstract string Description
		{
			get;
		}

		public abstract Type Code
		{
			get;
		}

		public abstract KeyCode[] Keys
		{
			get;
		}

		public abstract string Explanation
		{
			get;
		}

		public virtual int SizeKeys
		{
			get
			{
				return 25;
			}
		}

		public virtual string SpecificText
		{
			get
			{
				return "Specific Config";
			}
		}

		public virtual HtmlControl SpecificValue
		{
			get
			{
				HtmlGenericControl control =new HtmlGenericControl("span");
				control.Controls.Add(new LiteralControl("None"));
				return control;
			}
		}
	}

}