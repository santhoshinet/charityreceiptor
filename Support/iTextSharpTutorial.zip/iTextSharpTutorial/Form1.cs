using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Windows.Forms;

//--- Add the following to make this code work
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using System.Diagnostics;
using VVX;

namespace iTextSharpTutorial
{
    public partial class Form1 : Form
    {
        private string msAppName = "iTextSharp Tutorials";
        iTextSharp_Tutorials mTutorial = new iTextSharp_Tutorials();
        string msFilePDF = "";
        string msFolder = "";

        public Form1()
        {
            InitializeComponent();

            //--- init the folder in which generated PDF's will be saved.
            msFolder = Application.ExecutablePath;
            int n = msFolder.LastIndexOf(@"\");
            msFolder = msFolder.Substring(0, n+1);
        }

        private void OnFormShown(object sender, EventArgs e)
        {
            NavigateToHomePage();
            VVX.About.Show();   //OK to comment this out.
        }

        private void NavigateToHomePage()
        {
            string sFile = "iTextSharpTutorial.html";

            string sPath = sFile;
            for (int i = 0; i < 6; i++)
            {
                if (VVX.File.Exists(sPath))
                {
                    FileInfo fi = new FileInfo(sPath);
                    this.webBrowser1.Navigate(fi.FullName);
                    break;
                }
                sPath = @"..\" + sPath;
            }
        }

        #region General Purpose Helpers for this Form
        //************************************************************
        /// <summary>
        /// Refreshes the window's Caption/Title bar
        /// </summary>
        private void DoUpdateCaption()
        {
            this.Text = this.msAppName;

            if (this.msFilePDF.Length == 0)
            {
                this.Text += "<no PDF file create>";
            }
            else
            {
                FileInfo fi = new FileInfo(this.msFilePDF);
                this.Text += @"...\" + fi.Name;
            }
        }
        #endregion //General Purpose Helpers for this Form


        #region Show PDF Helpers for Tutorial Chapters
        private string GetURI(string sFile)
        {
            string sRet = msFolder + msFilePDF;

            return sRet;
        }

        private void DoShowPDF(string sFilePDF)
        {
            this.DoUpdateCaption();
            this.webBrowser1.Navigate(GetURI(sFilePDF));
        }
        #endregion //Show PDF Helpers for Tutorial Chapters

        
        #region Event Handlers
        private void ctlFileExitMNU_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ctlBrowserBackMNU_Click(object sender, EventArgs e)
        {
            if (webBrowser1.CanGoBack)
                this.webBrowser1.GoBack();
            else
                this.NavigateToHomePage();

            //MsgBox.Info("Cannot go back any further");
        }

        #region Help Event Handlers
        private void ctlHelpAboutMNU_Click(object sender, EventArgs e)
        {
            VVX.About.Show();
        }

        private void ctlHelpTutorialHomeMNU_Click(object sender, EventArgs e)
        {
            this.webBrowser1.Navigate("http://itextsharp.sourceforge.net/tutorial/index.html");
        }

        #region Help Event Handlers Adobe
        private void ctlAdobePdfSpecTechCenterMNU_Click(object sender, EventArgs e)
        {
            this.webBrowser1.Navigate("http://www.adobe.com/devnet/pdf/pdf_reference.html");
        }

        private void DoOpenLocalCopy(string sPdfSpecFile)
        {
            FileInfo fi = new FileInfo(sPdfSpecFile);
            if (fi.Exists)
                this.webBrowser1.Navigate(sPdfSpecFile);
            else
            {
                if(MsgBox.Confirm("Requested file not found. \n\nTry Adobe's Technology Center?"))
                    this.webBrowser1.Navigate("http://www.adobe.com/devnet/pdf/pdf_reference.html");
            }
        }

        private void ctlAdobePdfSpec13MNU_Click(object sender, EventArgs e)
        {
            string sPdfSpecFile = @"D:\Work\Xpt\VVX_PdfLibrary\PDFReference13.pdf";
            this.DoOpenLocalCopy(sPdfSpecFile);
        }

        private void ctlAdobePdfSpec14MNU_Click(object sender, EventArgs e)
        {
            string sPdfSpecFile = @"D:\Work\Xpt\VVX_PdfLibrary\PDFReference14.pdf";
            this.DoOpenLocalCopy(sPdfSpecFile);
        }

        private void ctlAdobePdfSpec15MNU_Click(object sender, EventArgs e)
        {
            string sPdfSpecFile = @"D:\Work\Xpt\VVX_PdfLibrary\PDFReference15_v6.pdf";
            this.DoOpenLocalCopy(sPdfSpecFile);
        }

        private void ctlAdobePdfSpec16MNU_Click(object sender, EventArgs e)
        {
            string sPdfSpecFile = @"D:\Work\Xpt\VVX_PdfLibrary\PDFReference16.pdf";
            this.DoOpenLocalCopy(sPdfSpecFile);
        }

        private void ctlAdobePdfSpec17MNU_Click(object sender, EventArgs e)
        {
            string sPdfSpecFile = @"D:\Work\Xpt\VVX_PdfLibrary\PDF_Reference.pdf";
            this.DoOpenLocalCopy(sPdfSpecFile);
        }
        #endregion //Help Event Handlers Adobe

        #endregion //Help Event Handlers

        #region Event Handlers Chapter 7
        // to do
        #endregion //Event Handlers Chapter 7

        #region Event Handlers Chapter 8
        // to do
        #endregion //Event Handlers Chapter 8

        #region Event Handlers Chapter 9
        // to do
        #endregion //Event Handlers Chapter 9

        #region Event Handlers Chapter 10
        // to do
        #endregion //Event Handlers Chapter 10

        #region Event Handlers Chapter 11
        // to do
        #endregion //Event Handlers Chapter 11

        #region Event Handlers Chapter 12
        // to do
        #endregion //Event Handlers Chapter 12

        #endregion //Event Handlers


        #region Event Handlers Chapter 1

        private void ctlTutorialAutoCheckMNU_Click(object sender, EventArgs e)
        {

        }

        private void DoPreProcess(object sender, EventArgs e)
        {
            if(ctlTutorialAutoCheckMNU.Checked)
                ((ToolStripMenuItem)sender).Checked = true;
        }

        private void DoPostProcess(object sender, EventArgs e)
        {
            if (ctlTutorialAutoCheckMNU.Checked)
                ((ToolStripMenuItem)sender).Checked = mTutorial.Success;

            if(mTutorial.Success)
                this.ctlInfoLBL.Text = mTutorial.Message.Replace(msFolder, "");
        }

        // See http://itextsharp.sourceforge.net/tutorial/ch01.html
        private void ctlChapter0101BTN_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0101.pdf";
            if (mTutorial.Chap0101(GetURI(GetURI(msFilePDF))))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }
        #endregion //Event Handlers Chapter 1

        #region Event Handlers Chapter 2
        private void ctlChapter0201_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0201.pdf";
            if (mTutorial.Chap0201(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }
        #endregion //Event Handlers Chapter 2

        #region Event Handlers Chapter 3
        private void ctlChapter0301BTN_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0301.pdf";
            if (mTutorial.Chap0301(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }
        #endregion //Event Handlers Chapter 3

        #region Event Handlers Chapter 4

        private void ctlChapter0401BTN_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0401.pdf";
            if (mTutorial.Chap0401(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0402BTN_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0402.pdf";
            if (mTutorial.Chap0402(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0403BTN_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0403.pdf";
            if (mTutorial.Chap0403(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0404BTN_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0404.pdf";
            if (mTutorial.Chap0404(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0405BTN_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0405.pdf";
            if (mTutorial.Chap0405(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }
        #endregion //Event Handlers Chapter 4

        #region Event Handlers Chapter 5

        private void ctlChapter0501MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0501.pdf";
            if (mTutorial.Chap0501(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0502MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0502.pdf";
            if (mTutorial.Chap0502(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0503MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0503.pdf";
            if (mTutorial.Chap0503(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0504MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0504.pdf";
            if (mTutorial.Chap0504(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0505MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0505.pdf";
            if (mTutorial.Chap0505(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0506MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0506.pdf";
            if (mTutorial.Chap0506(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0507MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0507.pdf";
            if (mTutorial.Chap0507(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0508MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0508.pdf";
            if (mTutorial.Chap0508(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0509MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0509.pdf";
            if (mTutorial.Chap0509(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0510MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0510.pdf";
            if (mTutorial.Chap0510(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0511MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0511.pdf";
            if (mTutorial.Chap0511(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0512MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0512.pdf";
            if (mTutorial.Chap0512(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0513MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0513.pdf";
            if (mTutorial.Chap0513(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0514MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0514.pdf";
            if (mTutorial.Chap0514(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0515MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0515.pdf";
            if (mTutorial.Chap0515(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0516MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0516.pdf";
            if (mTutorial.Chap0516(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0517MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0517.pdf";
            if (mTutorial.Chap0517(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0518MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0518.pdf";
            if (mTutorial.Chap0518(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }
        #endregion //Event Handlers Chapter 5

        #region Event Handlers Chapter 6

        private void ctlChapter0601MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0601.pdf";
            this.Cursor = Cursors.WaitCursor;
            if (mTutorial.Chap0601(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.Cursor = Cursors.Default;
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0602MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0602.pdf";
            if (mTutorial.Chap0602(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0603MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0603.pdf";
            if (mTutorial.Chap0603(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0604MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0604.pdf";
            if (mTutorial.Chap0604(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0605MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0605.pdf";
            if (mTutorial.Chap0605(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0606MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0606.pdf";
            if (mTutorial.Chap0606(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0607MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0607.pdf";
            if (mTutorial.Chap0607(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0608MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0608.pdf";
            if (mTutorial.Chap0608(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0609MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0609.pdf";
            if (mTutorial.Chap0609(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0610MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0610.pdf";
            if (mTutorial.Chap0610(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0611MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0611.pdf";
            if (mTutorial.Chap0611(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0612MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0612.pdf";
            if (mTutorial.Chap0612(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0613MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0613.pdf";
            if (mTutorial.Chap0613(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0614MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0614.pdf";
            if (mTutorial.Chap0614(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

        private void ctlChapter0615MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0615.pdf";
            this.Cursor = Cursors.WaitCursor;
            if (mTutorial.Chap0615(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.Cursor = Cursors.Default;
            this.DoPostProcess(sender, e);

            MsgBox.Warning("The result does not match what is shown on web site");

        }

        private void ctlChapter0616MNU_Click(object sender, EventArgs e)
        {
            DoPreProcess(sender, e);
            msFilePDF = "Chap0616.pdf";
            if (mTutorial.Chap0616(GetURI(msFilePDF)))
            {
                DoShowPDF(msFilePDF);
            }
            this.DoPostProcess(sender, e);
        }

       #endregion //Event Handlers Chapter 6

    }
}