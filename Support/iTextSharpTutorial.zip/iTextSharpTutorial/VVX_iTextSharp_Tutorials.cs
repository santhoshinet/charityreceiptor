using System;
using System.Collections.Generic;
using System.Text;

//--- Add the following to make this code work
using iTextSharp.text;
using iTextSharp.text.pdf;
//using System.Drawing ;
using System.IO;
using System.Diagnostics;
//using VVX;

namespace VVX
{
    class iTextSharp_Tutorials
    {
        private string sMsg = "";
        private bool bRet = false;

        public string Message
        {
            get { return sMsg; }
            set { sMsg = value; }
        }

        public bool Success
        {
            get { return bRet; }
            set { bRet = value; }
        }

        #region Helper methods
        /// <summary>
        /// Safely attempts to insert an image file into the document
        /// </summary>
        /// <param name="document">iTextSharp Document in which it needs to be inserted</param>
        /// <param name="sFilename">the name of the file to be inserted</param>
        /// <returns>false if failed to do so</returns>
        private bool DoInsertImageFile(Document document, string sFilename, bool bInsertMsg)
        {
            bool bRet = false;

            try
            {
                if (File.Exists(sFilename) == false)
                {
                    string sMsg = "Unable to find '"+sFilename +"' in the current folder.\n\n"
                                + "Would you like to locate it?";
                    if(MsgBox.Confirm(sMsg))
                        sFilename = FileDialog.GetFilenameToOpen(FileDialog.FileType.Image);
                }

                Image img = null;
                if (File.Exists(sFilename))
                {
                    this.DoGetImageFile(sFilename, out img);
                }

                if (img != null)
                {
                    document.Add(img);
                    bRet = true;
                }
                else
                {
                    if (bInsertMsg)
                        document.Add(new Paragraph(sFilename + " not found"));
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }

            return bRet;
        }

        private Image DoGetImageFile(string sFilename)
        {
            bool bRet = false;
            Image img = null;

            try
            {
                if (File.Exists(sFilename) == false)
                {
                    string sMsg = "Unable to find '" + sFilename + "' in the current folder.\n\n"
                                + "Would you like to locate it?";
                    if (MsgBox.Confirm(sMsg))
                        sFilename = FileDialog.GetFilenameToOpen(FileDialog.FileType.Image);
                }

                if (File.Exists(sFilename))
                {
                    img = Image.GetInstance(sFilename);
                }

                bRet = (img != null);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }

            return img;
        }

        private bool DoGetImageFile(string sFilename, out Image img)
        {
            bool bRet = false;
            img = null;

            try
            {
                if (File.Exists(sFilename) == false)
                {
                    string sMsg = "Unable to find '" + sFilename + "' in the current folder.\n\n"
                                + "Would you like to locate it?";
                    if (MsgBox.Confirm(sMsg))
                        sFilename = FileDialog.GetFilenameToOpen(FileDialog.FileType.Image);
                }

                if (File.Exists(sFilename))
                {
                    img = Image.GetInstance(sFilename);
                }

                bRet = (img != null);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }

            return bRet;
        }

        private bool DoLocateImageFile(ref string sFilename)
        {
            bool bRet = false;

            try
            {
                if (File.Exists(sFilename) == false)
                {
                    string sMsg = "Unable to find '" + sFilename + "' in the current folder.\n\n"
                                + "Would you like to locate it?";
                    
                    if (MsgBox.Confirm(sMsg))
                        sFilename = FileDialog.GetFilenameToOpen(FileDialog.FileType.Image);
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }

            return bRet = File.Exists(sFilename);
        }

        #endregion //Helper methods



        #region Chapter 1
        // See http://itextsharp.sourceforge.net/tutorial/ch01.html
        public bool Chap0101(string sFilePDF)
        {
            bRet = false;

            //Creates an instance of the iTextSharp.text.Document-object:
            Document document = new Document();

            try
            {
                //Creates a Writer that listens to this document and writes the document to the Stream of your choice:
                PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                //Opens the document:
                document.Open();

                //Adds content to the document:
                document.Add(new Paragraph("Hello World"));

                bRet = true;
            }
            catch (Exception ex)
            {
                this.Message = ex.Message;
            }
            finally
            {
                document.Close();
            }

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }
        #endregion //Chapter 1

        #region Chapter 2
        //See http://itextsharp.sourceforge.net/tutorial/ch02.html
        public bool Chap0201(string sFilePDF)
        {
            bRet = false ;

            Debug.WriteLine("Chapter 2 example 1: Chunks and fonts");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {

                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: we Add content to the document
                Font[] fonts = new Font[14];
                fonts[0] = FontFactory.GetFont(FontFactory.COURIER, 12, iTextSharp.text.Font.NORMAL);
                fonts[1] = FontFactory.GetFont(FontFactory.COURIER, 12, iTextSharp.text.Font.BOLD);
                fonts[2] = FontFactory.GetFont(FontFactory.COURIER, 12, iTextSharp.text.Font.ITALIC);
                fonts[3] = FontFactory.GetFont(FontFactory.COURIER, 12, iTextSharp.text.Font.BOLD | iTextSharp.text.Font.ITALIC);
                fonts[4] = FontFactory.GetFont(FontFactory.HELVETICA, 12, iTextSharp.text.Font.NORMAL);
                fonts[5] = FontFactory.GetFont(FontFactory.HELVETICA, 12, iTextSharp.text.Font.BOLD);
                fonts[6] = FontFactory.GetFont(FontFactory.HELVETICA, 12, iTextSharp.text.Font.ITALIC);
                fonts[7] = FontFactory.GetFont(FontFactory.HELVETICA, 12, iTextSharp.text.Font.BOLD | iTextSharp.text.Font.ITALIC);
                fonts[8] = FontFactory.GetFont(FontFactory.TIMES_ROMAN, 12, iTextSharp.text.Font.NORMAL);
                fonts[9] = FontFactory.GetFont(FontFactory.TIMES_ROMAN, 12, iTextSharp.text.Font.BOLD);
                fonts[10] = FontFactory.GetFont(FontFactory.TIMES_ROMAN, 12, iTextSharp.text.Font.ITALIC);
                fonts[11] = FontFactory.GetFont(FontFactory.TIMES_ROMAN, 12, iTextSharp.text.Font.BOLD | iTextSharp.text.Font.ITALIC);
                fonts[12] = FontFactory.GetFont(FontFactory.SYMBOL, 12, iTextSharp.text.Font.NORMAL);
                fonts[13] = FontFactory.GetFont(FontFactory.ZAPFDINGBATS, 12, iTextSharp.text.Font.NORMAL);
                for (int i = 0; i < 14; i++)
                {
                    Chunk chunk = new Chunk("This is some", fonts[i]);
                    document.Add(new Phrase(chunk));
                    document.Add(new Phrase(new Chunk(" font. ",
                        fonts[i]).SetTextRise((i % 2 == 0) ? -6 : 6)));
                }
                document.Add(new Phrase(new Chunk("This text is underlined",
                    FontFactory.GetFont(FontFactory.HELVETICA, 12, iTextSharp.text.Font.UNDERLINE))));
                document.Add(new Phrase(new Chunk("This font is of type ITALIC | STRIKETHRU",
                    FontFactory.GetFont(FontFactory.HELVETICA, 12, iTextSharp.text.Font.ITALIC | iTextSharp.text.Font.STRIKETHRU))));
                Chunk ck = new Chunk("This text has a yellow background color", FontFactory.GetFont(FontFactory.HELVETICA, 12));
                ck.SetBackground(new Color(0xFF, 0xFF, 0x00));
                document.Add(new Phrase(ck));

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }
        #endregion //Chapter 3

        #region Chapter 3
        //See http://itextsharp.sourceforge.net/tutorial/ch03.html
        public bool Chap0301(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 3 example 1: Anchors");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {

                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we Open the document
                document.Open();

                // step 4:
                Paragraph paragraph = new Paragraph("Please visit my ");
                Anchor anchor1 = new Anchor("website (external reference)", FontFactory.GetFont(FontFactory.HELVETICA, 12, Font.UNDERLINE, new Color(0, 0, 255)));
                anchor1.Reference = "http://itextsharp.sourceforge.net";
                anchor1.Name = "top";
                paragraph.Add(anchor1);
                paragraph.Add(new Chunk(".\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
                document.Add(paragraph);
                Anchor anchor2 = new Anchor("please jump to a local destination", FontFactory.GetFont(FontFactory.HELVETICA, 12, Font.NORMAL, new Color(0, 0, 255)));
                anchor2.Reference = "#top";
                document.Add(anchor2);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }
        #endregion //Chapter 3

        #region Chapter 4
        //See http://itextsharp.sourceforge.net/tutorial/ch04.html
        public bool Chap0401(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 4 example 1: Headers en Footers");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2: we create a writer that listens to the document
                PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // we Add a Footer that will show up on PAGE 1
                HeaderFooter footer = new HeaderFooter(new Phrase("This is page: "), true);
                footer.Border = Rectangle.NO_BORDER;
                document.Footer = footer;

                // step 3: we open the document
                document.Open();

                // we Add a Header that will show up on PAGE 2
                HeaderFooter header = new HeaderFooter(new Phrase("This is a header"), false);
                document.Header = header;

                // step 4: we Add content to the document

                // PAGE 1
                document.Add(new Paragraph("Hello World"));
                // we trigger a page break
                document.NewPage();

                // PAGE 2
                // we Add some more content
                document.Add(new Paragraph("Hello Earth"));
                // we remove the header starting from PAGE 3
                document.ResetHeader();
                // we trigger a page break
                document.NewPage();

                // PAGE 3
                // we Add some more content
                document.Add(new Paragraph("Hello Sun"));
                document.Add(new Paragraph("Remark: the header has vanished!"));
                // we reset the page numbering
                document.ResetPageCount();
                // we trigger a page break
                document.NewPage();

                // PAGE 4
                // we Add some more content
                document.Add(new Paragraph("Hello Moon"));
                document.Add(new Paragraph("Remark: the pagenumber has been reset!"));

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch04.html
        public bool Chap0402(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 4 example 2: Chapters and Sections");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2: we create a writer that listens to the document
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));
                // step 3: we open the document
                document.Open();
                // step 4: we Add content to the document
                // we define some fonts
                Font chapterFont = FontFactory.GetFont(FontFactory.HELVETICA, 24, Font.NORMAL, new Color(255, 0, 0));
                Font sectionFont = FontFactory.GetFont(FontFactory.HELVETICA, 20, Font.NORMAL, new Color(0, 0, 255));
                Font subsectionFont = FontFactory.GetFont(FontFactory.HELVETICA, 18, Font.BOLD, new Color(0, 64, 64));
                // we create some paragraphs
                Paragraph blahblah = new Paragraph("blah blah blah blah blah blah blaah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah");
                Paragraph blahblahblah = new Paragraph("blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blaah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah");
                // this loop will create 7 chapters
                for (int i = 1; i < 8; i++)
                {
                    Paragraph cTitle = new Paragraph("This is chapter " + i, chapterFont);
                    Chapter chapter = new Chapter(cTitle, i);

                    if (i == 4)
                    {
                        blahblahblah.Alignment = Element.ALIGN_JUSTIFIED;
                        blahblah.Alignment = Element.ALIGN_JUSTIFIED;
                        chapter.Add(blahblah);
                    }
                    if (i == 5)
                    {
                        blahblahblah.Alignment = Element.ALIGN_CENTER;
                        blahblah.Alignment = Element.ALIGN_RIGHT;
                        chapter.Add(blahblah);
                    }
                    // Add a table in the 6th chapter
                    if (i == 6)
                    {
                        blahblah.Alignment = Element.ALIGN_JUSTIFIED;
                    }
                    // in every chapter 3 sections will be Added
                    for (int j = 1; j < 4; j++)
                    {
                        Paragraph sTitle = new Paragraph("This is section " + j + " in chapter " + i, sectionFont);
                        Section section = chapter.AddSection(sTitle, 1);
                        // in all chapters except the 1st one, some extra text is Added to section 3
                        if (j == 3 && i > 1)
                        {
                            section.Add(blahblah);
                        }
                        // in every section 3 subsections are Added
                        for (int k = 1; k < 4; k++)
                        {
                            Paragraph subTitle = new Paragraph("This is subsection " + k + " of section " + j, subsectionFont);
                            Section subsection = section.AddSection(subTitle, 3);
                            if (k == 1 && j == 3)
                            {
                                subsection.Add(blahblahblah);
                            }
                            subsection.Add(blahblah);
                        }
                        if (j == 2 && i > 2)
                        {
                            section.Add(blahblahblah);
                        }
                    }
                    document.Add(chapter);
                }

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch04.html
        public bool Chap0403(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 4 example 3: Chapters and Sections");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2: we create a writer that listens to the document
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));
                
                // step 3: we open the document
                document.Open();
                
                // step 4: we Add content to the document
                Paragraph title1 = new Paragraph("This is Chapter 1", FontFactory.GetFont(FontFactory.HELVETICA, 18, Font.BOLDITALIC, new Color(0, 0, 255)));
                Chapter chapter1 = new Chapter(title1, 2);
                chapter1.NumberDepth = 0;
                Paragraph someText = new Paragraph("This is some text");
                chapter1.Add(someText);

                Paragraph title11 = new Paragraph("This is Section 1 in Chapter 1", FontFactory.GetFont(FontFactory.HELVETICA, 16, Font.BOLD, new Color(255, 0, 0)));
                Section section1 = chapter1.AddSection(title11);
                Paragraph someSectionText = new Paragraph("This is some silly paragraph in a chapter and/or section. It contains some text to test the functionality of Chapters and Section.");
                section1.Add(someSectionText);
                
                document.Add(chapter1);

                Paragraph title2 = new Paragraph("This is Chapter 2", FontFactory.GetFont(FontFactory.HELVETICA, 18, Font.BOLDITALIC, new Color(0, 0, 255)));
                Chapter chapter2 = new Chapter(title2, 2);
                chapter2.NumberDepth = 0;
                chapter2.Add(someText);

                Paragraph title21 = new Paragraph("This is Section 1 in Chapter 2", FontFactory.GetFont(FontFactory.HELVETICA, 16, Font.BOLD, new Color(255, 0, 0)));
                Section section2 = chapter2.AddSection(title21);
                section2.Add(someSectionText);
                chapter2.BookmarkOpen = false;

                document.Add(chapter2);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch04.html
        public bool Chap0404(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 4 example 4: Simple Graphic");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

#if true
                Paragraph paragraph = new Paragraph("Graphic Object Deprecated: ");
                Anchor anchor1 = new Anchor("Will this site help?", FontFactory.GetFont(FontFactory.HELVETICA, 12, Font.UNDERLINE, new Color(0, 0, 255)));
                anchor1.Reference = "http://www.nabble.com/HR-Using-PageEvent-vs-Deprecated-Graphic-Object-t3356791.html";
                anchor1.Name = "top";
                paragraph.Add(anchor1);
                paragraph.Add(new Chunk(".\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
                document.Add(paragraph);
                Anchor anchor2 = new Anchor("please jump to a local destination", FontFactory.GetFont(FontFactory.HELVETICA, 12, Font.NORMAL, new Color(0, 0, 255)));
                anchor2.Reference = "#top";
                document.Add(anchor2);
#else
                // step 4: we add a Graphic to the document
                Graphic grx = new Graphic();
                // add a rectangle
                grx.rectangle(100, 700, 100, 100);
                // add the diagonal
                grx.moveTo(100, 700);
                grx.lineTo(200, 800);
                // stroke the lines
                grx.stroke();
                document.Add(grx);
#endif

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch04.html
        public bool Chap0405(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 4 example 5: page borders and horizontal lines");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

#if true
                Paragraph paragraph = new Paragraph("Graphic Object Deprecated: ");
                Anchor anchor1 = new Anchor("Will this site help?", FontFactory.GetFont(FontFactory.HELVETICA, 12, Font.UNDERLINE, new Color(0, 0, 255)));
                anchor1.Reference = "http://www.nabble.com/HR-Using-PageEvent-vs-Deprecated-Graphic-Object-t3356791.html";
                anchor1.Name = "top";
                paragraph.Add(anchor1);
                paragraph.Add(new Chunk(".\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
                document.Add(paragraph);
                Anchor anchor2 = new Anchor("please jump to a local destination", FontFactory.GetFont(FontFactory.HELVETICA, 12, Font.NORMAL, new Color(0, 0, 255)));
                anchor2.Reference = "#top";
                document.Add(anchor2);
#else
                // step 4: we Add a paragraph to the document
                Graphic g = new Graphic();
                g.setBorder(3f, 5f);
                document.Add(g);
                document.Add(new Paragraph("Hello World"));
                document.Add(new Paragraph("Hello World\n\n"));
                g = new Graphic();
                g.setHorizontalLine(5f, 100f);
                document.Add(g);
                document.Add(new Paragraph("Hello World"));
                document.Add(new Paragraph("Hello World\n\n"));
                g = new Graphic();
                g.setHorizontalLine(2f, 80f, new Color(0xFF, 0x00, 0x00));
                document.Add(g);
                document.Add(new Paragraph("Hello World"));
#endif

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }
        #endregion //Chapter 4

        #region Chapter 5
        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0501(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 1: My First Table");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();
                // step 4: we create a table and add it to the document
                Table aTable = new Table(2, 2);    // 2 rows, 2 columns
                aTable.AddCell("0.0");
                aTable.AddCell("0.1");
                aTable.AddCell("1.0");
                aTable.AddCell("1.1");
                document.Add(aTable);           

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0502(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 2: adding cells at a specific position");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                Table aTable;

                aTable = new Table(4, 4);    // 4 rows, 4 columns
                aTable.AutoFillEmptyCells = true;
                aTable.AddCell("2.2", new System.Drawing.Point(2, 2));
                aTable.AddCell("3.3", new System.Drawing.Point(3, 3));
                aTable.AddCell("2.1", new System.Drawing.Point(2, 1));
                aTable.AddCell("1.3", new System.Drawing.Point(1, 3));
                document.Add(aTable);
                document.NewPage();

                aTable = new Table(4, 4);    // 4 rows, 4 columns
                aTable.AddCell("2.2", new System.Drawing.Point(2, 2));
                aTable.AddCell("3.3", new System.Drawing.Point(3, 3));
                aTable.AddCell("2.1", new System.Drawing.Point(2, 1));
                aTable.AddCell("1.3", new System.Drawing.Point(1, 3));
                document.Add(aTable);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0503(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 3: Rows Added Automatically");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: we create a table and add it to the document
                Table aTable = new Table(4, 4);    // 4 rows, 4 columns
                aTable.AutoFillEmptyCells = true;
                aTable.AddCell("2.2", new System.Drawing.Point(2, 2));
                aTable.AddCell("3.3", new System.Drawing.Point(3, 3));
                aTable.AddCell("2.1", new System.Drawing.Point(2, 1));
                aTable.AddCell("1.3", new System.Drawing.Point(1, 3));
                aTable.AddCell("5.2", new System.Drawing.Point(5, 2));
                aTable.AddCell("6.1", new System.Drawing.Point(6, 1));
                aTable.AddCell("5.0", new System.Drawing.Point(5, 0));
                document.Add(aTable);                      

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0504(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 4: Adding Columns");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                //document.Add(new Paragraph("TO DO"));
                ////.... TO DO
                // step 4: we create a table and add it to the document
                Table aTable = new Table(2, 2);    // 2 rows, 2 columns
                aTable.AutoFillEmptyCells = true;
                aTable.AddCell("0.0");
                aTable.AddCell("0.1");
                aTable.AddCell("1.0");
                aTable.AddCell("1.1");
                aTable.AddColumns(2);
                float[] f = { 1f, 1f, 1f, 1f };
                aTable.Widths = f;
                aTable.AddCell("2.2", new System.Drawing.Point(2, 2));
                aTable.AddCell("3.3", new System.Drawing.Point(3, 3));
                aTable.AddCell("2.1", new System.Drawing.Point(2, 1));
                aTable.AddCell("1.3", new System.Drawing.Point(1, 3));
                aTable.AddCell("5.2", new System.Drawing.Point(5, 2));
                aTable.AddCell("6.1", new System.Drawing.Point(6, 1));
                aTable.AddCell("5.0", new System.Drawing.Point(5, 0));
                document.Add(aTable);  

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0505(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 5: colspan, rowspan, padding, spacing, colors");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                //Adds content to the document:
                //document.Add(new Paragraph("TO DO"));
                ////.... TO DO
                // step 4: we create a table and add it to the document
                Table table = new Table(3);
                table.BorderWidth = 1;
                table.BorderColor = new Color(0, 0, 255);
                table.Padding = 5;
                table.Spacing = 5;
                Cell cell = new Cell("header");
                cell.Header = true;
                cell.Colspan = 3;
                table.AddCell(cell);
                cell = new Cell("example cell with colspan 1 and rowspan 2");
                cell.Rowspan = 2;
                cell.BorderColor = new Color(255, 0, 0);
                table.AddCell(cell);
                table.AddCell("1.1");
                table.AddCell("2.1");
                table.AddCell("1.2");
                table.AddCell("2.2");
                table.AddCell("cell test1");
                cell = new Cell("big cell");
                cell.Rowspan = 2;
                cell.Colspan = 2;
                cell.BackgroundColor = new Color(0xC0, 0xC0, 0xC0);
                table.AddCell(cell);
                table.AddCell("cell test2");
                document.Add(table);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }


        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0506(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 6: spacing, padding, alignment");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: we create a table and add it to the document
                Table table = new Table(3);
                table.BorderWidth = 1;
                table.BorderColor = new Color(0, 0, 255);
                table.Padding = 3;
                table.Spacing = 1;
                Cell cell = new Cell("header");
                cell.Header = true;
                cell.Colspan = 3;
                table.AddCell(cell);
                cell = new Cell("example cell with colspan 1 and rowspan 2");
                cell.Rowspan = 2;
                cell.BorderColor = new Color(255, 0, 0);
                table.AddCell(cell);
                table.AddCell("1.1");
                table.AddCell("2.1");
                table.AddCell("1.2");
                table.AddCell("2.2");
                table.AddCell("cell test1");
                cell = new Cell("big cell");
                cell.Rowspan = 2;
                cell.Colspan = 2;
                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.BackgroundColor = new Color(0xC0, 0xC0, 0xC0);
                table.AddCell(cell);
                table.AddCell("cell test2");
                document.Add(table);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }


        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0507(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 7: borders");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: we create a table and add it to the document
                Table table = new Table(3);
                table.BorderWidth = 1;
                table.BorderColor = new Color(0, 0, 255);
                table.Border = Rectangle.TOP_BORDER | Rectangle.BOTTOM_BORDER;
                table.Padding = 5;
                table.Spacing = 5;
                Cell cell = new Cell("header");
                cell.Header = true;
                cell.BorderWidth = 3;
                cell.Border = Rectangle.TOP_BORDER | Rectangle.BOTTOM_BORDER;
                cell.Colspan = 3;
                table.AddCell(cell);
                cell = new Cell("example cell with colspan 1 and rowspan 2");
                cell.Rowspan = 2;
                cell.BorderColor = new Color(255, 0, 0);
                cell.Border = Rectangle.LEFT_BORDER | Rectangle.BOTTOM_BORDER;
                table.AddCell(cell);
                table.AddCell("1.1");
                table.AddCell("2.1");
                table.AddCell("1.2");
                table.AddCell("2.2");
                table.AddCell("cell test1");
                cell = new Cell("big cell");
                cell.Rowspan = 2;
                cell.Colspan = 2;
                cell.Border = Rectangle.NO_BORDER;
                cell.GrayFill = 0.9f;
                table.AddCell(cell);
                table.AddCell("cell test2");
                document.Add(table);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }


        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0508(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 8: table splitting");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

			    // step 4: we create a table and add it to the document
			    Table table = new Table(3);
			    table.BorderWidth = 1;
			    table.BorderColor = new Color(0, 0, 255);
			    table.Padding = 5;
			    table.Spacing = 5;
			    Cell cell = new Cell("header");
			    cell.Header = true;
			    cell.Colspan = 3;
			    table.AddCell(cell);
			    cell = new Cell("example cell with colspan 1 and rowspan 2");
			    cell.Rowspan = 2;
			    cell.BorderColor = new Color(255, 0, 0);
			    table.AddCell(cell);
			    table.AddCell("1.1");
			    table.AddCell("2.1");
			    table.AddCell("1.2");
			    table.AddCell("2.2");
			    table.AddCell("cell test1");
			    cell = new Cell("big cell");
			    cell.Rowspan = 2;
			    cell.Colspan = 2;
			    cell.BackgroundColor = new Color(0xC0, 0xC0, 0xC0);
			    table.AddCell(cell);
			    table.AddCell("cell test2");
			    document.Add(new Paragraph("repeating the same table 10 times:"));
                for (int i = 0; i < 10; i++)
                {
                    document.Add(table);
                }

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }


        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0509(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 9: large tables");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // we add some meta information to the document
                document.AddAuthor("Gerald Henson");
                document.AddSubject("This is the result of a Test.");

                // step 3: we open the document
                document.Open();

                // step 4: we create a table and add it to the document
                Table datatable = new Table(10);
                datatable.Padding = 4;
                datatable.Spacing = 0;
                //datatable.setBorder(Rectangle.NO_BORDER);
                float[] headerwidths = { 10, 24, 12, 12, 7, 7, 7, 7, 7, 7 };
                datatable.Widths = headerwidths;
                datatable.WidthPercentage = 100;

                // the first cell spans 10 columns
                Cell cell = new Cell(new Phrase("Administration -System Users Report", FontFactory.GetFont(FontFactory.HELVETICA, 24, Font.BOLD)));
                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                cell.Leading = 30;
                cell.Colspan = 10;
                cell.Border = Rectangle.NO_BORDER;
                cell.BackgroundColor = new Color(0xC0, 0xC0, 0xC0);
                datatable.AddCell(cell);

                // These cells span 2 rows
                datatable.DefaultCellBorderWidth = 2;
                datatable.DefaultHorizontalAlignment = 1;
                datatable.DefaultRowspan = 2;
                datatable.AddCell("User Id");
                datatable.AddCell(new Phrase("Name", FontFactory.GetFont(FontFactory.HELVETICA, 14, Font.BOLD)));
                datatable.AddCell("Company");
                datatable.AddCell("Department");

                // This cell spans the remaining 6 columns in 1 row
                datatable.DefaultRowspan = 1;
                datatable.DefaultColspan = 6;
                datatable.AddCell("Permissions");

                // These cells span 1 row and 1 column
                datatable.DefaultColspan = 1;
                datatable.AddCell("Admin");
                datatable.AddCell("Data");
                datatable.AddCell("Expl");
                datatable.AddCell("Prod");
                datatable.AddCell("Proj");
                datatable.AddCell("Online");

                datatable.DefaultCellBorderWidth = 1;
                datatable.DefaultRowspan = 1;

                for (int i = 1; i < 30; i++)
                {
                    datatable.DefaultHorizontalAlignment = Element.ALIGN_LEFT;

                    datatable.AddCell("myUserId");
                    datatable.AddCell("Somebody with a very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very long long name");
                    datatable.AddCell("No Name Company");
                    datatable.AddCell("D" + i);

                    datatable.DefaultHorizontalAlignment = Element.ALIGN_CENTER;
                    datatable.AddCell("No");
                    datatable.AddCell("Yes");
                    datatable.AddCell("No");
                    datatable.AddCell("Yes");
                    datatable.AddCell("No");
                    datatable.AddCell("Yes");
                }

                document.Add(datatable);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }


        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0510(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 10: large tables with repeating headers");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                //Adds content to the document:
                //document.Add(new Paragraph("TO DO"));
                ////.... TO DO
                // step 4: we create a table and add it to the document
                Table datatable = new Table(10);

                datatable.Padding = 4;
                datatable.Spacing = 0;
                //datatable.setBorder(Rectangle.NO_BORDER);
                float[] headerwidths = { 10, 24, 12, 12, 7, 7, 7, 7, 7, 7 };
                datatable.Widths = headerwidths;
                datatable.WidthPercentage = 100;

                // the first cell spans 10 columns
                Cell cell = new Cell(new Phrase("Administration -System Users Report", FontFactory.GetFont(FontFactory.HELVETICA, 24, Font.BOLD)));
                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                cell.Leading = 30;
                cell.Colspan = 10;
                cell.Border = Rectangle.NO_BORDER;
                cell.BackgroundColor = new Color(0xC0, 0xC0, 0xC0);
                datatable.AddCell(cell);

                // These cells span 2 rows
                datatable.DefaultCellBorderWidth = 2;
                datatable.DefaultHorizontalAlignment = 1;
                datatable.DefaultRowspan = 2;
                datatable.AddCell("User Id");
                datatable.AddCell(new Phrase("Name", FontFactory.GetFont(FontFactory.HELVETICA, 14, Font.BOLD)));
                datatable.AddCell("Company");
                datatable.AddCell("Department");

                // This cell spans the remaining 6 columns in 1 row
                datatable.DefaultRowspan = 1;
                datatable.DefaultColspan = 6;
                datatable.AddCell("Permissions");

                // These cells span 1 row and 1 column
                datatable.DefaultColspan = 1;
                datatable.AddCell("Admin");
                datatable.AddCell("Data");
                datatable.AddCell("Expl");
                datatable.AddCell("Prod");
                datatable.AddCell("Proj");
                datatable.AddCell("Online");

                // this is the end of the table header
                datatable.EndHeaders();

                datatable.DefaultCellBorderWidth = 1;
                datatable.DefaultRowspan = 1;

                for (int i = 1; i < 30; i++)
                {
                    datatable.DefaultHorizontalAlignment = Element.ALIGN_LEFT;

                    datatable.AddCell("myUserId");
                    datatable.AddCell("Somebody with a very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very long long name");
                    datatable.AddCell("No Name Company");
                    datatable.AddCell("D" + i);

                    datatable.DefaultHorizontalAlignment = Element.ALIGN_CENTER;
                    datatable.AddCell("No");
                    datatable.AddCell("Yes");
                    datatable.AddCell("No");
                    datatable.AddCell("Yes");
                    datatable.AddCell("No");
                    datatable.AddCell("Yes");
                }

                document.Add(datatable);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0511(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 11: avoid table splitting");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                //Adds content to the document:
                // step 4: we create a table and add it to the document
                Table table = new Table(3);
                table.TableFitsPage = true;
                table.BorderWidth = 1;
                table.BorderColor = new Color(0, 0, 255);
                table.Padding = 5;
                table.Spacing = 5;
                Cell cell = new Cell("header");
                cell.Header = true;
                cell.Colspan = 3;
                table.AddCell(cell);
                cell = new Cell("example cell with colspan 1 and rowspan 2");
                cell.Rowspan = 2;
                cell.BorderColor = new Color(255, 0, 0);
                table.AddCell(cell);
                table.AddCell("1.1");
                table.AddCell("2.1");
                table.AddCell("1.2");
                table.AddCell("2.2");
                table.AddCell("cell test1");
                cell = new Cell("big cell");
                cell.Rowspan = 2;
                cell.Colspan = 2;
                cell.BackgroundColor = new Color(0xC0, 0xC0, 0xC0);
                table.AddCell(cell);
                table.AddCell("cell test2");
                document.Add(new Paragraph("repeating the same table 10 times:"));
                for (int i = 0; i < 10; i++)
                {
                    document.Add(table);
                }

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0512(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 12: avoid cell splitting");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // we add some meta information to the document
                document.AddAuthor("Gerald Henson");
                document.AddSubject("This is the result of a Test.");

                // step 3: we open the document
                document.Open();

                //Adds content to the document:
                // step 4: we create a table and add it to the document
                Table datatable = new Table(10);
                datatable.CellsFitPage = true;

                datatable.Padding = 4;
                datatable.Spacing = 0;
                //datatable.setBorder(Rectangle.NO_BORDER);
                float[] headerwidths = { 10, 24, 12, 12, 7, 7, 7, 7, 7, 7 };
                datatable.Widths = headerwidths;
                datatable.WidthPercentage = 100;

                // the first cell spans 10 columns
                Cell cell = new Cell(new Phrase("Administration -System Users Report", FontFactory.GetFont(FontFactory.HELVETICA, 24, Font.BOLD)));
                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                cell.Leading = 30;
                cell.Colspan = 10;
                cell.Border = Rectangle.NO_BORDER;
                cell.BackgroundColor = new Color(0xC0, 0xC0, 0xC0);
                datatable.AddCell(cell);

                // These cells span 2 rows
                datatable.DefaultCellBorderWidth = 2;
                datatable.DefaultHorizontalAlignment = 1;
                datatable.DefaultRowspan = 2;
                datatable.AddCell("User Id");
                datatable.AddCell(new Phrase("Name", FontFactory.GetFont(FontFactory.HELVETICA, 14, Font.BOLD)));
                datatable.AddCell("Company");
                datatable.AddCell("Department");

                // This cell spans the remaining 6 columns in 1 row
                datatable.DefaultRowspan = 1;
                datatable.DefaultColspan = 6;
                datatable.AddCell("Permissions");

                // These cells span 1 row and 1 column
                datatable.DefaultColspan = 1;
                datatable.AddCell("Admin");
                datatable.AddCell("Data");
                datatable.AddCell("Expl");
                datatable.AddCell("Prod");
                datatable.AddCell("Proj");
                datatable.AddCell("Online");

                // this is the end of the table header
                datatable.EndHeaders();

                datatable.DefaultCellBorderWidth = 1;
                datatable.DefaultRowspan = 1;

                for (int i = 1; i < 30; i++)
                {
                    datatable.DefaultHorizontalAlignment = Element.ALIGN_LEFT;

                    datatable.AddCell("myUserId");
                    datatable.AddCell("Somebody with a very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very long long name");
                    datatable.AddCell("No Name Company");
                    datatable.AddCell("D" + i);

                    datatable.DefaultHorizontalAlignment = Element.ALIGN_CENTER;
                    datatable.AddCell("No");
                    datatable.AddCell("Yes");
                    datatable.AddCell("No");
                    datatable.AddCell("Yes");
                    datatable.AddCell("No");
                    datatable.AddCell("Yes");
                }

                document.Add(datatable);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0513(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 13: large tables with FitsPage");

            // step 1: creation of a document-object
            // creation of the document with a certain size and certain margins
            //   WARNING: "A4" is a non-US paper size
            Document document = new Document(PageSize.A4.Rotate(), 50, 50, 50, 50);

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));
 
                // we add some meta information to the document
                document.AddAuthor("Alan Soukup");
                document.AddSubject("This is the result of a Test.");
 
                // step 3: we open the document
                document.Open();

                //Adds content to the document:
                // step 4: we create a table and add it to the document
                Table datatable = GetTable();

                for (int i = 1; i < 30; i++)
                {

                    datatable.DefaultHorizontalAlignment = Element.ALIGN_LEFT;

                    datatable.AddCell("myUserId");
                    datatable.AddCell("Somebody with a very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very long long name");
                    datatable.AddCell("No Name Company");
                    datatable.AddCell("D" + i);

                    datatable.DefaultHorizontalAlignment = Element.ALIGN_CENTER;
                    datatable.AddCell("No");
                    datatable.AddCell("Yes");
                    datatable.AddCell("No");
                    datatable.AddCell("Yes");
                    datatable.AddCell("No");
                    datatable.AddCell("Yes");

                    if (!writer.FitsPage(datatable))
                    {
                        datatable.DeleteLastRow();
                        i--;
                        document.Add(datatable);
                        document.NewPage();
                        datatable = GetTable();
                    }
                }

                document.Add(datatable);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        private static Table GetTable()
        {
            Table datatable = new Table(10);

            datatable.Padding = 4;
            datatable.Spacing = 0;
            //datatable.setBorder(Rectangle.NO_BORDER);
            float[] headerwidths = { 10, 24, 12, 12, 7, 7, 7, 7, 7, 7 };
            datatable.Widths = headerwidths;
            datatable.WidthPercentage = 100;

            // the first cell spans 10 columns
            Cell cell = new Cell(new Phrase("Administration -System Users Report", FontFactory.GetFont(FontFactory.HELVETICA, 24, Font.BOLD)));
            cell.HorizontalAlignment = Element.ALIGN_CENTER;
            cell.Leading = 30;
            cell.Colspan = 10;
            cell.Border = Rectangle.NO_BORDER;
            cell.BackgroundColor = new Color(0xC0, 0xC0, 0xC0);
            datatable.AddCell(cell);

            // These cells span 2 rows
            datatable.DefaultCellBorderWidth = 2;
            datatable.DefaultHorizontalAlignment = 1;
            datatable.DefaultRowspan = 2;
            datatable.AddCell("User Id");
            datatable.AddCell(new Phrase("Name", FontFactory.GetFont(FontFactory.HELVETICA, 14, Font.BOLD)));
            datatable.AddCell("Company");
            datatable.AddCell("Department");

            // This cell spans the remaining 6 columns in 1 row
            datatable.DefaultRowspan = 1;
            datatable.DefaultColspan = 6;
            datatable.AddCell("Permissions");

            // These cells span 1 row and 1 column
            datatable.DefaultColspan = 1;
            datatable.AddCell("Admin");
            datatable.AddCell("Data");
            datatable.AddCell("Expl");
            datatable.AddCell("Prod");
            datatable.AddCell("Proj");
            datatable.AddCell("Online");

            datatable.DefaultCellBorderWidth = 1;
            datatable.DefaultRowspan = 1;

            return datatable;
        }


        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0514(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 14: nested tables");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                //Adds content to the document:
                // step 4: we create a table and add it to the document
                // simple example

                Table secondTable = new Table(2);
                secondTable.AddCell("2nd table 0.0");
                secondTable.AddCell("2nd table 0.1");
                secondTable.AddCell("2nd table 1.0");
                secondTable.AddCell("2nd table 1.1");

                Table aTable = new Table(4, 4);    // 4 rows, 4 columns
                aTable.AutoFillEmptyCells = true;
                aTable.AddCell("2.2", new System.Drawing.Point(2, 2));
                aTable.AddCell("3.3", new System.Drawing.Point(3, 3));
                aTable.AddCell("2.1", new System.Drawing.Point(2, 1));
                aTable.InsertTable(secondTable, new System.Drawing.Point(1, 3));
                document.Add(aTable);

                // example with 2 nested tables

                Table thirdTable = new Table(2);
                thirdTable.AddCell("3rd table 0.0");
                thirdTable.AddCell("3rd table 0.1");
                thirdTable.AddCell("3rd table 1.0");
                thirdTable.AddCell("3rd table 1.1");

                aTable = new Table(5, 5);
                aTable.AutoFillEmptyCells = true;
                aTable.AddCell("2.2", new System.Drawing.Point(2, 2));
                aTable.AddCell("3.3", new System.Drawing.Point(3, 3));
                aTable.AddCell("2.1", new System.Drawing.Point(2, 1));
                aTable.InsertTable(secondTable, new System.Drawing.Point(1, 3));
                aTable.InsertTable(thirdTable, new System.Drawing.Point(6, 2));
                document.Add(aTable);

                // relative column widths are preserved

                Table a = new Table(2);
                a.Widths = new float[] { 85, 15 };
                a.AddCell("a-1");
                a.AddCell("a-2");

                Table b = new Table(5);
                b.Widths = new float[] { 15, 7, 7, 7, 7 };
                b.AddCell("b-1");
                b.AddCell("b-2");
                b.AddCell("b-3");
                b.AddCell("b-4");
                b.AddCell("b-5");

                // now, insert these 2 tables into a third for layout purposes
                Table c = new Table(3, 1);
                c.WidthPercentage = 100.0f;
                c.Widths = new float[] { 20, 2, 78 };
                c.InsertTable(a, new System.Drawing.Point(0, 0));
                c.InsertTable(b, new System.Drawing.Point(0, 2));

                document.Add(c);

                // adding extra cells after adding a table

                Table t1 = new Table(3);
                t1.AddCell("1.1");
                t1.AddCell("1.2");
                t1.AddCell("1.3");
                // nested
                Table t2 = new Table(2);
                t2.AddCell("2.1");
                t2.AddCell("2.2");

                // now insert the nested
                t1.InsertTable(t2);
                t1.AddCell("new cell");    // correct row/column ?
                document.Add(t1);

                // deep nesting

                t1 = new Table(2, 2);
                for (int i = 0; i < 4; i++)
                {
                    t1.AddCell("t1");
                }

                t2 = new Table(3, 3);
                for (int i = 0; i < 9; i++)
                {
                    if (i == 4) t2.InsertTable(t1);
                    else t2.AddCell("t2");
                }

                Table t3 = new Table(4, 4);
                for (int i = 0; i < 16; i++)
                {
                    if (i == 10) t3.InsertTable(t2);
                    else t3.AddCell("t3");
                }

                document.Add(t3); 

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0515(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 15: nested tables 2");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                //Adds content to the document:
                // step 4: we create a table and add it to the document
                Table secondTable = new Table(2);
                secondTable.AddCell("2.0.0");
                secondTable.AddCell("2.0.1");
                secondTable.AddCell("2.1.0");
                secondTable.AddCell("2.1.1");
                Cell tableCell = new Cell(secondTable);

                Table aTable = new Table(3, 3);    // 3 rows, 3 columns
                aTable.AddCell("0.0", new System.Drawing.Point(0, 0));
                aTable.AddCell("0.1", new System.Drawing.Point(0, 1));
                aTable.AddCell("0.2", new System.Drawing.Point(0, 2));
                aTable.AddCell("0.0", new System.Drawing.Point(1, 0));
                aTable.AddCell(tableCell, new System.Drawing.Point(1, 1));
                aTable.AddCell("2.2", new System.Drawing.Point(1, 2));
                aTable.AddCell("2.0", new System.Drawing.Point(2, 0));
                aTable.AddCell("2.1", new System.Drawing.Point(2, 1));
                aTable.AddCell("2.2", new System.Drawing.Point(2, 2));
                document.Add(aTable);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0516(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 16: nested tables 3");

            // step 1: creation of a document-object
            // creation of the document with a certain size and default margins
            //   WARNING: "A4" is a non-US paper size
            Document document = new Document(PageSize.A4.Rotate());

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                //Adds content to the document:
                // step 4: we create a table and add it to the document
                Table secondTable = new Table(2);
                secondTable.AddCell("2nd table 0.0");
                secondTable.AddCell("2nd table 0.1");
                secondTable.AddCell("2nd table 1.0");
                secondTable.AddCell("2nd table 1.1");
                Cell tableCell = new Cell("This is a nested table");
                tableCell.Add(secondTable);

                Table aTable = new Table(3, 3);    // 3 rows, 3 columns
                aTable.AddCell("0.0", new System.Drawing.Point(0, 0));
                aTable.AddCell("0.1", new System.Drawing.Point(0, 1));
                aTable.AddCell("0.2", new System.Drawing.Point(0, 2));
                aTable.AddCell("0.0", new System.Drawing.Point(1, 0));
                aTable.AddCell(tableCell, new System.Drawing.Point(1, 1));
                aTable.AddCell("2.2", new System.Drawing.Point(1, 2));
                aTable.AddCell("2.0", new System.Drawing.Point(2, 0));
                aTable.AddCell("2.1", new System.Drawing.Point(2, 1));
                aTable.AddCell("2.2", new System.Drawing.Point(2, 2));
                document.Add(aTable);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0517(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 17: table offset");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                //Adds content to the document:
                // step 4: we create a table and add it to the document
                // step 4: we create a table and add it to the document
                Table table = new Table(3);
                table.BorderWidth = 1;
                table.BorderColor = new Color(0, 0, 255);
                table.Padding = 5;
                table.Spacing = 5;
                Cell cell = new Cell("header");
                cell.Header = true;
                cell.Colspan = 3;
                table.AddCell(cell);
                cell = new Cell("example cell with colspan 1 and rowspan 2");
                cell.Rowspan = 2;
                cell.BorderColor = new Color(255, 0, 0);
                table.AddCell(cell);
                table.AddCell("1.1");
                table.AddCell("2.1");
                table.AddCell("1.2");
                table.AddCell("2.2");
                table.AddCell("cell test1");
                cell = new Cell("big cell");
                cell.Rowspan = 2;
                cell.Colspan = 2;
                cell.BackgroundColor = new Color(0xC0, 0xC0, 0xC0);
                table.AddCell(cell);
                table.AddCell("cell test2");
                document.Add(new Paragraph("repeating the same table 10 times, but with different offsets:"));
                document.Add(table);
                document.Add(new Paragraph("blah blah."));
                document.Add(table);
                document.Add(new Paragraph("we increase the offset."));
                table.Offset = 32;
                document.Add(table);
                document.Add(new Paragraph("blah blah."));
                document.Add(table);
                document.Add(new Paragraph("blah blah."));
                document.Add(table);
                document.Add(new Paragraph("we use an offset 0."));
                table.Offset = 0;
                document.Add(table);
                document.Add(new Paragraph("blah blah."));
                document.Add(table);
                document.Add(new Paragraph("blah blah."));
                document.Add(table);
                document.Add(new Paragraph("A negative offset."));
                table.Offset = -16;
                document.Add(table);
                document.Add(new Paragraph("blah blah."));
                document.Add(table);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch05.html
        public bool Chap0518(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 5 example 18: PdfPTable");

            // step 1: creation of a document-object
            // creation of the document with a certain size and certain margins
            //   WARNING: "A4" is a non-US paper size
            Document document = new Document(PageSize.A4.Rotate(), 10, 10, 10, 10);

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                //Adds content to the document:
                // step 4: we add content to the document (this happens in a seperate method)
                LoadDocument(document);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        private  void LoadDocument(Document document)
        {
            String[] bogusData = { "M0065920",
								 "SL",
								 "FR86000P",
								 "PCGOLD",
								 "119000",
								 "96 06",
								 "2001-08-13",
								 "4350",
								 "6011648299",
								 "FLFLMTGP",
								 "153",
								 "119000.00"
							 };
            int NumColumns = 12;
            try
            {
                // we add some meta information to the document

                PdfPTable datatable = new PdfPTable(NumColumns);

                datatable.DefaultCell.Padding = 3;
                float[] headerwidths = { 9, 4, 8, 10, 8, 11, 9, 7, 9, 10, 4, 10 }; // percentage
                datatable.SetWidths(headerwidths);
                datatable.WidthPercentage = 100; // percentage

                datatable.DefaultCell.BorderWidth = 2;
                datatable.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;
                datatable.AddCell("Clock #");
                datatable.AddCell("Trans Type");
                datatable.AddCell("Cusip");
                datatable.AddCell("Long Name");
                datatable.AddCell("Quantity");
                datatable.AddCell("Fraction Price");
                datatable.AddCell("Settle Date");
                datatable.AddCell("Portfolio");
                datatable.AddCell("ADP Number");
                datatable.AddCell("Account ID");
                datatable.AddCell("Reg Rep ID");
                datatable.AddCell("Amt To Go ");

                datatable.HeaderRows = 1;  // this is the end of the table header

                datatable.DefaultCell.BorderWidth = 1;

                int max = 666;
                for (int i = 1; i < max; i++)
                {
                    if (i % 2 == 1)
                    {
                        datatable.DefaultCell.GrayFill = 0.9f;
                    }
                    for (int x = 0; x < NumColumns; x++)
                    {
                        datatable.AddCell(bogusData[x]);
                    }
                    if (i % 2 == 1)
                    {
                        datatable.DefaultCell.GrayFill = 1.0f;
                    }
                }
                document.Add(datatable);
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.StackTrace);
            }
        }
        #endregion //Chapter 5

        #region Chapter 6
        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool Chap0601(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 6 example 1: ");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: 
                Image wmf = Image.GetInstance(new Uri("http://itextsharp.sourceforge.net/examples/harbour.wmf"));
                Image gif = Image.GetInstance(new Uri("http://itextsharp.sourceforge.net/examples/vonnegut.gif"));
                Image jpeg = Image.GetInstance(new Uri("http://itextsharp.sourceforge.net/examples/myKids.jpg"));
                Image png = Image.GetInstance(new Uri("http://itextsharp.sourceforge.net/examples/hitchcock.png"));

                document.Add(wmf);
                document.Add(gif);
                document.Add(jpeg);
                document.Add(png);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool Chap0602(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 6 example 2: Adding a Wmf, Gif, Jpeg and Png-file using filenames");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: 
#if true
                bool bInsertMsg = true;
                this.DoInsertImageFile(document, "vonnegut.gif", bInsertMsg);
                this.DoInsertImageFile(document, "myKids.jpg", bInsertMsg);
                this.DoInsertImageFile(document, "hitchcock.png", bInsertMsg);
#else
                Image gif = Image.GetInstance("vonnegut.gif");
                Image jpeg = Image.GetInstance("myKids.jpg");
                Image png = Image.GetInstance("hitchcock.png");

                document.Add(gif);
                document.Add(jpeg);
                document.Add(png);
#endif
                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool Chap0603(string sFilePDF)
        {
            bRet = false;

            //--- the original text was different
            //    "Chapter 6 example 3: using a relative path for HTML"
            Debug.WriteLine("Chapter 6 example 3: Inserting a Scaled Image File with relative path"); 

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: insert image (after scaling) info the document
#if true
                bool bInsertMsg = true;
                string sFilename = @"..\..\Images\myKids.jpg";
                Image jpg = this.DoGetImageFile(sFilename);
                if (jpg != null)
                {
                    jpg.ScalePercent(50f);
                    document.Add(jpg);
                }
                else
                {
                    if (bInsertMsg)
                        document.Add(new Paragraph(sFilename + " not found"));
                }
#else
                //--- example of scaling the image
			    Image jpg = Image.GetInstance("raf.jpg");
			    jpg.ScalePercent(50);
			    document.Add(jpg);
#endif

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool Chap0604(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 6 example 4: Alignment of images");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: 
                Image gif = this.DoGetImageFile(@"..\..\Images\vonnegut.gif");
                if (gif != null)
                {
                    gif.Alignment = Image.ALIGN_RIGHT;
                    document.Add(gif);
                }
                Image jpeg = this.DoGetImageFile(@"..\..\Images\myKids.jpg");
                if (jpeg != null)
                {
                    jpeg.Alignment = Image.ALIGN_MIDDLE;
                    document.Add(jpeg);
                }
                Image png = this.DoGetImageFile(@"..\..\Images\hitchcock.png");
                if (png != null)
                {
                    png.Alignment = Image.ALIGN_LEFT;
                    document.Add(png);
                }


                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool Chap0605(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 6 example 5: Alignment of images and text ");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: 
                Image gif = this.DoGetImageFile("vonnegut.gif");
                gif.Alignment = Image.ALIGN_RIGHT | Image.TEXTWRAP;
                Image jpeg = this.DoGetImageFile("myKids.jpg");
                jpeg.Alignment = Image.ALIGN_MIDDLE;
                Image png = this.DoGetImageFile("hitchcock.png");
                png.Alignment = Image.ALIGN_LEFT | Image.UNDERLYING;

                for (int i = 0; i < 100; i++)
                {
                    document.Add(new Phrase("Who is this? "));
                }
                document.Add(gif);
                for (int i = 0; i < 100; i++)
                {
                    document.Add(new Phrase("Who is this? "));
                }
                document.Add(jpeg);
                for (int i = 0; i < 100; i++)
                {
                    document.Add(new Phrase("Who is this? "));
                }
                document.Add(png);
                for (int i = 0; i < 100; i++)
                {
                    document.Add(new Phrase("Who is this? "));
                }
                document.Add(gif);
                for (int i = 0; i < 100; i++)
                {
                    document.Add(new Phrase("Who is this? "));
                }
                document.Add(jpeg);
                for (int i = 0; i < 100; i++)
                {
                    document.Add(new Phrase("Who is this? "));
                }
                document.Add(png);
                for (int i = 0; i < 100; i++)
                {
                    document.Add(new Phrase("Who is this? "));
                }

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool Chap0606(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 6 example 6: Absolute Positioning of an Image");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: 
                Image png = this.DoGetImageFile("hitchcock.png");
                png.SetAbsolutePosition(171, 250);
                document.Add(png);
                png.SetAbsolutePosition(342, 500);
                document.Add(png);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool Chap0607(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 6 example 7: Scaling an Image");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: we add content
                Image jpg1 = this.DoGetImageFile("myKids.jpg");
                jpg1.ScaleAbsolute(97, 101);
                document.Add(new Paragraph("scaleAbsolute(97, 101)"));
                document.Add(jpg1);
                Image jpg2 = this.DoGetImageFile("myKids.jpg");
                jpg2.ScalePercent(50);
                document.Add(new Paragraph("scalePercent(50)"));
                document.Add(jpg2);
                Image jpg3 = this.DoGetImageFile("myKids.jpg");
                jpg3.ScaleAbsolute(194, 101);
                document.Add(new Paragraph("scaleAbsolute(194, 101)"));
                document.Add(jpg3);
                Image jpg4 = this.DoGetImageFile("myKids.jpg");
                jpg4.ScalePercent(100, 50);
                document.Add(new Paragraph("scalePercent(100, 50)"));
                document.Add(jpg4);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool Chap0608(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 6 example 8: Rotating an Image");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: we add content
                Image jpg = this.DoGetImageFile("myKids.jpg");
                jpg.Alignment = Image.ALIGN_MIDDLE;

                jpg.Rotation = ((float)Math.PI / 6);
                document.Add(new Paragraph("rotate 30 degrees"));
                document.Add(jpg);
                document.NewPage();

                jpg.Rotation = ((float)Math.PI / 4);
                document.Add(new Paragraph("rotate 45 degrees"));
                document.Add(jpg);
                document.NewPage();

                jpg.Rotation = ((float)Math.PI / 2);
                document.Add(new Paragraph("rotate pi/2 radians"));
                document.Add(jpg);
                document.NewPage();

                jpg.Rotation = ((float)(Math.PI * 0.75));
                document.Add(new Paragraph("rotate 135 degrees"));
                document.Add(jpg);
                document.NewPage();

                jpg.Rotation = ((float)Math.PI);
                document.Add(new Paragraph("rotate pi radians"));
                document.Add(jpg);
                document.NewPage();

                jpg.Rotation = ((float)(2.0 * Math.PI));
                document.Add(new Paragraph("rotate 2 x pi radians"));
                document.Add(jpg);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }
        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool Chap0609(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 6 example 9: Inserting Raw Image Data");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: we add content (example by Paulo Soares)

                // creation a jpeg passed as an array of bytes to the Image
                string sFile = "mykids.jpg";
                if (this.DoLocateImageFile(ref sFile))
                {
                    FileStream rf = new FileStream("mykids.jpg", FileMode.Open, FileAccess.Read);
                    int size = (int)rf.Length;
                    byte[] imext = new byte[size];
                    rf.Read(imext, 0, size);
                    rf.Close();
                    Image img1 = Image.GetInstance(imext);
                    img1.SetAbsolutePosition(50, 500);
                    document.Add(img1);

                    // creation of an image of 100 x 100 pixels (x 3 bytes for the Red, Green and Blue value)
                    byte[] data = new byte[100 * 100 * 3];
                    for (int k = 0; k < 100; ++k)
                    {
                        for (int j = 0; j < 300; j += 3)
                        {
                            data[k * 300 + j] = (byte)(255 * Math.Sin(j * .5 * Math.PI / 300));
                            data[k * 300 + j + 1] = (byte)(256 - j * 256 / 300);
                            data[k * 300 + j + 2] = (byte)(255 * Math.Cos(k * .5 * Math.PI / 100));
                        }
                    }
                    Image img2 = Image.GetInstance(100, 100, 3, 8, data);
                    img2.SetAbsolutePosition(200, 200);
                    document.Add(img2);
                }
                else
                {
                    document.Add(new Paragraph(sFile + " not found"));
                }

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool Chap0610(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 6 example 10: Images using System.Drawing.Bitmap!");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: we add content to the document
                for (int i = 0; i < 300; i++)
                {
                    document.Add(new Phrase("Who is this? "));
                }
                PdfContentByte cb = writer.DirectContent;

                string sFile = "h.gif";
                if (this.DoLocateImageFile(ref sFile))
                {
                    System.Drawing.Imaging.ImageFormat fmt = System.Drawing.Imaging.ImageFormat.Bmp;
                    System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(sFile);
                    Image image = Image.GetInstance(bmp, fmt);
                    image.SetAbsolutePosition(100, 200);
                    cb.AddImage(image);
                }

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool Chap0611(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 6 example 11: TIFF and CCITT");

            // step 1: creation of a document-object
            // WARNING: Non-US 'A4' format
            Document document = new Document(PageSize.A4, 50, 50, 50, 50);

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file
                // creation of the different writers
                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                string sFile = "338814-00.tif";
                if (this.DoLocateImageFile(ref sFile))
                {
                    System.Drawing.Bitmap bm = new System.Drawing.Bitmap(sFile);
                    int total = bm.GetFrameCount(System.Drawing.Imaging.FrameDimension.Page);

                    Debug.WriteLine("Number of images in this TIFF: " + total);

                    // Which of the multiple images in the TIFF file do we want to load
                    // 0 refers to the first, 1 to the second and so on.

                    // step 3: we open the document
                    document.Open();

                    // step 4: 
                    PdfContentByte cb = writer.DirectContent;
                    for (int k = 0; k < total; ++k)
                    {
                        bm.SelectActiveFrame(System.Drawing.Imaging.FrameDimension.Page, k);
                        Image img = Image.GetInstance(bm, null, true);
                        img.ScalePercent(72f / 200f * 100);
                        img.SetAbsolutePosition(0, 0);
                        Debug.WriteLine("Image: " + k);
                        cb.AddImage(img);
                        document.NewPage();
                    }

                }

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool Chap0612(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 6 example 12: ");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: 
                document.Add(new Paragraph("TO DO"));
                ////.... TO DO

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool Chap0613(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 6 example 13: ");

            // step 1: creation of a document-object
            // WARNING: Non-US 'A4' format
            Document document = new Document(PageSize.A4, 50, 50, 50, 50);

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: 
                Paragraph p = new Paragraph("Some text behind a masked image.");
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);

                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);
                document.Add(p);

                PdfContentByte cb = writer.DirectContent;
                byte[] maskr = { (byte)0x3c, (byte)0x7e, (byte)0xe7, (byte)0xc3, (byte)0xc3, (byte)0xe7, (byte)0x7e, (byte)0x3c };
                Image mask = Image.GetInstance(8, 8, 1, 1, maskr);
                mask.MakeMask();
                mask.Inverted = true;
                Image image = this.DoGetImageFile("vonnegut.gif");
                image.ImageMask = mask;
                image.SetAbsolutePosition(60, 620);
                // explicit masking
                cb.AddImage(image);
                // stencil masking
                cb.SetRGBColorFill(255, 0, 0);
                cb.AddImage(mask, mask.ScaledWidth * 8, 0, 0, mask.ScaledHeight * 8, 100, 400);
                cb.SetRGBColorFill(0, 255, 0);
                cb.AddImage(mask, mask.ScaledWidth * 8, 0, 0, mask.ScaledHeight * 8, 200, 400);
                cb.SetRGBColorFill(0, 0, 255);
                cb.AddImage(mask, mask.ScaledWidth * 8, 0, 0, mask.ScaledHeight * 8, 300, 400);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool Chap0614(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 6 example 14: Images Wrapped in a Chunk");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: 
                Image img = this.DoGetImageFile("pngnow.png");
                img.ScalePercent(70);
                Chunk ck = new Chunk(img, 0, -5);
                Table table = new Table(3);
                table.WidthPercentage = 100;
                table.Padding = 2;
                table.DefaultHorizontalAlignment = Element.ALIGN_CENTER;
                Cell cell = new Cell(new Chunk(img, 0, -13));
                cell.BackgroundColor = new Color(0xC0, 0xC0, 0xC0);
                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                table.AddCell("I see an image\non my right");
                table.AddCell(cell);
                table.AddCell("I see an image\non my left");
                table.AddCell(cell);
                table.AddCell("I see images\neverywhere");
                table.AddCell(cell);
                table.AddCell("I see an image\non my right");
                table.AddCell(cell);
                table.AddCell("I see an image\non my left");

                Phrase p1 = new Phrase("This is an image ");
                p1.Add(ck);
                p1.Add(" just here.");
                document.Add(p1);
                document.Add(p1);
                document.Add(p1);
                document.Add(p1);
                document.Add(p1);
                document.Add(p1);
                document.Add(p1);
                document.Add(table);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool Chap0615(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 6 example 15: Images in Tables");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: we create a table and add it to the document
                Image img0 = this.DoGetImageFile("myKids.jpg");
                img0.Alignment = Image.ALIGN_MIDDLE;
                
                Image img1 = this.DoGetImageFile("pngnow.png");
                img1.Alignment = Image.ALIGN_LEFT | Image.UNDERLYING;
                
                Image img2 = this.DoGetImageFile("pngnow.png");
                img2.Alignment = Image.ALIGN_RIGHT | Image.TEXTWRAP;
                
                Image img3 = this.DoGetImageFile("pngnow.png");
                img3.Alignment = Image.ALIGN_LEFT;
                
                Image img4 = this.DoGetImageFile("pngnow.png");
                img4.Alignment = Image.ALIGN_MIDDLE;
                
                Image img5 = this.DoGetImageFile("pngnow.png");
                img5.Alignment = Image.ALIGN_RIGHT;
                
                Table table = new Table(3);
                table.Padding = 2;
                table.DefaultHorizontalAlignment = Element.ALIGN_CENTER;

                // row 1
                table.AddCell("I see an image\non my right");
                Cell cell = new Cell("This is the image (aligned in the middle):");
                cell.BackgroundColor = new Color(0xC0, 0xC0, 0xC0);
                cell.Add(img0);
                cell.Add(new Phrase("This was the image"));
                table.AddCell(cell);
                table.AddCell("I see an image\non my left");
                
                // row 2
                cell = new Cell("This is the image (left aligned):");
                cell.Add(img1);
                cell.Add(new Phrase("This was the image"));
                table.AddCell(cell);
                table.AddCell("I see images\neverywhere");
                cell = new Cell("This is the image (right aligned):");
                cell.Add(img2);
                cell.Add(new Phrase("This was the image"));
                table.AddCell(cell);
                
                // row 3
                table.AddCell("I see an image\non my right");
                cell = new Cell(img3);
                cell.Add(img4);
                cell.Add(img5);
                table.AddCell(cell);
                table.AddCell("I see an image\non my left");
                document.Add(table);

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool Chap0616(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 6 example 16: Images and Annotations");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: we add some content
                //Image wmf = Image.GetInstance(new Uri("http://itext.sourceforge.net/examples/harbour.wmf"));
                Image wmf = this.DoGetImageFile(@"..\..\Images\harbour.wmf");
                if (wmf != null)
                {
                    wmf.Annotation = new Annotation(0, 0, 0, 0, "http://www.lowagie.com");
                    wmf.SetAbsolutePosition(100f, 600f);
                    document.Add(wmf);
                }
                //Image gif = Image.GetInstance(new Uri("http://itext.sourceforge.net/examples/vonnegut.gif"));
                Image gif = this.DoGetImageFile(@"..\..\Images\vonnegut.gif");
                if (gif != null)
                {
                    gif.Annotation = new Annotation(0, 0, 0, 0, "Chap0610.pdf", 3);
                    gif.SetAbsolutePosition(100f, 400f);
                    document.Add(gif);
                }
                //Image jpeg = Image.GetInstance(new Uri("http://itext.sourceforge.net/examples/myKids.jpg"));
                Image jpeg = this.DoGetImageFile(@"..\..\Images\myKids.jpg");
                if (jpeg != null)
                {
                    jpeg.Annotation = new Annotation("picture", "These are my children", 0, 0, 0, 0);
                    jpeg.SetAbsolutePosition(100f, 150f);
                    document.Add(jpeg);
                }
                //Image png = Image.GetInstance(new Uri("http://itext.sourceforge.net/examples/hitchcock.png"));
                Image png = this.DoGetImageFile(@"..\..\Images\hitchcock.png");
                if (png != null)
                {
                    png.Annotation = new Annotation(0, 0, 0, 0, "Chap0610.pdf", "test");
                    png.SetAbsolutePosition(350f, 250f);
                    document.Add(png);
                }

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }

        #endregion //Chapter 6

        #region Chapter 7
        //--- To do
        #endregion //Chapter 7

        #region Chapter 8
        //--- To do
        #endregion //Chapter 8

        #region Chapter 9
        //--- To do
        #endregion //Chapter 9

        #region Chapter 10
        //--- To do
        #endregion //Chapter 10

        #region Chapter 11
        //--- To do
        #endregion //Chapter 11

        #region Chapter 12
        //--- To do
        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        #endregion //Chapter 12

        #region TO DO VERSION
        //--- To do
        //See http://itextsharp.sourceforge.net/tutorial/ch06.html
        public bool ChapCCXX(string sFilePDF)
        {
            bRet = false;

            Debug.WriteLine("Chapter 6 example 16: ");

            // step 1: creation of a document-object
            Document document = new Document();

            try
            {
                // step 2:
                // we create a writer that listens to the document
                // and directs a PDF-stream to a file

                PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(sFilePDF, FileMode.Create));

                // step 3: we open the document
                document.Open();

                // step 4: 
                document.Add(new Paragraph("TO DO"));
                ////.... TO DO

                bRet = true;
            }
            catch (DocumentException de)
            {
                this.Message = de.Message;
            }
            catch (IOException ioe)
            {
                this.Message = ioe.Message;
            }

            // step 5: we close the document
            document.Close();

            if (bRet)
                this.Message = sFilePDF + " has been created";

            return bRet;
        }
        #endregion //TO DO VERSION

    } // end of class
}
