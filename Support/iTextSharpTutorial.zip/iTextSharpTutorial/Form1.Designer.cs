namespace iTextSharpTutorial
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.ctlInfoLBL = new System.Windows.Forms.Label();
            this.ctlMainMenuStrip_MNU = new System.Windows.Forms.MenuStrip();
            this.ctlFile_MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlFileExitMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.tutorialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap01_MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0101MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap02_MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0201MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap03_MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0301MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap04_MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0401MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0402MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0403MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0404MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0405MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap05_MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0501MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0502MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0503MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0504MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0505MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0506MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0507MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0508MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0509MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0510MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0511MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0512MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0513MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0514MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0515MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0516MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0517MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChapter0518MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap06_MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0601MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0602MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0603MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0604MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0605MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0606MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0607MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0608MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0609MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0610MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0611MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0612MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0613MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0614MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0615MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlChap0616MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlHelp_MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlHelpAboutMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.ctlHelpTutorialHomeMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlAdobePdfSpec_MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlAdobePdfSpec17MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlAdobePdfSpec16MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlAdobePdfSpec15MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlAdobePdfSpec14MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlAdobePdfSpec13MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.ctlAdobePdfSpecTechCenterMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlBrowserBackMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.ctlTutorialAutoCheckMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlMainMenuStrip_MNU.SuspendLayout();
            this.SuspendLayout();
            // 
            // webBrowser1
            // 
            this.webBrowser1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.webBrowser1.Location = new System.Drawing.Point(12, 38);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(608, 496);
            this.webBrowser1.TabIndex = 5;
            // 
            // ctlInfoLBL
            // 
            this.ctlInfoLBL.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ctlInfoLBL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ctlInfoLBL.Location = new System.Drawing.Point(12, 540);
            this.ctlInfoLBL.Name = "ctlInfoLBL";
            this.ctlInfoLBL.Size = new System.Drawing.Size(608, 23);
            this.ctlInfoLBL.TabIndex = 6;
            this.ctlInfoLBL.Text = "Ready";
            // 
            // ctlMainMenuStrip_MNU
            // 
            this.ctlMainMenuStrip_MNU.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlFile_MNU,
            this.tutorialToolStripMenuItem,
            this.ctlHelp_MNU,
            this.ctlBrowserBackMNU});
            this.ctlMainMenuStrip_MNU.Location = new System.Drawing.Point(0, 0);
            this.ctlMainMenuStrip_MNU.Name = "ctlMainMenuStrip_MNU";
            this.ctlMainMenuStrip_MNU.Size = new System.Drawing.Size(632, 24);
            this.ctlMainMenuStrip_MNU.TabIndex = 8;
            this.ctlMainMenuStrip_MNU.Text = "&Help";
            // 
            // ctlFile_MNU
            // 
            this.ctlFile_MNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlFileExitMNU});
            this.ctlFile_MNU.Name = "ctlFile_MNU";
            this.ctlFile_MNU.Size = new System.Drawing.Size(35, 20);
            this.ctlFile_MNU.Text = "&File";
            // 
            // ctlFileExitMNU
            // 
            this.ctlFileExitMNU.Name = "ctlFileExitMNU";
            this.ctlFileExitMNU.Size = new System.Drawing.Size(103, 22);
            this.ctlFileExitMNU.Text = "E&xit";
            this.ctlFileExitMNU.Click += new System.EventHandler(this.ctlFileExitMNU_Click);
            // 
            // tutorialToolStripMenuItem
            // 
            this.tutorialToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlChap01_MNU,
            this.ctlChap02_MNU,
            this.ctlChap03_MNU,
            this.ctlChap04_MNU,
            this.ctlChap05_MNU,
            this.ctlChap06_MNU,
            this.toolStripMenuItem3,
            this.ctlTutorialAutoCheckMNU});
            this.tutorialToolStripMenuItem.Name = "tutorialToolStripMenuItem";
            this.tutorialToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.tutorialToolStripMenuItem.Text = "&Tutorial";
            // 
            // ctlChap01_MNU
            // 
            this.ctlChap01_MNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlChap0101MNU});
            this.ctlChap01_MNU.Name = "ctlChap01_MNU";
            this.ctlChap01_MNU.Size = new System.Drawing.Size(237, 22);
            this.ctlChap01_MNU.Text = "Chapter 1";
            // 
            // ctlChap0101MNU
            // 
            this.ctlChap0101MNU.Name = "ctlChap0101MNU";
            this.ctlChap0101MNU.Size = new System.Drawing.Size(160, 22);
            this.ctlChap0101MNU.Text = "1: \"Hello World\"";
            this.ctlChap0101MNU.Click += new System.EventHandler(this.ctlChapter0101BTN_Click);
            // 
            // ctlChap02_MNU
            // 
            this.ctlChap02_MNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlChap0201MNU});
            this.ctlChap02_MNU.Name = "ctlChap02_MNU";
            this.ctlChap02_MNU.Size = new System.Drawing.Size(237, 22);
            this.ctlChap02_MNU.Text = "Chapter 2";
            // 
            // ctlChap0201MNU
            // 
            this.ctlChap0201MNU.Name = "ctlChap0201MNU";
            this.ctlChap0201MNU.Size = new System.Drawing.Size(182, 22);
            this.ctlChap0201MNU.Text = "1: Chunks and fonts";
            this.ctlChap0201MNU.Click += new System.EventHandler(this.ctlChapter0201_Click);
            // 
            // ctlChap03_MNU
            // 
            this.ctlChap03_MNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlChap0301MNU});
            this.ctlChap03_MNU.Name = "ctlChap03_MNU";
            this.ctlChap03_MNU.Size = new System.Drawing.Size(237, 22);
            this.ctlChap03_MNU.Text = "Chapter 3";
            // 
            // ctlChap0301MNU
            // 
            this.ctlChap0301MNU.Name = "ctlChap0301MNU";
            this.ctlChap0301MNU.Size = new System.Drawing.Size(137, 22);
            this.ctlChap0301MNU.Text = "1: Anchors";
            this.ctlChap0301MNU.Click += new System.EventHandler(this.ctlChapter0301BTN_Click);
            // 
            // ctlChap04_MNU
            // 
            this.ctlChap04_MNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlChap0401MNU,
            this.ctlChap0402MNU,
            this.ctlChap0403MNU,
            this.ctlChap0404MNU,
            this.ctlChap0405MNU});
            this.ctlChap04_MNU.Name = "ctlChap04_MNU";
            this.ctlChap04_MNU.Size = new System.Drawing.Size(237, 22);
            this.ctlChap04_MNU.Text = "Chapter 4";
            // 
            // ctlChap0401MNU
            // 
            this.ctlChap0401MNU.Name = "ctlChap0401MNU";
            this.ctlChap0401MNU.Size = new System.Drawing.Size(261, 22);
            this.ctlChap0401MNU.Text = "1: Headers and Footers";
            this.ctlChap0401MNU.Click += new System.EventHandler(this.ctlChapter0401BTN_Click);
            // 
            // ctlChap0402MNU
            // 
            this.ctlChap0402MNU.Name = "ctlChap0402MNU";
            this.ctlChap0402MNU.Size = new System.Drawing.Size(261, 22);
            this.ctlChap0402MNU.Text = "2: Chapters and Sections";
            this.ctlChap0402MNU.Click += new System.EventHandler(this.ctlChapter0402BTN_Click);
            // 
            // ctlChap0403MNU
            // 
            this.ctlChap0403MNU.Name = "ctlChap0403MNU";
            this.ctlChap0403MNU.Size = new System.Drawing.Size(261, 22);
            this.ctlChap0403MNU.Text = "3: Chapters and Sections 2";
            this.ctlChap0403MNU.Click += new System.EventHandler(this.ctlChapter0403BTN_Click);
            // 
            // ctlChap0404MNU
            // 
            this.ctlChap0404MNU.Name = "ctlChap0404MNU";
            this.ctlChap0404MNU.Size = new System.Drawing.Size(261, 22);
            this.ctlChap0404MNU.Text = "4: Simple Graphic";
            this.ctlChap0404MNU.Click += new System.EventHandler(this.ctlChapter0404BTN_Click);
            // 
            // ctlChap0405MNU
            // 
            this.ctlChap0405MNU.Name = "ctlChap0405MNU";
            this.ctlChap0405MNU.Size = new System.Drawing.Size(261, 22);
            this.ctlChap0405MNU.Text = "5: Page Borders and Horizontal Lines";
            this.ctlChap0405MNU.Click += new System.EventHandler(this.ctlChapter0405BTN_Click);
            // 
            // ctlChap05_MNU
            // 
            this.ctlChap05_MNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlChapter0501MNU,
            this.ctlChapter0502MNU,
            this.ctlChapter0503MNU,
            this.ctlChapter0504MNU,
            this.ctlChapter0505MNU,
            this.ctlChapter0506MNU,
            this.ctlChapter0507MNU,
            this.ctlChapter0508MNU,
            this.ctlChapter0509MNU,
            this.ctlChapter0510MNU,
            this.ctlChapter0511MNU,
            this.ctlChapter0512MNU,
            this.ctlChapter0513MNU,
            this.ctlChapter0514MNU,
            this.ctlChapter0515MNU,
            this.ctlChapter0516MNU,
            this.ctlChapter0517MNU,
            this.ctlChapter0518MNU});
            this.ctlChap05_MNU.Name = "ctlChap05_MNU";
            this.ctlChap05_MNU.Size = new System.Drawing.Size(237, 22);
            this.ctlChap05_MNU.Text = "Chapter 5";
            // 
            // ctlChapter0501MNU
            // 
            this.ctlChapter0501MNU.Name = "ctlChapter0501MNU";
            this.ctlChapter0501MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0501MNU.Text = "1: My First Table";
            this.ctlChapter0501MNU.Click += new System.EventHandler(this.ctlChapter0501MNU_Click);
            // 
            // ctlChapter0502MNU
            // 
            this.ctlChapter0502MNU.Name = "ctlChapter0502MNU";
            this.ctlChapter0502MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0502MNU.Text = "2: Adding Cells at a Specific Position";
            this.ctlChapter0502MNU.Click += new System.EventHandler(this.ctlChapter0502MNU_Click);
            // 
            // ctlChapter0503MNU
            // 
            this.ctlChapter0503MNU.Name = "ctlChapter0503MNU";
            this.ctlChapter0503MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0503MNU.Text = "3: Rows Added Automatically";
            this.ctlChapter0503MNU.Click += new System.EventHandler(this.ctlChapter0503MNU_Click);
            // 
            // ctlChapter0504MNU
            // 
            this.ctlChapter0504MNU.Name = "ctlChapter0504MNU";
            this.ctlChapter0504MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0504MNU.Text = "4: Adding Columns";
            this.ctlChapter0504MNU.Click += new System.EventHandler(this.ctlChapter0504MNU_Click);
            // 
            // ctlChapter0505MNU
            // 
            this.ctlChapter0505MNU.Name = "ctlChapter0505MNU";
            this.ctlChapter0505MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0505MNU.Text = "5: ColSpan, RowSpan, Padding, Spacing, Colors";
            this.ctlChapter0505MNU.Click += new System.EventHandler(this.ctlChapter0505MNU_Click);
            // 
            // ctlChapter0506MNU
            // 
            this.ctlChapter0506MNU.Name = "ctlChapter0506MNU";
            this.ctlChapter0506MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0506MNU.Text = "6: Spacing, Padding, Alignment";
            this.ctlChapter0506MNU.Click += new System.EventHandler(this.ctlChapter0506MNU_Click);
            // 
            // ctlChapter0507MNU
            // 
            this.ctlChapter0507MNU.Name = "ctlChapter0507MNU";
            this.ctlChapter0507MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0507MNU.Text = "7: Borders";
            this.ctlChapter0507MNU.Click += new System.EventHandler(this.ctlChapter0507MNU_Click);
            // 
            // ctlChapter0508MNU
            // 
            this.ctlChapter0508MNU.Name = "ctlChapter0508MNU";
            this.ctlChapter0508MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0508MNU.Text = "8: Table Splitting";
            this.ctlChapter0508MNU.Click += new System.EventHandler(this.ctlChapter0508MNU_Click);
            // 
            // ctlChapter0509MNU
            // 
            this.ctlChapter0509MNU.Name = "ctlChapter0509MNU";
            this.ctlChapter0509MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0509MNU.Text = "9: Large Tables";
            this.ctlChapter0509MNU.Click += new System.EventHandler(this.ctlChapter0509MNU_Click);
            // 
            // ctlChapter0510MNU
            // 
            this.ctlChapter0510MNU.Name = "ctlChapter0510MNU";
            this.ctlChapter0510MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0510MNU.Text = "10: Large Tables with Repeating Headers";
            this.ctlChapter0510MNU.Click += new System.EventHandler(this.ctlChapter0510MNU_Click);
            // 
            // ctlChapter0511MNU
            // 
            this.ctlChapter0511MNU.Name = "ctlChapter0511MNU";
            this.ctlChapter0511MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0511MNU.Text = "11: Avoid Table Splitting";
            this.ctlChapter0511MNU.Click += new System.EventHandler(this.ctlChapter0511MNU_Click);
            // 
            // ctlChapter0512MNU
            // 
            this.ctlChapter0512MNU.Name = "ctlChapter0512MNU";
            this.ctlChapter0512MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0512MNU.Text = "12: Avoid Cell Splitting";
            this.ctlChapter0512MNU.Click += new System.EventHandler(this.ctlChapter0512MNU_Click);
            // 
            // ctlChapter0513MNU
            // 
            this.ctlChapter0513MNU.Name = "ctlChapter0513MNU";
            this.ctlChapter0513MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0513MNU.Text = "13: Large Tables with \'FitsPage\'";
            this.ctlChapter0513MNU.Click += new System.EventHandler(this.ctlChapter0513MNU_Click);
            // 
            // ctlChapter0514MNU
            // 
            this.ctlChapter0514MNU.Name = "ctlChapter0514MNU";
            this.ctlChapter0514MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0514MNU.Text = "14: Nested Tables 1";
            this.ctlChapter0514MNU.Click += new System.EventHandler(this.ctlChapter0514MNU_Click);
            // 
            // ctlChapter0515MNU
            // 
            this.ctlChapter0515MNU.Name = "ctlChapter0515MNU";
            this.ctlChapter0515MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0515MNU.Text = "15: Nested Tables 2";
            this.ctlChapter0515MNU.Click += new System.EventHandler(this.ctlChapter0515MNU_Click);
            // 
            // ctlChapter0516MNU
            // 
            this.ctlChapter0516MNU.Name = "ctlChapter0516MNU";
            this.ctlChapter0516MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0516MNU.Text = "16: Nested Tables 3";
            this.ctlChapter0516MNU.Click += new System.EventHandler(this.ctlChapter0516MNU_Click);
            // 
            // ctlChapter0517MNU
            // 
            this.ctlChapter0517MNU.Name = "ctlChapter0517MNU";
            this.ctlChapter0517MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0517MNU.Text = "17: Table Offset";
            this.ctlChapter0517MNU.Click += new System.EventHandler(this.ctlChapter0517MNU_Click);
            // 
            // ctlChapter0518MNU
            // 
            this.ctlChapter0518MNU.Name = "ctlChapter0518MNU";
            this.ctlChapter0518MNU.Size = new System.Drawing.Size(315, 22);
            this.ctlChapter0518MNU.Text = "18: PdfPTable";
            this.ctlChapter0518MNU.Click += new System.EventHandler(this.ctlChapter0518MNU_Click);
            // 
            // ctlChap06_MNU
            // 
            this.ctlChap06_MNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlChap0601MNU,
            this.ctlChap0602MNU,
            this.ctlChap0603MNU,
            this.ctlChap0604MNU,
            this.ctlChap0605MNU,
            this.ctlChap0606MNU,
            this.ctlChap0607MNU,
            this.ctlChap0608MNU,
            this.ctlChap0609MNU,
            this.ctlChap0610MNU,
            this.ctlChap0611MNU,
            this.ctlChap0612MNU,
            this.ctlChap0613MNU,
            this.ctlChap0614MNU,
            this.ctlChap0615MNU,
            this.ctlChap0616MNU});
            this.ctlChap06_MNU.Name = "ctlChap06_MNU";
            this.ctlChap06_MNU.Size = new System.Drawing.Size(237, 22);
            this.ctlChap06_MNU.Text = "Chapter 6";
            // 
            // ctlChap0601MNU
            // 
            this.ctlChap0601MNU.Name = "ctlChap0601MNU";
            this.ctlChap0601MNU.Size = new System.Drawing.Size(351, 22);
            this.ctlChap0601MNU.Text = "1: Adding a Wmf, Gif, Jpeg and Png-file using urls";
            this.ctlChap0601MNU.Click += new System.EventHandler(this.ctlChapter0601MNU_Click);
            // 
            // ctlChap0602MNU
            // 
            this.ctlChap0602MNU.Name = "ctlChap0602MNU";
            this.ctlChap0602MNU.Size = new System.Drawing.Size(351, 22);
            this.ctlChap0602MNU.Text = "2: Adding a Wmf, Gif, Jpeg and Png-file using filenames";
            this.ctlChap0602MNU.Click += new System.EventHandler(this.ctlChapter0602MNU_Click);
            // 
            // ctlChap0603MNU
            // 
            this.ctlChap0603MNU.Name = "ctlChap0603MNU";
            this.ctlChap0603MNU.Size = new System.Drawing.Size(351, 22);
            this.ctlChap0603MNU.Text = "3: Inserting a Scaled Image file, relative path";
            this.ctlChap0603MNU.Click += new System.EventHandler(this.ctlChapter0603MNU_Click);
            // 
            // ctlChap0604MNU
            // 
            this.ctlChap0604MNU.Name = "ctlChap0604MNU";
            this.ctlChap0604MNU.Size = new System.Drawing.Size(351, 22);
            this.ctlChap0604MNU.Text = "4: Alignment of Images";
            this.ctlChap0604MNU.Click += new System.EventHandler(this.ctlChapter0604MNU_Click);
            // 
            // ctlChap0605MNU
            // 
            this.ctlChap0605MNU.Name = "ctlChap0605MNU";
            this.ctlChap0605MNU.Size = new System.Drawing.Size(351, 22);
            this.ctlChap0605MNU.Text = "5: Alignment of Images and Text";
            this.ctlChap0605MNU.Click += new System.EventHandler(this.ctlChapter0605MNU_Click);
            // 
            // ctlChap0606MNU
            // 
            this.ctlChap0606MNU.Name = "ctlChap0606MNU";
            this.ctlChap0606MNU.Size = new System.Drawing.Size(351, 22);
            this.ctlChap0606MNU.Text = "6: Absolute Positioning of an Image";
            this.ctlChap0606MNU.Click += new System.EventHandler(this.ctlChapter0606MNU_Click);
            // 
            // ctlChap0607MNU
            // 
            this.ctlChap0607MNU.Name = "ctlChap0607MNU";
            this.ctlChap0607MNU.Size = new System.Drawing.Size(351, 22);
            this.ctlChap0607MNU.Text = "7: Scaling an Image";
            this.ctlChap0607MNU.Click += new System.EventHandler(this.ctlChapter0607MNU_Click);
            // 
            // ctlChap0608MNU
            // 
            this.ctlChap0608MNU.Name = "ctlChap0608MNU";
            this.ctlChap0608MNU.Size = new System.Drawing.Size(351, 22);
            this.ctlChap0608MNU.Text = "8: Rotating an Image";
            this.ctlChap0608MNU.Click += new System.EventHandler(this.ctlChapter0608MNU_Click);
            // 
            // ctlChap0609MNU
            // 
            this.ctlChap0609MNU.Name = "ctlChap0609MNU";
            this.ctlChap0609MNU.Size = new System.Drawing.Size(351, 22);
            this.ctlChap0609MNU.Text = "9: Inserting Raw Image Data";
            this.ctlChap0609MNU.Click += new System.EventHandler(this.ctlChapter0609MNU_Click);
            // 
            // ctlChap0610MNU
            // 
            this.ctlChap0610MNU.Name = "ctlChap0610MNU";
            this.ctlChap0610MNU.Size = new System.Drawing.Size(351, 22);
            this.ctlChap0610MNU.Text = "10: Images using System.Drawing.Bitmap!";
            this.ctlChap0610MNU.Click += new System.EventHandler(this.ctlChapter0610MNU_Click);
            // 
            // ctlChap0611MNU
            // 
            this.ctlChap0611MNU.Enabled = false;
            this.ctlChap0611MNU.Name = "ctlChap0611MNU";
            this.ctlChap0611MNU.Size = new System.Drawing.Size(351, 22);
            this.ctlChap0611MNU.Text = "11: TIFF and CCITT";
            this.ctlChap0611MNU.Click += new System.EventHandler(this.ctlChapter0611MNU_Click);
            // 
            // ctlChap0612MNU
            // 
            this.ctlChap0612MNU.Enabled = false;
            this.ctlChap0612MNU.Name = "ctlChap0612MNU";
            this.ctlChap0612MNU.Size = new System.Drawing.Size(351, 22);
            this.ctlChap0612MNU.Text = "12";
            this.ctlChap0612MNU.Click += new System.EventHandler(this.ctlChapter0612MNU_Click);
            // 
            // ctlChap0613MNU
            // 
            this.ctlChap0613MNU.Name = "ctlChap0613MNU";
            this.ctlChap0613MNU.Size = new System.Drawing.Size(351, 22);
            this.ctlChap0613MNU.Text = "13: Masked Images";
            this.ctlChap0613MNU.Click += new System.EventHandler(this.ctlChapter0613MNU_Click);
            // 
            // ctlChap0614MNU
            // 
            this.ctlChap0614MNU.Name = "ctlChap0614MNU";
            this.ctlChap0614MNU.Size = new System.Drawing.Size(351, 22);
            this.ctlChap0614MNU.Text = "14: Images Wrapped in a Chunk";
            this.ctlChap0614MNU.Click += new System.EventHandler(this.ctlChapter0614MNU_Click);
            // 
            // ctlChap0615MNU
            // 
            this.ctlChap0615MNU.Name = "ctlChap0615MNU";
            this.ctlChap0615MNU.Size = new System.Drawing.Size(351, 22);
            this.ctlChap0615MNU.Text = "15: Images in Tables";
            this.ctlChap0615MNU.Click += new System.EventHandler(this.ctlChapter0615MNU_Click);
            // 
            // ctlChap0616MNU
            // 
            this.ctlChap0616MNU.Name = "ctlChap0616MNU";
            this.ctlChap0616MNU.Size = new System.Drawing.Size(351, 22);
            this.ctlChap0616MNU.Text = "16: Images and Annotations";
            this.ctlChap0616MNU.Click += new System.EventHandler(this.ctlChapter0616MNU_Click);
            // 
            // ctlHelp_MNU
            // 
            this.ctlHelp_MNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlHelpTutorialHomeMNU,
            this.ctlAdobePdfSpec_MNU,
            this.toolStripMenuItem1,
            this.ctlHelpAboutMNU});
            this.ctlHelp_MNU.Name = "ctlHelp_MNU";
            this.ctlHelp_MNU.Size = new System.Drawing.Size(40, 20);
            this.ctlHelp_MNU.Text = "&Help";
            // 
            // ctlHelpAboutMNU
            // 
            this.ctlHelpAboutMNU.Name = "ctlHelpAboutMNU";
            this.ctlHelpAboutMNU.Size = new System.Drawing.Size(206, 22);
            this.ctlHelpAboutMNU.Text = "&About";
            this.ctlHelpAboutMNU.Click += new System.EventHandler(this.ctlHelpAboutMNU_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(203, 6);
            // 
            // ctlHelpTutorialHomeMNU
            // 
            this.ctlHelpTutorialHomeMNU.Name = "ctlHelpTutorialHomeMNU";
            this.ctlHelpTutorialHomeMNU.Size = new System.Drawing.Size(206, 22);
            this.ctlHelpTutorialHomeMNU.Text = "iTextSharp Tutorial Home";
            this.ctlHelpTutorialHomeMNU.Click += new System.EventHandler(this.ctlHelpTutorialHomeMNU_Click);
            // 
            // ctlAdobePdfSpec_MNU
            // 
            this.ctlAdobePdfSpec_MNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlAdobePdfSpec17MNU,
            this.ctlAdobePdfSpec16MNU,
            this.ctlAdobePdfSpec15MNU,
            this.ctlAdobePdfSpec14MNU,
            this.ctlAdobePdfSpec13MNU,
            this.toolStripMenuItem2,
            this.ctlAdobePdfSpecTechCenterMNU});
            this.ctlAdobePdfSpec_MNU.Name = "ctlAdobePdfSpec_MNU";
            this.ctlAdobePdfSpec_MNU.Size = new System.Drawing.Size(206, 22);
            this.ctlAdobePdfSpec_MNU.Text = "Adobe PDF Specifications";
            // 
            // ctlAdobePdfSpec17MNU
            // 
            this.ctlAdobePdfSpec17MNU.Name = "ctlAdobePdfSpec17MNU";
            this.ctlAdobePdfSpec17MNU.Size = new System.Drawing.Size(198, 22);
            this.ctlAdobePdfSpec17MNU.Text = "Version 1.7";
            this.ctlAdobePdfSpec17MNU.Click += new System.EventHandler(this.ctlAdobePdfSpec17MNU_Click);
            // 
            // ctlAdobePdfSpec16MNU
            // 
            this.ctlAdobePdfSpec16MNU.Name = "ctlAdobePdfSpec16MNU";
            this.ctlAdobePdfSpec16MNU.Size = new System.Drawing.Size(198, 22);
            this.ctlAdobePdfSpec16MNU.Text = "Version 1.6";
            this.ctlAdobePdfSpec16MNU.Click += new System.EventHandler(this.ctlAdobePdfSpec16MNU_Click);
            // 
            // ctlAdobePdfSpec15MNU
            // 
            this.ctlAdobePdfSpec15MNU.Name = "ctlAdobePdfSpec15MNU";
            this.ctlAdobePdfSpec15MNU.Size = new System.Drawing.Size(198, 22);
            this.ctlAdobePdfSpec15MNU.Text = "Version 1.5";
            this.ctlAdobePdfSpec15MNU.Click += new System.EventHandler(this.ctlAdobePdfSpec15MNU_Click);
            // 
            // ctlAdobePdfSpec14MNU
            // 
            this.ctlAdobePdfSpec14MNU.Name = "ctlAdobePdfSpec14MNU";
            this.ctlAdobePdfSpec14MNU.Size = new System.Drawing.Size(198, 22);
            this.ctlAdobePdfSpec14MNU.Text = "Version 1.4";
            this.ctlAdobePdfSpec14MNU.Click += new System.EventHandler(this.ctlAdobePdfSpec14MNU_Click);
            // 
            // ctlAdobePdfSpec13MNU
            // 
            this.ctlAdobePdfSpec13MNU.Name = "ctlAdobePdfSpec13MNU";
            this.ctlAdobePdfSpec13MNU.Size = new System.Drawing.Size(198, 22);
            this.ctlAdobePdfSpec13MNU.Text = "Version 1.3";
            this.ctlAdobePdfSpec13MNU.Click += new System.EventHandler(this.ctlAdobePdfSpec13MNU_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(195, 6);
            // 
            // ctlAdobePdfSpecTechCenterMNU
            // 
            this.ctlAdobePdfSpecTechCenterMNU.Name = "ctlAdobePdfSpecTechCenterMNU";
            this.ctlAdobePdfSpecTechCenterMNU.Size = new System.Drawing.Size(198, 22);
            this.ctlAdobePdfSpecTechCenterMNU.Text = "PDF Technology Center";
            this.ctlAdobePdfSpecTechCenterMNU.Click += new System.EventHandler(this.ctlAdobePdfSpecTechCenterMNU_Click);
            // 
            // ctlBrowserBackMNU
            // 
            this.ctlBrowserBackMNU.Name = "ctlBrowserBackMNU";
            this.ctlBrowserBackMNU.Size = new System.Drawing.Size(41, 20);
            this.ctlBrowserBackMNU.Text = "&Back";
            this.ctlBrowserBackMNU.Click += new System.EventHandler(this.ctlBrowserBackMNU_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(234, 6);
            // 
            // ctlTutorialAutoCheckMNU
            // 
            this.ctlTutorialAutoCheckMNU.Checked = true;
            this.ctlTutorialAutoCheckMNU.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ctlTutorialAutoCheckMNU.Name = "ctlTutorialAutoCheckMNU";
            this.ctlTutorialAutoCheckMNU.Size = new System.Drawing.Size(237, 22);
            this.ctlTutorialAutoCheckMNU.Text = "&Auto check example when done";
            this.ctlTutorialAutoCheckMNU.Click += new System.EventHandler(this.ctlTutorialAutoCheckMNU_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 566);
            this.Controls.Add(this.ctlInfoLBL);
            this.Controls.Add(this.webBrowser1);
            this.Controls.Add(this.ctlMainMenuStrip_MNU);
            this.MainMenuStrip = this.ctlMainMenuStrip_MNU;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "iTextSharpTutorial";
            this.Shown += new System.EventHandler(this.OnFormShown);
            this.ctlMainMenuStrip_MNU.ResumeLayout(false);
            this.ctlMainMenuStrip_MNU.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.Label ctlInfoLBL;
        private System.Windows.Forms.MenuStrip ctlMainMenuStrip_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlFile_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlFileExitMNU;
        private System.Windows.Forms.ToolStripMenuItem tutorialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ctlChap01_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap02_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap03_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap04_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0401MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0402MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0403MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0404MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0405MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0201MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0101MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0301MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap05_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0501MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0502MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0503MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0504MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0505MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0506MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0507MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0508MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0509MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0510MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0511MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0512MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0513MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0514MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0515MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0516MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0517MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChapter0518MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlHelp_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlHelpAboutMNU;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ctlHelpTutorialHomeMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap06_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0601MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0602MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0603MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0604MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0605MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0606MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0607MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0608MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0609MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0610MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0611MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0612MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0613MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0614MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0615MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlChap0616MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlAdobePdfSpec_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlAdobePdfSpec17MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlAdobePdfSpec16MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlAdobePdfSpec15MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlAdobePdfSpec14MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlAdobePdfSpec13MNU;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem ctlAdobePdfSpecTechCenterMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlBrowserBackMNU;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem ctlTutorialAutoCheckMNU;
    }
}

